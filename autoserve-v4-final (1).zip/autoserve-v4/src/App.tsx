import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppProvider } from './context/AppContext';
import Navbar from './components/layout/Navbar';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import VehiclesPage from './pages/VehiclesPage';
import ServicesPage from './pages/ServicesPage';
import CartPage from './pages/CartPage';
import BookingPage from './pages/BookingPage';
import BookingsPage from './pages/BookingsPage';
import TrackingPage from './pages/TrackingPage';
import PaymentPage from './pages/PaymentPage';
import MessagesPage from './pages/MessagesPage';
import ProfilePage from './pages/ProfilePage';
import AdminDashboard from './pages/AdminDashboard';
import MechanicPage from './pages/MechanicPage';
import SettingsPage from './pages/SettingsPage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';

// ─── Types ────────────────────────────────────────────────────────────────────

interface ProtectedRouteProps {
  children: React.ReactNode;
  roles?: string[];
}

type CartUpdater = number[] | ((prev: number[]) => number[]);

// ─── Protected Route ──────────────────────────────────────────────────────────

function ProtectedRoute({ children, roles }: ProtectedRouteProps) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/dashboard" replace />;
  return <>{children}</>;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function cartKey(userId: number): string {
  return `as_cart_user_${userId}`;
}

function loadCart(userId: number): number[] {
  try {
    const stored = localStorage.getItem(cartKey(userId));
    return stored ? (JSON.parse(stored) as number[]) : [];
  } catch {
    return [];
  }
}

function saveCart(userId: number, items: number[]): void {
  try {
    localStorage.setItem(cartKey(userId), JSON.stringify(items));
  } catch {}
}

// ─── App Routes ───────────────────────────────────────────────────────────────

function AppRoutes() {
  const { user } = useAuth();

  // Cart always starts empty; useEffect below loads the correct user-specific cart
  const [cart, setCart] = useState<number[]>([]);

  // Reload (or clear) the cart whenever the logged-in user changes
  useEffect(() => {
    if (user) {
      setCart(loadCart(user.id));
    } else {
      // No one is logged in — wipe the in-memory cart so it doesn't bleed into
      // the next user's session
      setCart([]);
    }
  }, [user?.id]); // runs when user logs in, switches, or logs out

  const updateCart = (fn: CartUpdater): void => {
    setCart(prev => {
      const next = typeof fn === 'function' ? fn(prev) : fn;
      // Only persist when there is an active user
      if (user) {
        saveCart(user.id, next);
      }
      return next;
    });
  };

  return (
    <>
      <Navbar cart={cart} />
      <div style={{ paddingTop: user ? '65px' : '0' }}>
        <Routes>
          <Route path="/"          element={user ? <Navigate to="/dashboard" /> : <LandingPage />} />
          <Route path="/login"     element={user ? <Navigate to="/dashboard" /> : <LoginPage />} />
          <Route path="/register"  element={user ? <Navigate to="/dashboard" /> : <RegisterPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
          <Route path="/vehicles"  element={<ProtectedRoute><VehiclesPage /></ProtectedRoute>} />
          <Route path="/services"  element={<ProtectedRoute roles={['customer']}><ServicesPage cart={cart} setCart={updateCart} /></ProtectedRoute>} />
          <Route path="/cart"      element={<ProtectedRoute roles={['customer']}><CartPage cart={cart} setCart={updateCart} /></ProtectedRoute>} />
          <Route path="/book/:serviceId?" element={<ProtectedRoute><BookingPage /></ProtectedRoute>} />
          <Route path="/book"      element={<ProtectedRoute><BookingPage /></ProtectedRoute>} />
          <Route path="/bookings"  element={<ProtectedRoute><BookingsPage /></ProtectedRoute>} />
          <Route path="/track/:bookingId"    element={<ProtectedRoute><TrackingPage /></ProtectedRoute>} />
          <Route path="/payment/:bookingId"  element={<ProtectedRoute><PaymentPage /></ProtectedRoute>} />
          <Route path="/messages"            element={<ProtectedRoute><MessagesPage /></ProtectedRoute>} />
          <Route path="/messages/:bookingId" element={<ProtectedRoute><MessagesPage /></ProtectedRoute>} />
          <Route path="/profile"   element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
          <Route path="/admin"     element={<ProtectedRoute roles={['admin']}><AdminDashboard /></ProtectedRoute>} />
          <Route path="/admin/bookings" element={<ProtectedRoute roles={['admin']}><AdminDashboard tab="bookings" /></ProtectedRoute>} />
          <Route path="/mechanic"  element={<ProtectedRoute roles={['mechanic']}><MechanicPage /></ProtectedRoute>} />
          <Route path="/settings"  element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />
          <Route path="*"          element={<Navigate to="/" />} />
        </Routes>
      </div>
    </>
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppProvider>
          <AppRoutes />
          <Toaster
            position="top-right"
            toastOptions={{
              style: { background: '#ffffff', color: '#1e293b', border: '1px solid #e2e8f0', fontFamily: 'DM Sans, sans-serif', boxShadow: '0 4px 24px rgba(0,0,0,0.1)' },
              success: { iconTheme: { primary: '#16a34a', secondary: '#ffffff' } },
              error:   { iconTheme: { primary: '#dc2626', secondary: '#ffffff' } },
            }}
          />
        </AppProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
