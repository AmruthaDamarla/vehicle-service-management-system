import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { Notification } from '../../context/AppContext';
import { Bell, X, MessageCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function NotificationBell() {
  const { notifications, dismissNotification } = useApp();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Filter notifications relevant to current user role
  const myNotifs: Notification[] = notifications.filter(n => {
    if (user?.role === 'customer') return n.from === 'mechanic';
    if (user?.role === 'mechanic') return n.from === 'customer';
    return false;
  });

  // Popup toast for newest notification
  const [toast, setToast] = useState<Notification | null>(null);
  const prevLen = useRef(myNotifs.length);
  useEffect(() => {
    if (myNotifs.length > prevLen.current) {
      const newest = myNotifs[0];
      setToast(newest);
      const t = setTimeout(() => setToast(null), 4000);
      return () => clearTimeout(t);
    }
    prevLen.current = myNotifs.length;
  }, [myNotifs.length]);

  // Close dropdown on outside click
  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  if (!user || user.role === 'admin') return null;

  return (
    <>
      {/* Popup toast */}
      {toast && (
        <div
          className="notif-toast animate-slideInRight"
          onClick={() => { navigate(`/messages/${toast.bookingId}`); setToast(null); }}
        >
          <div className="nt-icon"><MessageCircle size={16} /></div>
          <div className="nt-body">
            <div className="nt-title">{toast.from === 'mechanic' ? '🔧 Mechanic replied' : '👤 New message'}</div>
            <div className="nt-text">{toast.text?.slice(0, 60)}{(toast.text?.length ?? 0) > 60 ? '…' : ''}</div>
          </div>
          <button className="nt-close" onClick={e => { e.stopPropagation(); setToast(null); }}><X size={14} /></button>
        </div>
      )}

      {/* Bell icon */}
      <div style={{ position: 'relative' }} ref={ref}>
        <button className="notif-bell-btn" onClick={() => setOpen(!open)}>
          <Bell size={18} />
          {myNotifs.length > 0 && <span className="notif-dot">{myNotifs.length}</span>}
        </button>

        {open && (
          <div className="notif-dropdown animate-fadeInUp">
            <div className="nd-header">
              <span>Notifications</span>
              {myNotifs.length > 0 && (
                <button className="nd-clear" onClick={() => myNotifs.forEach(n => dismissNotification(n.id))}>Clear all</button>
              )}
            </div>
            {myNotifs.length === 0 ? (
              <div className="nd-empty"><Bell size={24} /><p>No notifications</p></div>
            ) : (
              myNotifs.map(n => (
                <div key={n.id} className="nd-item" onClick={() => { navigate(`/messages/${n.bookingId}`); setOpen(false); }}>
                  <div className="nd-icon"><MessageCircle size={14} /></div>
                  <div className="nd-body">
                    <div className="nd-from">{n.from === 'mechanic' ? 'Mechanic' : 'Customer'}</div>
                    <div className="nd-text">{n.text?.slice(0, 50)}{(n.text?.length ?? 0) > 50 ? '…' : ''}</div>
                    <div className="nd-time">{n.time}</div>
                  </div>
                  <button className="nd-dismiss" onClick={e => { e.stopPropagation(); dismissNotification(n.id); }}><X size={12} /></button>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </>
  );
}
