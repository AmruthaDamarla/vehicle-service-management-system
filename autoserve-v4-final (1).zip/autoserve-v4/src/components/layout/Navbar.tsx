import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { Car, Menu, X, LogOut, User, Settings, LayoutDashboard, Wrench, BookOpen, MessageCircle, ChevronDown, ShoppingCart, LucideIcon } from 'lucide-react';
import './Navbar.css';

interface NavbarProps {
  cart?: number[];
}

interface NavLink {
  to: string;
  label: string;
  icon: LucideIcon;
}

export default function Navbar({ cart = [] }: NavbarProps) {
  const { user, logout } = useAuth();
  const { bookings, messages } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 0 || true);
    window.addEventListener('scroll', h);
    return () => window.removeEventListener('scroll', h);
  }, []);

  const unreadMessages = Object.values(messages).flat().filter(m => !m.read && m.from !== 'customer').length;
  const activeBookings = bookings.filter(b => b.userId === user?.id && !['Completed', 'Cancelled'].includes(b.status)).length;

  const handleLogout = () => { logout(); navigate('/'); };

  const navLinks: NavLink[] = user?.role === 'admin'
    ? [{ to: '/admin', label: 'Dashboard', icon: LayoutDashboard }, { to: '/admin/bookings', label: 'Bookings', icon: BookOpen }]
    : user?.role === 'mechanic'
    ? [{ to: '/mechanic', label: 'My Jobs', icon: Wrench }]
    : [
        { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { to: '/services',  label: 'Services',  icon: Wrench },
        { to: '/bookings',  label: 'Bookings',  icon: BookOpen },
        { to: '/vehicles',  label: 'Vehicles',  icon: Car },
        { to: '/messages',  label: 'Messages',  icon: MessageCircle },
      ];

  if (!user && ['/login', '/register'].includes(location.pathname)) return null;

  return (
    <nav className={`navbar${scrolled ? ' scrolled' : ''}`}>
      <div className="navbar-inner">
        <Link to={user ? '/dashboard' : '/'} className="navbar-brand">
          <div className="brand-icon"><Car size={20} /></div>
          <span className="brand-text">AutoServe</span>
        </Link>

        {user && (
          <div className="navbar-links">
            {navLinks.map(l => (
              <Link key={l.to} to={l.to} className={`nav-link${location.pathname.startsWith(l.to) ? ' active' : ''}`}>
                <l.icon size={16} />
                {l.label}
                {l.to === '/messages' && unreadMessages > 0 && <span className="nav-badge">{unreadMessages}</span>}
                {l.to === '/bookings' && activeBookings > 0 && <span className="nav-badge">{activeBookings}</span>}
              </Link>
            ))}
          </div>
        )}

        <div className="navbar-right">
          {user ? (
            <>
              {user?.role === 'customer' && cart.length > 0 && (
                <Link to="/cart" className="icon-btn" style={{ position: 'relative' }}>
                  <ShoppingCart size={18} />
                  <span className="notif-dot">{cart.length}</span>
                </Link>
              )}
              <div className="profile-menu-wrap">
                <button className="profile-trigger" onClick={() => setProfileOpen(!profileOpen)}>
                  <div className="avatar">{user.avatar}</div>
                  <span className="profile-name">{user.name.split(' ')[0]}</span>
                  <ChevronDown size={14} className={profileOpen ? 'rotate' : ''} />
                </button>
                {profileOpen && (
                  <div className="profile-dropdown" onClick={() => setProfileOpen(false)}>
                    <div className="dropdown-header">
                      <div className="avatar lg">{user.avatar}</div>
                      <div>
                        <div className="dh-name">{user.name}</div>
                        <div className="dh-email">{user.email}</div>
                        <span className={`badge badge-${user.role === 'admin' ? 'orange' : user.role === 'mechanic' ? 'blue' : 'green'}`}>{user.role}</span>
                      </div>
                    </div>
                    <div className="dropdown-divider" />
                    <Link to="/profile"  className="dropdown-item"><User size={15} />Profile</Link>
                    <Link to="/settings" className="dropdown-item"><Settings size={15} />Settings</Link>
                    <div className="dropdown-divider" />
                    <button className="dropdown-item danger" onClick={handleLogout}><LogOut size={15} />Sign Out</button>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="auth-buttons">
              <Link to="/login"    className="btn btn-ghost btn-sm">Sign In</Link>
              <Link to="/register" className="btn btn-primary btn-sm">Get Started</Link>
            </div>
          )}
          <button className="mobile-menu-btn" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {menuOpen && user && (
        <div className="mobile-nav" onClick={() => setMenuOpen(false)}>
          {navLinks.map(l => (
            <Link key={l.to} to={l.to} className={`mobile-nav-link${location.pathname.startsWith(l.to) ? ' active' : ''}`}>
              <l.icon size={16} />{l.label}
            </Link>
          ))}
          <button className="mobile-nav-link danger" onClick={handleLogout}><LogOut size={16} />Sign Out</button>
        </div>
      )}
    </nav>
  );
}
