import React, { createContext, useContext, useState, useCallback } from 'react';

// ─── Types ───────────────────────────────────────────────────────────────────

export interface User {
  id: number;
  name: string;
  email: string;
  mobile: string;
  password: string;
  role: 'customer' | 'admin' | 'mechanic';
  avatar: string;
  skills: string[];
  status: 'active' | 'pending' | 'inactive';
  token?: string;
}

export interface RegisterData {
  name: string;
  email: string;
  mobile: string;
  password: string;
  role: 'customer' | 'mechanic';
  skills?: string[];
}

export interface ApplicationData {
  userId: number;
  name: string;
  email: string;
  mobile: string;
  skills: string[];
}

export interface RegisterResult {
  success?: boolean;
  pending?: boolean;
  error?: string;
}

export interface LoginResult {
  success?: boolean;
  role?: string;
  error?: string;
}

interface AuthContextType {
  user: User | null;
  register: (data: RegisterData, submitApplication?: (data: ApplicationData) => void) => RegisterResult;
  login: (identifier: string, password: string) => LoginResult;
  logout: () => void;
  updateProfile: (data: Partial<User>) => { success: boolean };
  MOCK_USERS: User[];
  activateMechanicUser: (userId: number) => void;
}

// ─── Persistence helpers ──────────────────────────────────────────────────────

const LS_USERS_KEY = 'as_registered_users';

const BASE_USERS: User[] = [
  { id: 1, name: 'Arjun Kumar',   email: 'arjun@example.com',    mobile: '9876543210', password: 'Arjun@123', role: 'customer',  avatar: 'AK', skills: [], status: 'active' },
  { id: 2, name: 'Admin User',    email: 'admin@autoserve.com',  mobile: '9000000001', password: 'Admin@123', role: 'admin',     avatar: 'AU', skills: [], status: 'active' },
  { id: 3, name: 'Ravi Mechanic', email: 'ravi@autoserve.com',   mobile: '9000000002', password: 'Ravi@123',  role: 'mechanic',  avatar: 'RM', skills: ['General', 'Electrical'], status: 'active' },
  { id: 4, name: 'Suresh Kumar',  email: 'suresh@autoserve.com', mobile: '9000000003', password: 'Suresh@123', role: 'mechanic', avatar: 'SK', skills: ['Bodywork', 'General'],   status: 'active' },
];

function loadUsers(): User[] {
  try {
    const stored = localStorage.getItem(LS_USERS_KEY);
    if (!stored) return [...BASE_USERS];
    const extra: User[] = JSON.parse(stored);
    // Merge: base users always fresh; extra users appended
    const merged = [...BASE_USERS];
    for (const u of extra) {
      if (!merged.find(b => b.id === u.id)) merged.push(u);
    }
    return merged;
  } catch {
    return [...BASE_USERS];
  }
}

function saveExtraUsers(users: User[]): void {
  try {
    const extra = users.filter(u => !BASE_USERS.find(b => b.id === u.id));
    localStorage.setItem(LS_USERS_KEY, JSON.stringify(extra));
  } catch {}
}

// Mutable runtime store — kept in sync with localStorage
export let MOCK_USERS: User[] = loadUsers();

// ─── Context ──────────────────────────────────────────────────────────────────

const AuthContext = createContext<AuthContextType>(null!);

// ─── Provider ─────────────────────────────────────────────────────────────────

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [failedAttempts, setFailedAttempts] = useState<Record<string, number>>({});
  const [lockedAccounts, setLockedAccounts] = useState<Record<string, number>>({});

  // Register: customers instantly active; mechanics go into "pending" (handled by AppContext)
  const register = useCallback((data: RegisterData, submitApplication?: (d: ApplicationData) => void): RegisterResult => {
    // Re-load from localStorage so we always have latest list
    MOCK_USERS = loadUsers();

    const existing = MOCK_USERS.find(u => u.email === data.email || u.mobile === data.mobile);
    if (existing) {
      return { error: existing.email === data.email ? 'Email already registered' : 'Mobile already registered' };
    }

    if (data.role === 'mechanic') {
      const pendingUser: User = {
        id: Date.now(), ...data,
        role: 'mechanic',
        avatar: data.name.substring(0, 2).toUpperCase(),
        skills: data.skills || [],
        status: 'pending',
      };
      MOCK_USERS.push(pendingUser);
      saveExtraUsers(MOCK_USERS);
      if (submitApplication) {
        submitApplication({ userId: pendingUser.id, name: pendingUser.name, email: pendingUser.email, mobile: pendingUser.mobile, skills: pendingUser.skills });
      }
      return { success: true, pending: true };
    }

    // Customer: save account but do NOT auto-login — redirect to login page
    const newUser: User = { id: Date.now(), ...data, role: 'customer', avatar: data.name.substring(0, 2).toUpperCase(), skills: [], status: 'active' };
    MOCK_USERS.push(newUser);
    saveExtraUsers(MOCK_USERS);
    return { success: true };
  }, []);

  const login = useCallback((identifier: string, password: string): LoginResult => {
    // Always reload users from localStorage before login to pick up newly registered users
    MOCK_USERS = loadUsers();

    if (lockedAccounts[identifier]) {
      const lockTime = lockedAccounts[identifier];
      if (Date.now() - lockTime < 15 * 60 * 1000) return { error: 'Account locked. Please reset your password.' };
      setLockedAccounts(prev => { const n = { ...prev }; delete n[identifier]; return n; });
    }
    const found = MOCK_USERS.find(u => (u.email === identifier || u.mobile === identifier) && u.password === password);
    if (!found) {
      const attempts = (failedAttempts[identifier] || 0) + 1;
      setFailedAttempts(prev => ({ ...prev, [identifier]: attempts }));
      if (attempts >= 5) { setLockedAccounts(prev => ({ ...prev, [identifier]: Date.now() })); return { error: 'Account locked after 5 failed attempts.' }; }
      return { error: `Invalid credentials. ${5 - attempts} attempts remaining.` };
    }
    if (found.role === 'mechanic' && found.status === 'pending') {
      return { error: 'Your mechanic account is pending admin approval. Please wait for approval before logging in.' };
    }
    setFailedAttempts(prev => { const n = { ...prev }; delete n[identifier]; return n; });
    // Remove the old global cart key so it never bleeds into a new session
    try { localStorage.removeItem('as_cart'); } catch {}
    const token = `jwt_${Date.now()}`;
    setUser({ ...found, token });
    return { success: true, role: found.role };
  }, [failedAttempts, lockedAccounts]);

  const logout = useCallback(() => {
    try { localStorage.removeItem('as_cart'); } catch {}
    setUser(null);
  }, []);

  const updateProfile = useCallback((data: Partial<User>): { success: boolean } => {
    setUser(prev => prev ? { ...prev, ...data } : prev);
    return { success: true };
  }, []);

  // Admin can approve mechanic → update their status in MOCK_USERS
  const activateMechanicUser = useCallback((userId: number) => {
    MOCK_USERS = loadUsers();
    const u = MOCK_USERS.find(u => u.id === userId);
    if (u) {
      u.status = 'active';
      saveExtraUsers(MOCK_USERS);
    }
  }, []);

  return (
    <AuthContext.Provider value={{ user, register, login, logout, updateProfile, MOCK_USERS, activateMechanicUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = (): AuthContextType => useContext(AuthContext);
