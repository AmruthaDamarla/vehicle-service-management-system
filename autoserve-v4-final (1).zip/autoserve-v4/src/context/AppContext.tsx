import React, { createContext, useContext, useState, useEffect } from 'react';

// ─── Types ───────────────────────────────────────────────────────────────────

export interface Addon {
  id: string;
  name: string;
  price: number;
}

export interface Service {
  id: number;
  name: string;
  category: 'General' | 'Electrical' | 'Bodywork';
  description: string;
  price: number;
  duration: number;
  inclusions: string[];
  exclusions: string[];
  addons: Addon[];
  rating: number;
  reviews: number;
}

export interface StatusHistoryEntry {
  status: string;
  time: string;
  notes?: string;
  photos?: string[];
}

export interface Booking {
  id: string;
  userId: number;
  vehicleId: number;
  serviceId: number;
  serviceIds: number[];
  date: string;
  slot: string;
  status: string;
  mechanic: string | null;
  mechanicId: number | null;
  total: number;
  addons: string[];
  notes: string;
  createdAt: string;
  userName?: string;
  vehicleLabel?: string;
  serviceLabel?: string;
  statusHistory: StatusHistoryEntry[];
  photos: string[];
  userImages?: string[];
}

export interface Vehicle {
  id: number;
  userId: number;
  make: string;
  model: string;
  variant: string;
  year: number;
  fuelType: string;
  regNumber: string;
  isDefault: boolean;
}

export interface Review {
  id: number;
  userId: number;
  bookingId: string;
  serviceId: number;
  rating: number;
  comment: string;
  createdAt: string;
  userName: string;
  edited: boolean;
  editedAt?: string;
  flagged?: boolean;
  flaggedReason?: string;
  approved?: boolean;
}

export interface Message {
  id: number;
  from: 'customer' | 'mechanic';
  text: string;
  time: string;
  read: boolean;
  imageUrl?: string;
}

export interface ConversationMeta {
  muted: boolean;
  reported: boolean;
  reportReason?: string;
}

export interface Mechanic {
  id: number;
  name: string;
  email: string;
  skills: string[];
  currentLoad: number;
  availability: boolean;
  shift: string;
  rating: number;
  status: 'active' | 'inactive';
}

export interface Application {
  id: number;
  userId?: number;
  name: string;
  email: string;
  mobile: string;
  skills: string[];
  status: 'pending' | 'approved' | 'rejected';
  appliedAt: string;
}

export interface Notification {
  id: number;
  bookingId: string;
  from: 'customer' | 'mechanic' | 'system';
  text: string;
  time: string;
}

export type CreateBookingData = Omit<Booking, 'id' | 'status' | 'mechanic' | 'mechanicId' | 'createdAt' | 'statusHistory' | 'photos'>;
export type AddVehicleData = Omit<Vehicle, 'id' | 'userId'>;
export type AddReviewData = Omit<Review, 'id' | 'createdAt' | 'edited' | 'flagged' | 'approved'>;
export type ApplicationSubmitData = Omit<Application, 'id' | 'status' | 'appliedAt'>;

interface OperationResult { success: boolean }
interface OperationError { error: string }

interface AppContextType {
  services: Service[];
  bookings: Booking[];
  vehicles: Vehicle[];
  reviews: Review[];
  messages: Record<string, Message[]>;
  conversationMeta: Record<string, ConversationMeta>;
  mechanics: Mechanic[];
  applications: Application[];
  notifications: Notification[];
  addVehicle: (v: AddVehicleData, userId?: number) => OperationResult;
  updateVehicle: (id: number, data: Partial<Vehicle>) => OperationResult;
  deleteVehicle: (id: number) => OperationResult;
  setDefaultVehicle: (id: number) => void;
  createBooking: (data: CreateBookingData) => OperationResult & { bookingId: string };
  cancelBooking: (id: string) => OperationResult;
  updateBookingStatus: (id: string, status: string, notes?: string, photos?: string[]) => OperationResult;
  assignMechanic: (bookingId: string, mechanicId: number) => OperationResult;
  rescheduleBooking: (id: string, date: string, slot: string) => OperationResult | OperationError;
  addReview: (data: AddReviewData) => OperationResult | OperationError;
  editReview: (id: number, data: Partial<Review>) => OperationResult | OperationError;
  flagReview: (id: number, reason: string) => OperationResult;
  approveReview: (id: number) => OperationResult;
  deleteReview: (id: number) => OperationResult;
  sendMessage: (bookingId: string, text: string, from: 'customer' | 'mechanic', imageUrl?: string) => OperationResult;
  markMessagesRead: (bookingId: string) => void;
  reportConversation: (bookingId: string, reason: string) => OperationResult;
  muteConversation: (bookingId: string) => OperationResult;
  unmuteConversation: (bookingId: string) => OperationResult;
  dismissNotification: (id: number) => void;
  updateMechanicSkills: (mechanicId: number, skills: string[]) => OperationResult;
  deactivateMechanic: (mechanicId: number) => OperationResult;
  reactivateMechanic: (mechanicId: number) => OperationResult;
  submitApplication: (applicantData: ApplicationSubmitData) => OperationResult;
  approveApplication: (appId: number) => OperationResult | OperationError;
  rejectApplication: (appId: number) => OperationResult;
  getSuggestedMechanic: (serviceId: number) => Mechanic | null;
  getServiceAverageRating: (serviceId: number) => number;
}

// ─── Static data ──────────────────────────────────────────────────────────────

const AppContext = createContext<AppContextType>(null!);

export const SERVICES: Service[] = [
  { id: 1,  name: 'Full Service',           category: 'General',    description: 'Complete vehicle checkup including oil change, filters, fluids, brakes and tyre check.', price: 2499, duration: 180, inclusions: ['Oil change','Air filter','Oil filter','Fluid top-up','Brake inspection','Tyre rotation'], exclusions: ['Spare parts','Major repairs'], addons: [{id:'a1',name:'AC Service',price:999},{id:'a2',name:'Battery Check',price:299}], rating: 4.7, reviews: 128 },
  { id: 2,  name: 'Basic Service',          category: 'General',    description: 'Essential maintenance: oil change and safety inspection.', price: 999, duration: 90, inclusions: ['Oil change','Safety inspection','Fluid check'], exclusions: ['Spare parts','AC service'], addons: [{id:'a3',name:'Car Wash',price:299},{id:'a4',name:'Interior Clean',price:499}], rating: 4.5, reviews: 243 },
  { id: 3,  name: 'AC Service & Repair',    category: 'Electrical', description: 'Full AC diagnosis, gas refill, and cooling system check.', price: 1499, duration: 120, inclusions: ['Gas refill','Condenser clean','Cooling check'], exclusions: ['Compressor replacement'], addons: [{id:'a5',name:'Cabin Filter',price:399}], rating: 4.6, reviews: 89 },
  { id: 4,  name: 'Electrical Diagnostics', category: 'Electrical', description: 'Comprehensive computer diagnostics for electrical faults.', price: 799, duration: 60, inclusions: ['OBD scan','Fault code read','Battery test'], exclusions: ['Part replacement'], addons: [{id:'a6',name:'Wiring Fix',price:999}], rating: 4.4, reviews: 56 },
  { id: 5,  name: 'Dent & Paint',           category: 'Bodywork',   description: 'Panel beating, dent removal and paint touch-up.', price: 3999, duration: 240, inclusions: ['Dent removal','Surface prep','Paint matching','Clear coat'], exclusions: ['Full respray'], addons: [{id:'a7',name:'Polish',price:799},{id:'a8',name:'Ceramic Coat',price:2499}], rating: 4.8, reviews: 67 },
  { id: 6,  name: 'Windshield Repair',      category: 'Bodywork',   description: 'Crack and chip repair or full windshield replacement.', price: 1999, duration: 90, inclusions: ['Chip repair','Sealing','Water test'], exclusions: ['Frame damage'], addons: [{id:'a9',name:'Rain Repellent',price:299}], rating: 4.5, reviews: 44 },
  { id: 7,  name: 'Tyre Replacement',       category: 'General',    description: 'Tyre fitting, balancing and alignment for all vehicles.', price: 599, duration: 45, inclusions: ['Fitting','Balancing','TPMS reset'], exclusions: ['Tyre cost'], addons: [{id:'a10',name:'Alignment',price:499}], rating: 4.9, reviews: 312 },
  { id: 8,  name: 'Brake Service',          category: 'General',    description: 'Brake pad replacement, disc resurfacing and fluid change.', price: 1799, duration: 120, inclusions: ['Pad replacement','Disc check','Brake fluid'], exclusions: ['Caliper replacement'], addons: [{id:'a11',name:'Disc Replacement',price:2999}], rating: 4.7, reviews: 198 },
  { id: 9,  name: 'Engine Tune-Up',         category: 'General',    description: 'Spark plugs, timing check, throttle cleaning and performance test.', price: 1299, duration: 90, inclusions: ['Spark plugs','Air filter','Throttle clean','Timing check'], exclusions: ['Major engine work'], addons: [{id:'a12',name:'Fuel Injector Clean',price:499}], rating: 4.6, reviews: 74 },
  { id: 10, name: 'Battery Replacement',    category: 'Electrical', description: 'Battery health test and replacement with warranty.', price: 2999, duration: 30, inclusions: ['Health test','Battery replacement','Terminal clean'], exclusions: ['Alternator repair'], addons: [{id:'a13',name:'Trickle Charger',price:699}], rating: 4.8, reviews: 156 },
  { id: 11, name: 'Car Detailing',          category: 'Bodywork',   description: 'Deep interior and exterior cleaning, polish and wax.', price: 2499, duration: 180, inclusions: ['Exterior wash','Interior vacuum','Polish','Wax coat'], exclusions: ['Paint correction'], addons: [{id:'a14',name:'Ceramic Coat',price:3499},{id:'a15',name:'Seat Shampoo',price:799}], rating: 4.9, reviews: 201 },
  { id: 12, name: 'Suspension Check',       category: 'General',    description: 'Full suspension, steering and wheel alignment inspection.', price: 899, duration: 60, inclusions: ['Shock absorber check','Wheel alignment','Steering check'], exclusions: ['Part replacement'], addons: [{id:'a16',name:'Alignment Correction',price:699}], rating: 4.5, reviews: 88 },
  { id: 13, name: 'Oil Change (Express)',   category: 'General',    description: 'Quick synthetic or mineral oil change with filter.', price: 499, duration: 30, inclusions: ['Oil drain','New oil','Oil filter','Dipstick check'], exclusions: ['Other fluids'], addons: [{id:'a17',name:'Coolant Top-up',price:149}], rating: 4.7, reviews: 430 },
  { id: 14, name: 'Fog Light & Headlight',  category: 'Electrical', description: 'Headlight alignment, bulb replacement and fog lamp fitting.', price: 699, duration: 45, inclusions: ['Bulb check','Alignment','Fog lamp wiring'], exclusions: ['HID conversion'], addons: [{id:'a18',name:'LED Upgrade',price:1199}], rating: 4.3, reviews: 62 },
  { id: 15, name: 'Exhaust Repair',         category: 'Bodywork',   description: 'Exhaust pipe welding, muffler replacement and leak fix.', price: 1599, duration: 90, inclusions: ['Leak detection','Pipe repair','Muffler check'], exclusions: ['Catalytic converter'], addons: [{id:'a19',name:'Performance Exhaust',price:4999}], rating: 4.4, reviews: 39 },
];

// ─── Content moderation ───────────────────────────────────────────────────────

const ABUSIVE_WORDS = ['spam','scam','fraud','cheat','idiot','stupid','hate','kill','abuse','shit','fuck','damn','ass','bastard','crap'];

export function containsAbusiveContent(text: string): boolean {
  const lower = text.toLowerCase();
  return ABUSIVE_WORDS.some(w => lower.includes(w));
}

// Major status changes that trigger notifications
const MAJOR_STATUSES = new Set(['Assigned', 'In Progress', 'Quality Check', 'Ready for Pickup', 'Completed']);

// Next expected step map
export const NEXT_STEP: Record<string, string> = {
  'Booked': 'Awaiting mechanic assignment',
  'Assigned': 'Vehicle check-in by mechanic',
  'Checked-In': 'Work in progress',
  'In Progress': 'Quality inspection',
  'Quality Check': 'Ready for pickup notification',
  'Ready for Pickup': 'Vehicle collection',
  'Completed': 'Service complete',
};

function ls<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch {
    return fallback;
  }
}

const MOCK_BOOKINGS_DEFAULT: Booking[] = [
  { id:'BK001', userId:1, vehicleId:1, serviceId:1, serviceIds:[1], date:'2026-05-28', slot:'10:00 AM', status:'In Progress', mechanic:'Ravi Mechanic', mechanicId:3, total:2799, addons:['a1'], notes:'Please check the engine noise too', createdAt:'2026-05-20', userName:'Arjun Kumar', vehicleLabel:'Maruti Suzuki Swift (KA-51-AB-1234)', serviceLabel:'Full Service', statusHistory:[{status:'Booked',time:'2026-05-20 10:00'},{status:'Checked-In',time:'2026-05-28 09:45'},{status:'In Progress',time:'2026-05-28 10:15', notes:'Started oil change and filter replacement'}], photos:[] },
  { id:'BK002', userId:1, vehicleId:2, serviceId:7, serviceIds:[7], date:'2026-05-15', slot:'02:00 PM', status:'Completed', mechanic:'Ravi Mechanic', mechanicId:3, total:1098, addons:['a10'], notes:'', createdAt:'2026-05-10', userName:'Arjun Kumar', vehicleLabel:'Honda Activa (KA-09-EF-5678)', serviceLabel:'Tyre Replacement', statusHistory:[{status:'Booked',time:'2026-05-10 11:00'},{status:'Assigned',time:'2026-05-10 11:30'},{status:'Completed',time:'2026-05-15 16:00', notes:'All 4 tyres replaced and balanced'}], photos:[] },
];

const MOCK_VEHICLES_DEFAULT: Vehicle[] = [
  { id:1, userId:1, make:'Maruti Suzuki', model:'Swift', variant:'VXi', year:2021, fuelType:'Petrol', regNumber:'KA-51-AB-1234', isDefault:true },
  { id:2, userId:1, make:'Honda', model:'Activa', variant:'6G', year:2022, fuelType:'Petrol', regNumber:'KA-09-EF-5678', isDefault:false },
];

const MOCK_REVIEWS_DEFAULT: Review[] = [
  { id:1, userId:1, bookingId:'BK002', serviceId:7, rating:5, comment:'Excellent service! Very professional and quick.', createdAt:'2026-05-15', userName:'Arjun Kumar', edited:false, flagged:false, approved:true },
];

const MOCK_MESSAGES_DEFAULT: Record<string, Message[]> = {
  'BK001': [
    { id:1, from:'customer', text:'Is the service started?', time:'2026-05-28 10:05', read:true },
    { id:2, from:'mechanic', text:'Yes, we have started. Will update you soon.', time:'2026-05-28 10:20', read:true },
    { id:3, from:'mechanic', text:'Engine noise issue found - minor valve adjustment needed. No extra cost.', time:'2026-05-28 11:00', read:false },
  ],
};

const MOCK_MECHANICS_DEFAULT: Mechanic[] = [
  { id:3, name:'Ravi Mechanic',  email:'ravi@autoserve.com',   skills:['General','Electrical','Brakes'], currentLoad:2, availability:true,  shift:'08:00-18:00', rating:4.8, status:'active' },
  { id:4, name:'Suresh Kumar',   email:'suresh@autoserve.com', skills:['Bodywork','General','Tyres'],    currentLoad:1, availability:true,  shift:'09:00-19:00', rating:4.6, status:'active' },
  { id:5, name:'Priya Singh',    email:'priya@autoserve.com',  skills:['Electrical','AC Service'],       currentLoad:3, availability:false, shift:'08:00-18:00', rating:4.9, status:'active' },
];

const MOCK_APPLICATIONS_DEFAULT: Application[] = [];

function convertSlotTo24h(slot: string): string {
  const [time, period] = slot.split(' ');
  let [h, m] = time.split(':').map(Number);
  if (period === 'PM' && h !== 12) h += 12;
  if (period === 'AM' && h === 12) h = 0;
  return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':00';
}

// ─── Provider ─────────────────────────────────────────────────────────────────

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [bookings,     setBookings]     = useState<Booking[]>(() => ls('as_bookings', MOCK_BOOKINGS_DEFAULT));
  const [vehicles,     setVehicles]     = useState<Vehicle[]>(() => ls('as_vehicles', MOCK_VEHICLES_DEFAULT));
  const [reviews,      setReviews]      = useState<Review[]>(() => ls('as_reviews', MOCK_REVIEWS_DEFAULT));
  const [messages,     setMessages]     = useState<Record<string, Message[]>>(() => ls('as_messages', MOCK_MESSAGES_DEFAULT));
  const [conversationMeta, setConversationMeta] = useState<Record<string, ConversationMeta>>(() => ls('as_conv_meta', {}));
  const [mechanics,    setMechanics]    = useState<Mechanic[]>(() => ls('as_mechanics', MOCK_MECHANICS_DEFAULT));
  const [applications, setApplications] = useState<Application[]>(() => ls('as_applications', MOCK_APPLICATIONS_DEFAULT));
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => { try { localStorage.setItem('as_bookings',     JSON.stringify(bookings));     } catch {} }, [bookings]);
  useEffect(() => { try { localStorage.setItem('as_vehicles',     JSON.stringify(vehicles));     } catch {} }, [vehicles]);
  useEffect(() => { try { localStorage.setItem('as_reviews',      JSON.stringify(reviews));      } catch {} }, [reviews]);
  useEffect(() => { try { localStorage.setItem('as_messages',     JSON.stringify(messages));     } catch {} }, [messages]);
  useEffect(() => { try { localStorage.setItem('as_conv_meta',    JSON.stringify(conversationMeta)); } catch {} }, [conversationMeta]);
  useEffect(() => { try { localStorage.setItem('as_mechanics',    JSON.stringify(mechanics));    } catch {} }, [mechanics]);
  useEffect(() => { try { localStorage.setItem('as_applications', JSON.stringify(applications)); } catch {} }, [applications]);

  // ── Vehicles ──────────────────────────────────────────────────────────────
  const addVehicle = (v: AddVehicleData, userId?: number): OperationResult => {
    const newV: Vehicle = { ...v, id: Date.now(), userId: userId ?? 1 };
    if (v.isDefault) setVehicles(prev => prev.map(x => ({ ...x, isDefault: false })).concat(newV));
    else setVehicles(prev => [...prev, newV]);
    return { success: true };
  };
  const updateVehicle = (id: number, data: Partial<Vehicle>): OperationResult => {
    setVehicles(prev => prev.map(v => v.id === id ? { ...v, ...data } : v));
    return { success: true };
  };
  const deleteVehicle = (id: number): OperationResult => {
    setVehicles(prev => prev.filter(v => v.id !== id));
    return { success: true };
  };
  const setDefaultVehicle = (id: number): void => {
    setVehicles(prev => prev.map(v => ({ ...v, isDefault: v.id === id })));
  };

  // ── Bookings ──────────────────────────────────────────────────────────────
  const createBooking = (data: CreateBookingData): OperationResult & { bookingId: string } => {
    const id = `BK${String(bookings.length + 1).padStart(3, '0')}${Date.now().toString().slice(-2)}`;
    const newB: Booking = {
      id, ...data, status: 'Booked', mechanic: null, mechanicId: null,
      createdAt: new Date().toISOString().split('T')[0],
      statusHistory: [{ status: 'Booked', time: new Date().toLocaleString() }],
      photos: [],
      userImages: data.userImages ?? [],
    };
    setBookings(prev => [newB, ...prev]);
    return { success: true, bookingId: id };
  };
  const cancelBooking = (id: string): OperationResult => {
    setBookings(prev => prev.map(b => b.id === id ? { ...b, status: 'Cancelled', statusHistory: [...b.statusHistory, { status: 'Cancelled', time: new Date().toLocaleString() }] } : b));
    return { success: true };
  };
  const updateBookingStatus = (id: string, status: string, notes?: string, photos?: string[]): OperationResult => {
    const entry: StatusHistoryEntry = { status, time: new Date().toLocaleString(), notes, photos };
    setBookings(prev => prev.map(b => {
      if (b.id !== id) return b;
      const allPhotos = photos ? [...b.photos, ...photos] : b.photos;
      return { ...b, status, statusHistory: [...b.statusHistory, entry], photos: allPhotos };
    }));
    // Trigger notification for major status changes
    if (MAJOR_STATUSES.has(status)) {
      const notif: Notification = {
        id: Date.now(),
        bookingId: id,
        from: 'system',
        text: `Booking #${id}: Status updated to "${status}"${notes ? ` — ${notes}` : ''}`,
        time: new Date().toLocaleString(),
      };
      setNotifications(prev => [notif, ...prev.slice(0, 19)]);
    }
    return { success: true };
  };
  const assignMechanic = (bookingId: string, mechanicId: number): OperationResult => {
    const mech = mechanics.find(m => m.id === mechanicId);
    setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, mechanic: mech?.name ?? null, mechanicId, status: 'Assigned', statusHistory: [...b.statusHistory, { status: 'Assigned', time: new Date().toLocaleString() }] } : b));
    setMechanics(prev => prev.map(m => m.id === mechanicId ? { ...m, currentLoad: m.currentLoad + 1 } : m));
    const notif: Notification = {
      id: Date.now(),
      bookingId,
      from: 'system',
      text: `Booking #${bookingId}: Mechanic ${mech?.name ?? 'assigned'} has been assigned to your service.`,
      time: new Date().toLocaleString(),
    };
    setNotifications(prev => [notif, ...prev.slice(0, 19)]);
    return { success: true };
  };
  const rescheduleBooking = (id: string, date: string, slot: string): OperationResult | OperationError => {
    const booking = bookings.find(b => b.id === id);
    if (!booking) return { error: 'Booking not found' };
    const bt = new Date(date + 'T' + convertSlotTo24h(slot));
    if (bt < new Date(Date.now() + 3 * 60 * 60 * 1000)) return { error: 'Reschedule not allowed within 3 hours of appointment' };
    setBookings(prev => prev.map(b => b.id === id ? { ...b, date, slot, statusHistory: [...b.statusHistory, { status: `Rescheduled to ${date} ${slot}`, time: new Date().toLocaleString() }] } : b));
    return { success: true };
  };

  // ── Reviews ───────────────────────────────────────────────────────────────
  const addReview = (data: AddReviewData): OperationResult | OperationError => {
    if (reviews.find(r => r.bookingId === data.bookingId)) return { error: 'Already reviewed' };
    const isFlagged = containsAbusiveContent(data.comment);
    const newReview: Review = {
      id: Date.now(), ...data,
      createdAt: new Date().toISOString().split('T')[0],
      edited: false,
      flagged: isFlagged,
      flaggedReason: isFlagged ? 'Potentially inappropriate content — pending moderation' : undefined,
      approved: !isFlagged,
    };
    setReviews(prev => [newReview, ...prev]);
    if (isFlagged) return { success: true, ...{ flagged: true } } as OperationResult;
    return { success: true };
  };
  const editReview = (id: number, data: Partial<Review>): OperationResult | OperationError => {
    const r = reviews.find(r => r.id === id);
    if (!r) return { error: 'Not found' };
    const hrs = (Date.now() - new Date(r.createdAt + 'T00:00:00').getTime()) / (1000 * 60 * 60);
    if (hrs > 24) return { error: 'Review can only be edited within 24 hours' };
    const newComment = (data.comment ?? r.comment);
    const isFlagged = containsAbusiveContent(newComment);
    setReviews(prev => prev.map(rv => rv.id === id ? {
      ...rv, ...data, edited: true, editedAt: new Date().toISOString(),
      flagged: isFlagged,
      flaggedReason: isFlagged ? 'Potentially inappropriate content — pending moderation' : undefined,
      approved: isFlagged ? false : rv.approved,
    } : rv));
    return { success: true };
  };
  const flagReview = (id: number, reason: string): OperationResult => {
    setReviews(prev => prev.map(r => r.id === id ? { ...r, flagged: true, flaggedReason: reason, approved: false } : r));
    return { success: true };
  };
  const approveReview = (id: number): OperationResult => {
    setReviews(prev => prev.map(r => r.id === id ? { ...r, flagged: false, flaggedReason: undefined, approved: true } : r));
    return { success: true };
  };
  const deleteReview = (id: number): OperationResult => {
    setReviews(prev => prev.filter(r => r.id !== id));
    return { success: true };
  };

  // ── Messages + Notifications ──────────────────────────────────────────────
  const sendMessage = (bookingId: string, text: string, from: 'customer' | 'mechanic', imageUrl?: string): OperationResult => {
    if (containsAbusiveContent(text)) return { success: false } as unknown as OperationResult;
    const meta = conversationMeta[bookingId];
    if (meta?.muted) return { success: false } as unknown as OperationResult;
    const msg: Message = { id: Date.now(), from, text, time: new Date().toLocaleString(), read: false, imageUrl };
    setMessages(prev => ({ ...prev, [bookingId]: [...(prev[bookingId] || []), msg] }));
    const notif: Notification = { id: Date.now() + 1, bookingId, from, text: imageUrl ? '📷 Photo sent' : text, time: new Date().toLocaleString() };
    setNotifications(prev => [notif, ...prev.slice(0, 19)]);
    return { success: true };
  };
  const markMessagesRead = (bookingId: string): void => {
    setMessages(prev => ({ ...prev, [bookingId]: (prev[bookingId] || []).map(m => ({ ...m, read: true })) }));
  };
  const dismissNotification = (id: number): void => setNotifications(prev => prev.filter(n => n.id !== id));

  const reportConversation = (bookingId: string, reason: string): OperationResult => {
    setConversationMeta(prev => ({ ...prev, [bookingId]: { ...(prev[bookingId] ?? { muted: false, reported: false }), reported: true, reportReason: reason } }));
    const notif: Notification = {
      id: Date.now(),
      bookingId,
      from: 'system',
      text: `Conversation #${bookingId} has been reported: ${reason}`,
      time: new Date().toLocaleString(),
    };
    setNotifications(prev => [notif, ...prev.slice(0, 19)]);
    return { success: true };
  };
  const muteConversation = (bookingId: string): OperationResult => {
    setConversationMeta(prev => ({ ...prev, [bookingId]: { ...(prev[bookingId] ?? { muted: false, reported: false }), muted: true } }));
    return { success: true };
  };
  const unmuteConversation = (bookingId: string): OperationResult => {
    setConversationMeta(prev => ({ ...prev, [bookingId]: { ...(prev[bookingId] ?? { muted: false, reported: false }), muted: false } }));
    return { success: true };
  };

  // ── Mechanics (admin) ─────────────────────────────────────────────────────
  const updateMechanicSkills = (mechanicId: number, skills: string[]): OperationResult => {
    setMechanics(prev => prev.map(m => m.id === mechanicId ? { ...m, skills } : m));
    return { success: true };
  };
  const deactivateMechanic = (mechanicId: number): OperationResult => {
    setMechanics(prev => prev.map(m => m.id === mechanicId ? { ...m, status: 'inactive', availability: false } : m));
    return { success: true };
  };
  const reactivateMechanic = (mechanicId: number): OperationResult => {
    setMechanics(prev => prev.map(m => m.id === mechanicId ? { ...m, status: 'active' } : m));
    return { success: true };
  };

  // ── Applications ──────────────────────────────────────────────────────────
  const submitApplication = (applicantData: ApplicationSubmitData): OperationResult => {
    const app: Application = { id: Date.now(), ...applicantData, status: 'pending', appliedAt: new Date().toISOString() };
    setApplications(prev => [app, ...prev]);
    return { success: true };
  };
  const approveApplication = (appId: number): OperationResult | OperationError => {
    const app = applications.find(a => a.id === appId);
    if (!app) return { error: 'Not found' };
    const newMech: Mechanic = { id: app.userId ?? Date.now(), name: app.name, email: app.email, skills: app.skills || [], currentLoad: 0, availability: true, shift: '09:00-18:00', rating: 0, status: 'active' };
    setMechanics(prev => [...prev, newMech]);
    setApplications(prev => prev.map(a => a.id === appId ? { ...a, status: 'approved' } : a));
    return { success: true };
  };
  const rejectApplication = (appId: number): OperationResult => {
    setApplications(prev => prev.map(a => a.id === appId ? { ...a, status: 'rejected' } : a));
    return { success: true };
  };

  // ── Smart mechanic suggestion ─────────────────────────────────────────────
  const getSuggestedMechanic = (serviceId: number): Mechanic | null => {
    const svc = SERVICES.find(s => s.id === serviceId);
    if (!svc) return null;
    const active = mechanics.filter(m => m.availability && m.status === 'active');
    const skilled = active.filter(m => m.skills.includes(svc.category));
    const pool = skilled.length > 0 ? skilled : active;
    return pool.sort((a, b) => a.currentLoad - b.currentLoad)[0] ?? null;
  };

  // ── Service average rating (from user reviews) ────────────────────────────
  const getServiceAverageRating = (serviceId: number): number => {
    const serviceReviews = reviews.filter(r => r.serviceId === serviceId && r.approved !== false);
    if (serviceReviews.length === 0) return 0;
    const sum = serviceReviews.reduce((acc, r) => acc + r.rating, 0);
    return Math.round((sum / serviceReviews.length) * 10) / 10;
  };

  return (
    <AppContext.Provider value={{
      services: SERVICES, bookings, vehicles, reviews, messages, conversationMeta, mechanics,
      applications, notifications,
      addVehicle, updateVehicle, deleteVehicle, setDefaultVehicle,
      createBooking, cancelBooking, updateBookingStatus, assignMechanic, rescheduleBooking,
      addReview, editReview, flagReview, approveReview, deleteReview,
      sendMessage, markMessagesRead, reportConversation, muteConversation, unmuteConversation,
      dismissNotification,
      updateMechanicSkills, deactivateMechanic, reactivateMechanic,
      submitApplication, approveApplication, rejectApplication,
      getSuggestedMechanic, getServiceAverageRating,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = (): AppContextType => useContext(AppContext);
