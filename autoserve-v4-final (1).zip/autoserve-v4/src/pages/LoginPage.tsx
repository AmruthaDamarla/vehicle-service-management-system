import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { Car, Eye, EyeOff, ArrowRight, Lock, Phone, User, Settings, Wrench, ShieldAlert, LucideIcon } from 'lucide-react';
import './AuthPages.css';

interface RoleInfo {
  key: 'customer' | 'admin' | 'mechanic';
  label: string;
  icon: LucideIcon;
  desc: string;
  cred?: { id: string; pw: string };
}

interface LoginForm {
  identifier: string;
  password: string;
}

const ROLES: RoleInfo[] = [
  { key: 'customer', label: 'Customer', icon: User,     desc: 'Book & manage services' },
  { key: 'admin',    label: 'Admin',    icon: Settings,  desc: 'Manage operations',    cred: { id: 'admin@autoserve.com', pw: 'Admin@123' } },
  { key: 'mechanic', label: 'Mechanic', icon: Wrench,    desc: 'View & update jobs' },
];

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState<'customer' | 'admin' | 'mechanic'>('customer');
  const [form, setForm] = useState<LoginForm>({ identifier: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm(p => ({ ...p, [e.target.name]: e.target.value }));
    setError('');
  };

  const handleRoleChange = (r: 'customer' | 'admin' | 'mechanic') => {
    setRole(r);
    setForm({ identifier: '', password: '' });
    setError('');
  };

  const fillDemo = () => {
    const cred = ROLES.find(r => r.key === role)?.cred;
    if (cred) setForm({ identifier: cred.id, password: cred.pw });
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!form.identifier || !form.password) { setError('Please fill in all fields.'); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 600));
    const result = login(form.identifier, form.password);
    setLoading(false);
    if (result.error) { setError(result.error); return; }
    if (result.role !== role && role !== 'customer') {
      setError(`This account is not a ${role}. Please select the correct role.`);
      return;
    }
    toast.success('Welcome back!');
    if (result.role === 'admin') navigate('/admin');
    else if (result.role === 'mechanic') navigate('/mechanic');
    else navigate('/dashboard');
  };

  const selectedRole = ROLES.find(r => r.key === role);

  return (
    <div className="auth-page">
      <div className="auth-bg">
        <div className="auth-orb auth-orb1" />
        <div className="auth-orb auth-orb2" />
        <div className="auth-grid" />
      </div>
      <div className="auth-container">
        <div className="auth-card animate-fadeInUp">
          <div className="auth-logo">
            <Link to="/" className="brand-link">
              <div className="brand-icon"><Car size={20} /></div>
              <span className="brand-text">AutoServe</span>
            </Link>
          </div>
          <h1 className="auth-title">Welcome Back</h1>
          <p className="auth-subtitle">Sign in to your account</p>

          {/* Role Tabs */}
          <div className="auth-role-tabs">
            {ROLES.map(r => (
              <button key={r.key} className={`auth-role-tab${role === r.key ? ' active' : ''}`} onClick={() => handleRoleChange(r.key)}>
                <r.icon size={14} />{r.label}
              </button>
            ))}
          </div>

          {/* Admin note + demo creds only for admin */}
          {role === 'admin' && (
            <>
              <div className="admin-note">
                <ShieldAlert size={16} />
                Admin accounts are pre-configured. No sign-up available.
              </div>
              <div className="demo-creds">
                <div className="demo-label">Demo Credentials – Admin</div>
                <div className="demo-items">
                  <div className="demo-item" onClick={fillDemo}>
                    <span className="badge badge-orange">Admin</span>
                    <span>admin@autoserve.com / Admin@123</span>
                  </div>
                </div>
              </div>
            </>
          )}

          <form onSubmit={handleSubmit} className="auth-form">
            <div className="form-group">
              <label className="label">Email or Mobile</label>
              <div className="input-wrap">
                <Phone size={16} className="input-icon" />
                <input className={`input-field padded${error ? ' error' : ''}`} name="identifier" value={form.identifier} onChange={handleChange} placeholder="email@example.com or 9876543210" autoComplete="username" />
              </div>
            </div>
            <div className="form-group">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <label className="label">Password</label>
                <Link to="/forgot-password" className="forgot-link">Forgot password?</Link>
              </div>
              <div className="input-wrap">
                <Lock size={16} className="input-icon" />
                <input className={`input-field padded${error ? ' error' : ''}`} name="password" type={showPass ? 'text' : 'password'} value={form.password} onChange={handleChange} placeholder="Your password" autoComplete="current-password" />
                <button type="button" className="eye-btn" onClick={() => setShowPass(!showPass)}>
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            {error && <div className="error-banner">{error}</div>}
            <button type="submit" className="btn btn-primary btn-lg auth-submit" disabled={loading}>
              {loading ? <span className="spinner" /> : <><span>Sign In as {selectedRole?.label}</span><ArrowRight size={18} /></>}
            </button>
          </form>

          {role !== 'admin' && (
            <p className="auth-switch">
              Don't have an account? <Link to="/register">Create one</Link>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
