import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import toast from 'react-hot-toast';
import { CreditCard, Smartphone, Building2, Wallet, CheckCircle, ArrowLeft, Download, Shield, Lock } from 'lucide-react';
import './PaymentPage.css';

interface PaymentMethod {
  id: string;
  label: string;
  icon: React.ElementType;
  desc: string;
  options: string[];
}

interface CardForm {
  number: string;
  expiry: string;
  cvv: string;
  name: string;
}

const METHODS: PaymentMethod[] = [
  { id: 'upi', label: 'UPI', icon: Smartphone, desc: 'Pay via any UPI app', options: ['Google Pay', 'PhonePe', 'Paytm', 'BHIM'] },
  { id: 'card', label: 'Card', icon: CreditCard, desc: 'Credit or Debit card', options: [] },
  { id: 'netbanking', label: 'Net Banking', icon: Building2, desc: 'All major banks supported', options: ['SBI', 'HDFC', 'ICICI', 'Axis', 'Kotak'] },
  { id: 'wallet', label: 'Wallet', icon: Wallet, desc: 'Paytm, Amazon Pay', options: ['Paytm', 'Amazon Pay', 'Mobikwik'] },
];


const COUPONS: Record<string, { discount: number; type: 'flat' | 'percent'; desc: string }> = {
  'SAVE100':  { discount: 100,  type: 'flat',    desc: '₹100 off your order' },
  'SAVE200':  { discount: 200,  type: 'flat',    desc: '₹200 off your order' },
  'AUTO10':   { discount: 10,   type: 'percent', desc: '10% off (max ₹500)' },
  'FIRST20':  { discount: 20,   type: 'percent', desc: '20% off for first booking' },
  'WELCOME':  { discount: 50,   type: 'flat',    desc: '₹50 welcome discount' },
};


// ── Invoice generator ──────────────────────────────────────────────────────────
function generateInvoiceHTML(params: {
  receiptNo: string; bookingId: string; vehicleLabel: string;
  serviceLabel: string; date: string; slot: string;
  base: number; gst: number; discount: number; total: number;
  method: string; payDate: string;
}): string {
  const { receiptNo, bookingId, vehicleLabel, serviceLabel, date, slot, base, gst, discount, total, method, payDate } = params;
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>AutoServe Invoice ${receiptNo}</title>
<style>
  body{font-family:Arial,sans-serif;margin:0;padding:32px;color:#1e293b;background:#fff}
  .header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #f97316;padding-bottom:20px;margin-bottom:24px}
  .brand{font-size:24px;font-weight:800;color:#f97316}
  .brand span{color:#1e293b}
  .invoice-meta{text-align:right;font-size:13px;color:#64748b}
  .invoice-meta strong{color:#1e293b}
  .section{margin-bottom:20px}
  .section h3{font-size:13px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.5px;margin:0 0 10px}
  .row{display:flex;justify-content:space-between;padding:6px 0;font-size:14px;border-bottom:1px solid #f1f5f9}
  .row:last-child{border-bottom:none}
  .total-row{display:flex;justify-content:space-between;padding:12px 16px;background:#f97316;color:white;border-radius:8px;font-weight:700;font-size:16px;margin-top:12px}
  .discount-row{color:#16a34a;font-weight:600}
  .footer{margin-top:32px;padding-top:16px;border-top:1px solid #e2e8f0;font-size:12px;color:#94a3b8;text-align:center}
  .badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;background:rgba(249,115,22,0.1);color:#f97316}
</style>
</head>
<body>
<div class="header">
  <div>
    <div class="brand">Auto<span>Serve</span></div>
    <div style="font-size:12px;color:#64748b;margin-top:4px">Vehicle Service Booking System</div>
  </div>
  <div class="invoice-meta">
    <div><strong>INVOICE</strong></div>
    <div>Receipt: ${receiptNo}</div>
    <div>Date: ${payDate}</div>
    <span class="badge">PAID</span>
  </div>
</div>
<div class="section">
  <h3>Booking Details</h3>
  <div class="row"><span>Booking ID</span><strong>${bookingId}</strong></div>
  <div class="row"><span>Vehicle</span><span>${vehicleLabel}</span></div>
  <div class="row"><span>Service</span><span>${serviceLabel}</span></div>
  <div class="row"><span>Scheduled</span><span>${date} at ${slot}</span></div>
  <div class="row"><span>Payment Method</span><span>${method}</span></div>
</div>
<div class="section">
  <h3>Amount Breakdown</h3>
  <div class="row"><span>Base Amount</span><span>₹${base.toLocaleString('en-IN')}</span></div>
  <div class="row"><span>GST (18%)</span><span>₹${gst.toLocaleString('en-IN')}</span></div>
  ${discount > 0 ? `<div class="row discount-row"><span>Discount Applied</span><span>−₹${discount.toLocaleString('en-IN')}</span></div>` : ''}
</div>
<div class="total-row"><span>Total Paid</span><span>₹${total.toLocaleString('en-IN')}</span></div>
<div class="footer">
  Thank you for choosing AutoServe · PCI-DSS Compliant · This is a computer-generated invoice
</div>
</body>
</html>`;
}

function downloadInvoice(params: Parameters<typeof generateInvoiceHTML>[0]): void {
  const html = generateInvoiceHTML(params);
  const blob = new Blob([html], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `AutoServe-Invoice-${params.receiptNo}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export default function PaymentPage(): JSX.Element {
  const { bookingId } = useParams<{ bookingId?: string }>();
  const { bookings, vehicles, services, updateBookingStatus } = useApp();
  const navigate = useNavigate();
  const [method, setMethod] = useState<string>('upi');
  const [subOption, setSubOption] = useState<string>('Google Pay');
  const [cardForm, setCardForm] = useState<CardForm>({ number: '', expiry: '', cvv: '', name: '' });
  const [loading, setLoading] = useState<boolean>(false);
  const [paid, setPaid] = useState<boolean>(false);
  const [receiptNo, setReceiptNo] = useState<string>('');
  const [discount, setDiscount] = useState<number>(0);
  const [couponCode, setCouponCode] = useState<string>('');
  const [couponApplied, setCouponApplied] = useState<string>('');
  const [couponError, setCouponError] = useState<string>('');

  const booking = bookings.find(b => b.id === bookingId);
  if (!booking) return (
    <div className="page payment-page">
      <div className="container">
        <div className="not-found">Booking not found. <Link to="/bookings">Go back</Link></div>
      </div>
    </div>
  );

  const vehicle = vehicles.find(v => v.id === booking.vehicleId);
  const service = services.find(s => s.id === booking.serviceId);
  const tax = Math.round((booking.total ?? 0) * 0.18 / 1.18);
  const base = (booking.total ?? 0) - tax;

  const handlePay = async (): Promise<void> => {
    if (method === 'card') {
      if (!cardForm.number || !cardForm.expiry || !cardForm.cvv || !cardForm.name) {
        toast.error('Please fill all card details'); return;
      }
    }
    setLoading(true);
    await new Promise<void>(r => setTimeout(r, 2000));
    const receipt = `RCP${Date.now().toString().slice(-8)}`;
    setReceiptNo(receipt);
    updateBookingStatus(bookingId ?? '', 'Assigned');
    setPaid(true);
    setLoading(false);
  };

  const formatCard = (val: string): string => {
    const v = val.replace(/\D/g, '').slice(0, 16);
    return v.replace(/(.{4})/g, '$1 ').trim();
  };
  const formatExpiry = (val: string): string => {
    const v = val.replace(/\D/g, '').slice(0, 4);
    return v.length >= 3 ? `${v.slice(0, 2)}/${v.slice(2)}` : v;
  };

  if (paid) return (
    <div className="payment-success animate-fadeInUp">
      <div className="ps-card">
        <div className="ps-anim">
          <svg viewBox="0 0 80 80" className="success-svg">
            <circle cx="40" cy="40" r="36" fill="none" stroke="var(--green)" strokeWidth="4" />
            <polyline points="25,42 36,52 55,30" fill="none" stroke="var(--green)" strokeWidth="4"
              strokeLinecap="round" strokeLinejoin="round"
              strokeDasharray="48" strokeDashoffset="48"
              style={{ animation: 'checkmark 0.6s ease forwards 0.4s' }} />
          </svg>
        </div>
        <h1>Payment Successful!</h1>
        <p>Your payment has been processed securely.</p>
        <div className="ps-receipt">
          <div className="psr-row"><span>Receipt No.</span><strong>{receiptNo}</strong></div>
          <div className="psr-row"><span>Booking ID</span><strong>{bookingId}</strong></div>
          <div className="psr-row"><span>Amount Paid</span><strong>₹{Math.max(0, (booking.total ?? 0) - discount).toLocaleString('en-IN')}</strong></div>
          <div className="psr-row"><span>Method</span><strong>{METHODS.find(m => m.id === method)?.label}</strong></div>
          <div className="psr-row"><span>Date</span><strong>{new Date().toLocaleDateString('en-IN')}</strong></div>
        </div>
        <div className="ps-actions">
          <button className="btn btn-secondary" onClick={() => {
              const v = vehicles.find(vv => vv.id === booking.vehicleId);
              const svc = services.find(ss => ss.id === booking.serviceId);
              downloadInvoice({
                receiptNo,
                bookingId: bookingId ?? '',
                vehicleLabel: v ? `${v.make} ${v.model} (${v.regNumber})` : 'N/A',
                serviceLabel: svc?.name ?? 'N/A',
                date: booking.date,
                slot: booking.slot,
                base,
                gst: tax,
                discount,
                total: booking.total ?? 0,
                method: METHODS.find(m => m.id === method)?.label ?? method,
                payDate: new Date().toLocaleDateString('en-IN'),
              });
              toast.success('Invoice downloaded!');
            }}>
            <Download size={15} /> Download Invoice
          </button>
          <button className="btn btn-primary" onClick={() => navigate(`/track/${bookingId}`)}>
            <CheckCircle size={15} /> Track Service
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="page payment-page">
      <div className="container">
        <div className="page-header animate-fadeInUp">
          <div>
            <Link to="/bookings" className="back-link"><ArrowLeft size={16} /> Back to Bookings</Link>
            <h1 className="page-title" style={{ marginTop: 8 }}>Secure Payment</h1>
            <p className="page-subtitle">Booking #{bookingId}</p>
          </div>
          <div className="secure-badge"><Lock size={14} /><span>256-bit SSL Encrypted</span></div>
        </div>

        <div className="payment-layout">
          {/* Payment Methods */}
          <div className="payment-main animate-fadeInUp delay-100">
            <h2 className="section-title2">Choose Payment Method</h2>
            <div className="method-tabs">
              {METHODS.map(m => (
                <button key={m.id} className={`method-tab${method === m.id ? ' active' : ''}`} onClick={() => { setMethod(m.id); setSubOption(m.options[0] || ''); }}>
                  <m.icon size={18} />
                  <span>{m.label}</span>
                </button>
              ))}
            </div>

            <div className="method-body">
              {/* UPI */}
              {method === 'upi' && (
                <div className="method-options">
                  <p className="method-hint">Select UPI app</p>
                  <div className="option-chips">
                    {METHODS.find(m => m.id === 'upi')!.options.map(o => (
                      <button key={o} className={`option-chip${subOption === o ? ' active' : ''}`} onClick={() => setSubOption(o)}>{o}</button>
                    ))}
                  </div>
                  <div className="upi-input-section">
                    <label className="label">Or enter UPI ID</label>
                    <input className="input-field" placeholder="yourname@upi" />
                  </div>
                </div>
              )}

              {/* Card */}
              {method === 'card' && (
                <div className="card-form">
                  <div className="form-group">
                    <label className="label">Card Number</label>
                    <div className="input-wrap2">
                      <CreditCard size={16} className="fi-icon" />
                      <input className="input-field pli" placeholder="1234 5678 9012 3456" value={cardForm.number}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCardForm(p => ({ ...p, number: formatCard(e.target.value) }))} maxLength={19} />
                    </div>
                  </div>
                  <div className="form-row">
                    <div className="form-group">
                      <label className="label">Expiry Date</label>
                      <input className="input-field" placeholder="MM/YY" value={cardForm.expiry}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCardForm(p => ({ ...p, expiry: formatExpiry(e.target.value) }))} maxLength={5} />
                    </div>
                    <div className="form-group">
                      <label className="label">CVV</label>
                      <input className="input-field" placeholder="•••" type="password" value={cardForm.cvv}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCardForm(p => ({ ...p, cvv: e.target.value.slice(0, 4) }))} maxLength={4} />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="label">Cardholder Name</label>
                    <input className="input-field" placeholder="As on card" value={cardForm.name}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCardForm(p => ({ ...p, name: e.target.value }))} />
                  </div>
                  <div className="card-logos">
                    <span className="card-logo visa">VISA</span>
                    <span className="card-logo mc">MC</span>
                    <span className="card-logo rupay">RuPay</span>
                  </div>
                </div>
              )}

              {/* Net Banking */}
              {method === 'netbanking' && (
                <div className="method-options">
                  <p className="method-hint">Select your bank</p>
                  <div className="bank-grid">
                    {METHODS.find(m => m.id === 'netbanking')!.options.map(b => (
                      <button key={b} className={`bank-btn${subOption === b ? ' active' : ''}`} onClick={() => setSubOption(b)}>
                        <div className="bank-icon">{b[0]}</div>
                        <span>{b}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Wallet */}
              {method === 'wallet' && (
                <div className="method-options">
                  <p className="method-hint">Select wallet</p>
                  <div className="option-chips">
                    {METHODS.find(m => m.id === 'wallet')!.options.map(w => (
                      <button key={w} className={`option-chip${subOption === w ? ' active' : ''}`} onClick={() => setSubOption(w)}>{w}</button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <button className="btn btn-primary pay-btn" onClick={handlePay} disabled={loading}>
              {loading ? (
                <><span className="spinner" /> Processing Payment…</>
              ) : (
                <><Shield size={16} /> Pay ₹{Math.max(0, (booking.total ?? 0) - discount).toLocaleString('en-IN')} Securely</>
              )}
            </button>

            <p className="pay-note"><Lock size={12} /> Your payment info is encrypted and never stored on our servers.</p>
          </div>

          {/* Order Summary */}
          <div className="payment-sidebar animate-slideInRight delay-200">
            <div className="order-summary">
              <h3>Order Summary</h3>
              <div className="os-vehicle">
                <div className="osv-icon">🚗</div>
                <div>
                  <div className="osv-name">{vehicle?.make} {vehicle?.model}</div>
                  <div className="osv-reg">{vehicle?.regNumber}</div>
                </div>
              </div>
              <div className="os-divider" />
              <div className="os-service">{service?.name}</div>
              <div className="os-date">📅 {booking.date} · {booking.slot}</div>
              <div className="os-divider" />
              <div className="os-rows">
                <div className="os-row"><span>Base Amount</span><span>₹{base.toLocaleString('en-IN')}</span></div>
                <div className="os-row"><span>GST (18%)</span><span>₹{tax.toLocaleString('en-IN')}</span></div>
              </div>
              {/* Coupon / Discount */}
              <div style={{ margin: '12px 0' }}>
                {!couponApplied ? (
                  <>
                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 6 }}>Apply Coupon</div>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <input
                        className="input-field"
                        style={{ flex: 1, fontSize: 13, padding: '8px 12px', textTransform: 'uppercase' }}
                        placeholder="Enter coupon code"
                        value={couponCode}
                        onChange={e => { setCouponCode(e.target.value.toUpperCase()); setCouponError(''); }}
                      />
                      <button
                        className="btn btn-secondary btn-sm"
                        style={{ whiteSpace: 'nowrap', padding: '0 14px' }}
                        onClick={() => {
                          const c = COUPONS[couponCode.trim()];
                          if (!c) { setCouponError('Invalid coupon code.'); return; }
                          const disc = c.type === 'flat' ? c.discount : Math.min(Math.round((booking.total ?? 0) * c.discount / 100), 500);
                          setDiscount(disc);
                          setCouponApplied(couponCode.trim());
                          setCouponError('');
                          toast.success(`Coupon applied! ${c.desc}`);
                        }}
                      >Apply</button>
                    </div>
                    {couponError && <p style={{ fontSize: 12, color: 'var(--red)', margin: '4px 0 0' }}>{couponError}</p>}
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 6 }}>
                      Try: SAVE100, SAVE200, AUTO10, FIRST20, WELCOME
                    </div>
                  </>
                ) : (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'rgba(22,163,74,0.08)', border: '1px solid rgba(22,163,74,0.25)', borderRadius: 8, padding: '8px 12px' }}>
                    <div>
                      <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--green)' }}>🎉 {couponApplied} Applied</div>
                      <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>−₹{discount.toLocaleString('en-IN')} saved</div>
                    </div>
                    <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--red)', fontSize: 12, fontWeight: 600 }}
                      onClick={() => { setDiscount(0); setCouponApplied(''); setCouponCode(''); }}>Remove</button>
                  </div>
                )}
              </div>
              <div className="os-divider" />
              <div className="os-total">
                <span>Total</span>
                <span>₹{Math.max(0, (booking.total ?? 0) - discount).toLocaleString('en-IN')}</span>
              </div>
              <div className="os-security">
                <Shield size={14} /> <span>PCI-DSS Compliant Checkout</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
