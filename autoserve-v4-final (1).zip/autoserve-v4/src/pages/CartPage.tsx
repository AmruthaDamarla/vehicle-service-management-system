import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { ShoppingCart, X, Wrench, Clock, Star, ArrowRight, Plus } from 'lucide-react';
import './CartPage.css';

type CartUpdater = number[] | ((prev: number[]) => number[]);

interface CartPageProps {
  cart: number[];
  setCart: (fn: CartUpdater) => void;
}

export default function CartPage({ cart, setCart }: CartPageProps) {
  const { services } = useApp();
  const navigate = useNavigate();

  const cartServices = services.filter(s => cart.includes(s.id));
  const subtotal = cartServices.reduce((sum, s) => sum + s.price, 0);
  const tax   = Math.round(subtotal * 0.18);
  const total = subtotal + tax;

  const remove = (id: number) => setCart(prev => prev.filter(x => x !== id));

  const handleProceed = () => {
    if (cartServices.length === 0) return;
    navigate('/book', { state: { serviceIds: cart } });
  };

  return (
    <div className="page cart-page">
      <div className="container">
        <div className="page-header animate-fadeInUp">
          <div>
            <h1 className="page-title">My Cart</h1>
            <p className="page-subtitle">{cartServices.length} service{cartServices.length !== 1 ? 's' : ''} selected</p>
          </div>
          <Link to="/services" className="btn btn-secondary"><Plus size={16} />Add More Services</Link>
        </div>

        {cartServices.length === 0 ? (
          <div className="cart-empty animate-fadeInUp">
            <ShoppingCart size={56} />
            <h3>Your cart is empty</h3>
            <p>Browse our services and add them to your cart</p>
            <Link to="/services" className="btn btn-primary"><Plus size={16} />Browse Services</Link>
          </div>
        ) : (
          <div className="cart-layout animate-fadeInUp delay-100">
            <div className="cart-items">
              {cartServices.map(s => (
                <div key={s.id} className="cart-item">
                  <div className="ci-icon"><Wrench size={22} /></div>
                  <div className="ci-body">
                    <div className="ci-name">{s.name}</div>
                    <div className="ci-meta">
                      <span className={`badge badge-${s.category === 'General' ? 'green' : s.category === 'Electrical' ? 'blue' : 'orange'}`}>{s.category}</span>
                      <span><Clock size={12} /> {s.duration >= 60 ? `${Math.floor(s.duration / 60)}h ${s.duration % 60 ? s.duration % 60 + 'm' : ''}` : `${s.duration}m`}</span>
                      <span><Star size={12} className="star" /> {s.rating}</span>
                    </div>
                    <div className="ci-desc">{s.description}</div>
                  </div>
                  <div className="ci-right">
                    <div className="ci-price">₹{s.price.toLocaleString('en-IN')}</div>
                    <button className="ci-remove" onClick={() => remove(s.id)} title="Remove"><X size={16} /></button>
                  </div>
                </div>
              ))}
            </div>

            <div className="cart-summary">
              <div className="cs-card">
                <h3>Order Summary</h3>
                <div className="cs-rows">
                  {cartServices.map(s => (
                    <div key={s.id} className="cs-row"><span>{s.name}</span><span>₹{s.price.toLocaleString('en-IN')}</span></div>
                  ))}
                  <div className="cs-row"><span>GST (18%)</span><span>₹{tax.toLocaleString('en-IN')}</span></div>
                  <div className="cs-divider" />
                  <div className="cs-row total"><span>Total</span><span>₹{total.toLocaleString('en-IN')}</span></div>
                </div>
                <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 20 }} onClick={handleProceed}>
                  Proceed to Slot Booking <ArrowRight size={16} />
                </button>
                <Link to="/services" className="btn btn-secondary" style={{ width: '100%', justifyContent: 'center', marginTop: 10 }}>
                  <Plus size={14} /> Add More
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
