import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import toast from 'react-hot-toast';
import { Car, Eye, EyeOff, ArrowRight, User, Mail, Phone, Lock, CheckCircle, Wrench, X, Clock } from 'lucide-react';
import './AuthPages.css';

const SKILL_OPTIONS = ['General', 'Electrical', 'Bodywork', 'AC Service', 'Tyres', 'Brakes'];

interface RegisterForm {
  name: string;
  email: string;
  mobile: string;
  password: string;
  confirm: string;
  skills: string[];
}

type FormErrors = Partial<Record<keyof RegisterForm, string>>;

const validate = (form: RegisterForm, role: string): FormErrors => {
  const e: FormErrors = {};
  if (!form.name.trim()) e.name = 'Full name is required';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Enter a valid email address';
  if (!/^[6-9]\d{9}$/.test(form.mobile)) e.mobile = 'Enter a valid 10-digit mobile number';
  if (form.password.length < 8) e.password = 'Password must be at least 8 characters';
  else if (!/[A-Z]/.test(form.password)) e.password = 'Must contain at least 1 uppercase letter';
  else if (!/[0-9]/.test(form.password)) e.password = 'Must contain at least 1 number';
  if (form.password !== form.confirm) e.confirm = 'Passwords do not match';
  if (role === 'mechanic' && form.skills.length === 0) e.skills = 'Select at least one skill';
  return e;
};

const PWD_CHECKS: { label: string; test: (p: string) => boolean }[] = [
  { label: '8+ characters', test: p => p.length >= 8 },
  { label: '1 uppercase',   test: p => /[A-Z]/.test(p) },
  { label: '1 number',      test: p => /[0-9]/.test(p) },
];

export default function RegisterPage() {
  const { register } = useAuth();
  const { submitApplication } = useApp();
  const navigate = useNavigate();
  const [signupRole, setSignupRole] = useState<'customer' | 'mechanic'>('customer');
  const [form, setForm] = useState<RegisterForm>({ name: '', email: '', mobile: '', password: '', confirm: '', skills: [] });
  const [errors, setErrors] = useState<FormErrors>({});
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [pendingSuccess, setPendingSuccess] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm(p => ({ ...p, [e.target.name]: e.target.value }));
    const key = e.target.name as keyof RegisterForm;
    if (errors[key]) setErrors(p => ({ ...p, [key]: '' }));
  };

  const toggleSkill = (skill: string) => {
    setForm(p => ({ ...p, skills: p.skills.includes(skill) ? p.skills.filter(s => s !== skill) : [...p.skills, skill] }));
    setErrors(p => ({ ...p, skills: '' }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const errs = validate(form, signupRole);
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 800));
    const result = register(
      { name: form.name, email: form.email, mobile: form.mobile, password: form.password, role: signupRole, skills: form.skills },
      submitApplication
    );
    setLoading(false);
    if (result.error) { setErrors({ email: result.error }); return; }
    if (result.pending) { setPendingSuccess(true); return; }
    toast.success('Account created! Please log in to continue. 🎉');
    navigate('/login');
  };

  if (pendingSuccess) return (
    <div className="auth-page">
      <div className="auth-bg"><div className="auth-orb auth-orb1" /><div className="auth-orb auth-orb2" /><div className="auth-grid" /></div>
      <div className="auth-container">
        <div className="auth-card animate-fadeInUp" style={{ textAlign: 'center' }}>
          <div style={{ width: 64, height: 64, background: 'rgba(249,115,22,0.1)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px' }}>
            <Clock size={28} color="var(--accent)" />
          </div>
          <h2 style={{ fontFamily: 'var(--font-head)', fontSize: 22, fontWeight: 800, marginBottom: 8 }}>Application Submitted!</h2>
          <p style={{ color: 'var(--text-secondary)', marginBottom: 20, lineHeight: 1.6 }}>
            Your mechanic account is <strong>pending admin approval</strong>. Once the admin reviews and approves your application, you will be able to log in and receive jobs.
          </p>
          <div style={{ background: 'rgba(79,70,229,0.06)', border: '1px solid rgba(79,70,229,0.2)', borderRadius: 10, padding: '12px 16px', marginBottom: 24, fontSize: 13, color: 'var(--blue)' }}>
            📋 Admin will verify your skills and credentials before activation.
          </div>
          <Link to="/login" className="btn btn-primary" style={{ display: 'inline-flex', justifyContent: 'center' }}>Back to Login</Link>
        </div>
      </div>
    </div>
  );

  return (
    <div className="auth-page">
      <div className="auth-bg"><div className="auth-orb auth-orb1" /><div className="auth-orb auth-orb2" /><div className="auth-grid" /></div>
      <div className="auth-container">
        <div className="auth-card animate-fadeInUp">
          <div className="auth-logo">
            <Link to="/" className="brand-link">
              <div className="brand-icon"><Car size={20} /></div>
              <span className="brand-text">AutoServe</span>
            </Link>
          </div>
          <h1 className="auth-title">Create Account</h1>
          <p className="auth-subtitle">Choose your account type to get started</p>

          <div className="signup-role-selector">
            <div className={`signup-role-card${signupRole === 'customer' ? ' selected' : ''}`} onClick={() => setSignupRole('customer')}>
              <div className="src-icon"><User size={20} /></div>
              <div className="src-label">Customer</div>
              <div className="src-desc">Book vehicle services</div>
            </div>
            <div className={`signup-role-card${signupRole === 'mechanic' ? ' selected' : ''}`} onClick={() => setSignupRole('mechanic')}>
              <div className="src-icon"><Wrench size={20} /></div>
              <div className="src-label">Mechanic</div>
              <div className="src-desc">Apply to work on jobs</div>
            </div>
          </div>

          {signupRole === 'mechanic' && (
            <div className="admin-note" style={{ marginBottom: 16 }}>
              ⚠️ Mechanic accounts require admin approval before you can log in.
            </div>
          )}

          <form onSubmit={handleSubmit} className="auth-form">
            <div className="form-group">
              <label className="label">Full Name</label>
              <div className="input-wrap"><User size={16} className="input-icon" />
                <input className={`input-field padded${errors.name ? ' error' : ''}`} name="name" value={form.name} onChange={handleChange} placeholder="Your full name" />
              </div>
              {errors.name && <p className="error-text">{errors.name}</p>}
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="label">Email</label>
                <div className="input-wrap"><Mail size={16} className="input-icon" />
                  <input className={`input-field padded${errors.email ? ' error' : ''}`} name="email" type="email" value={form.email} onChange={handleChange} placeholder="you@example.com" />
                </div>
                {errors.email && <p className="error-text">{errors.email}</p>}
              </div>
              <div className="form-group">
                <label className="label">Mobile Number</label>
                <div className="input-wrap"><Phone size={16} className="input-icon" />
                  <input className={`input-field padded${errors.mobile ? ' error' : ''}`} name="mobile" value={form.mobile} onChange={handleChange} placeholder="9876543210" maxLength={10} />
                </div>
                {errors.mobile && <p className="error-text">{errors.mobile}</p>}
              </div>
            </div>
            <div className="form-group">
              <label className="label">Password</label>
              <div className="input-wrap"><Lock size={16} className="input-icon" />
                <input className={`input-field padded${errors.password ? ' error' : ''}`} name="password" type={showPass ? 'text' : 'password'} value={form.password} onChange={handleChange} placeholder="Min 8 chars, 1 uppercase, 1 number" />
                <button type="button" className="eye-btn" onClick={() => setShowPass(!showPass)}>{showPass ? <EyeOff size={16} /> : <Eye size={16} />}</button>
              </div>
              {errors.password && <p className="error-text">{errors.password}</p>}
              {form.password && (
                <div className="pwd-checks">
                  {PWD_CHECKS.map(c => (
                    <span key={c.label} className={`pwd-check${c.test(form.password) ? ' pass' : ''}`}>
                      <CheckCircle size={12} />{c.label}
                    </span>
                  ))}
                </div>
              )}
            </div>
            <div className="form-group">
              <label className="label">Confirm Password</label>
              <div className="input-wrap"><Lock size={16} className="input-icon" />
                <input className={`input-field padded${errors.confirm ? ' error' : ''}`} name="confirm" type="password" value={form.confirm} onChange={handleChange} placeholder="Re-enter password" />
              </div>
              {errors.confirm && <p className="error-text">{errors.confirm}</p>}
            </div>
            {signupRole === 'mechanic' && (
              <div className="form-group">
                <label className="label">Your Skills <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}>(select all that apply)</span></label>
                <div className="skill-options">
                  {SKILL_OPTIONS.map(s => (
                    <button key={s} type="button" className={`skill-opt-btn${form.skills.includes(s) ? ' active' : ''}`} onClick={() => toggleSkill(s)}>
                      {form.skills.includes(s) && <CheckCircle size={11} style={{ display: 'inline', marginRight: 4 }} />}{s}
                    </button>
                  ))}
                </div>
                {form.skills.length > 0 && (
                  <div className="skills-input-wrap">
                    {form.skills.map(s => (
                      <span key={s} className="skill-chip">{s}<button type="button" onClick={() => toggleSkill(s)}><X size={10} /></button></span>
                    ))}
                  </div>
                )}
                {errors.skills && <p className="error-text">{errors.skills}</p>}
              </div>
            )}
            <button type="submit" className="btn btn-primary btn-lg auth-submit" disabled={loading}>
              {loading ? <span className="spinner" /> : <><span>{signupRole === 'mechanic' ? 'Submit Application' : 'Create Account'}</span><ArrowRight size={18} /></>}
            </button>
          </form>
          <p className="auth-switch">Already have an account? <Link to="/login">Sign in</Link></p>
        </div>
      </div>
    </div>
  );
}
