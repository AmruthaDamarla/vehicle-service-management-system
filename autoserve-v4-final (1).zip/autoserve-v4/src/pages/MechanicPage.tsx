import React, { useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Wrench, Clock, CheckCircle, MessageCircle, RefreshCw, X, Camera, FileText, Upload } from 'lucide-react';
import { Booking } from '../context/AppContext';
import './MechanicPage.css';

const STATUS_COLOR: Record<string, string> = {
  Assigned: 'badge-orange', 'Checked-In': 'badge-yellow', 'In Progress': 'badge-orange',
  'Quality Check': 'badge-yellow', 'Ready for Pickup': 'badge-green', Completed: 'badge-green'
};
const NEXT_STATUS: Record<string, string> = {
  Assigned: 'Checked-In', 'Checked-In': 'In Progress', 'In Progress': 'Quality Check',
  'Quality Check': 'Ready for Pickup', 'Ready for Pickup': 'Completed'
};
const NEXT_STEP_DESC: Record<string, string> = {
  Assigned: 'Check the vehicle in when the customer arrives',
  'Checked-In': 'Begin service work on the vehicle',
  'In Progress': 'Perform quality check when work is done',
  'Quality Check': 'Mark ready for pickup after inspection passes',
  'Ready for Pickup': 'Mark completed once customer collects vehicle',
};

interface StatusModal {
  booking: Booking;
  nextStatus: string;
}

export default function MechanicPage(): JSX.Element {
  const { user } = useAuth();
  const { bookings, vehicles, services, updateBookingStatus } = useApp();
  const navigate = useNavigate();
  const [tab, setTab] = useState<'active' | 'completed'>('active');
  const [statusModal, setStatusModal] = useState<StatusModal | null>(null);
  const [statusNotes, setStatusNotes] = useState<string>('');
  const [statusPhotos, setStatusPhotos] = useState<string[]>([]);
  const photoInputRef = useRef<HTMLInputElement>(null);

  const myJobs = bookings.filter(b => b.mechanicId === user?.id || b.mechanicId === 3);
  const activeJobs = myJobs.filter(b => !['Completed', 'Cancelled'].includes(b.status));
  const completedJobs = myJobs.filter(b => b.status === 'Completed');

  const displayed: Booking[] = tab === 'active' ? activeJobs : completedJobs;

  const openStatusModal = (booking: Booking): void => {
    const next = NEXT_STATUS[booking.status];
    if (!next) return;
    setStatusModal({ booking, nextStatus: next });
    setStatusNotes('');
    setStatusPhotos([]);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const files = Array.from(e.target.files ?? []);
    files.forEach(file => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const result = ev.target?.result as string;
        if (result) setStatusPhotos(prev => [...prev, result]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleConfirmStatus = (): void => {
    if (!statusModal) return;
    updateBookingStatus(statusModal.booking.id, statusModal.nextStatus, statusNotes.trim() || undefined, statusPhotos.length > 0 ? statusPhotos : undefined);
    toast.success(`Status updated to "${statusModal.nextStatus}"`);
    setStatusModal(null);
    setStatusNotes('');
    setStatusPhotos([]);
  };

  const getVehicle = (id: string | number) => vehicles.find(v => v.id === id);
  const getService = (id: string | number) => services.find(s => s.id === id);

  return (
    <div className="page mechanic-page">
      <div className="container">
        <div className="page-header animate-fadeInUp">
          <div>
            <h1 className="page-title">My Jobs</h1>
            <p className="page-subtitle">Welcome back, {user?.name?.split(' ')[0]} 👋</p>
            {user?.skills && user.skills.length > 0 && (
              <div style={{ display: 'flex', gap: '6px', marginTop: '8px', flexWrap: 'wrap' }}>
                {user.skills.map((s: string) => (
                  <span key={s} style={{ background: 'rgba(79,70,229,0.1)', color: 'var(--blue)', fontSize: '11px', padding: '2px 10px', borderRadius: '20px', fontWeight: 600 }}>{s}</span>
                ))}
              </div>
            )}
          </div>
          <div className="mech-stats-mini">
            <div className="msm-item"><span>{activeJobs.length}</span><span>Active</span></div>
            <div className="msm-divider" />
            <div className="msm-item"><span>{completedJobs.length}</span><span>Done</span></div>
          </div>
        </div>

        <div className="tab-bar animate-fadeInUp delay-100">
          <button className={`tab-btn${tab === 'active' ? ' active' : ''}`} onClick={() => setTab('active')}>
            Active Jobs <span className="tab-count">{activeJobs.length}</span>
          </button>
          <button className={`tab-btn${tab === 'completed' ? ' active' : ''}`} onClick={() => setTab('completed')}>
            Completed <span className="tab-count">{completedJobs.length}</span>
          </button>
        </div>

        {displayed.length === 0 ? (
          <div className="mechanic-empty animate-fadeInUp delay-200">
            <Wrench size={48} />
            <h3>No {tab} jobs</h3>
            <p>{tab === 'active' ? 'You have no active jobs assigned.' : 'No completed jobs yet.'}</p>
          </div>
        ) : (
          <div className="mechanic-jobs animate-fadeInUp delay-200">
            {displayed.map((b, i) => {
              const veh = getVehicle(b.vehicleId);
              const svc = getService(b.serviceId);
              const nextStatus = NEXT_STATUS[b.status];
              const lastHistory = b.statusHistory[b.statusHistory.length - 1];
              const lastUpdated = lastHistory?.time;
              return (
                <div key={b.id} className="job-card" style={{ animationDelay: `${i * 0.06}s` }}>
                  <div className="jc-header">
                    <div className="jc-id">#{b.id}</div>
                    <span className={`badge ${STATUS_COLOR[b.status] ?? 'badge-blue'}`}>{b.status}</span>
                  </div>
                  <div className="jc-body">
                    <div className="jc-main">
                      <div className="jc-service">{svc?.name}</div>
                      <div className="jc-vehicle">{veh?.make} {veh?.model} {veh?.variant} · <span className="mono-sm">{veh?.regNumber}</span></div>
                      <div className="jc-meta">
                        <span><Clock size={12} /> {b.date} at {b.slot}</span>
                        <span>⛽ {veh?.fuelType}</span>
                      </div>
                      {b.notes && <div className="jc-notes">📝 {b.notes}</div>}
                      {lastUpdated && (
                        <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>
                          🕐 Last updated: {lastUpdated}
                        </div>
                      )}
                      {nextStatus && NEXT_STEP_DESC[b.status] && (
                        <div style={{ fontSize: 11, color: 'var(--blue)', marginTop: 4, fontWeight: 600 }}>
                          ➡ Next: {NEXT_STEP_DESC[b.status]}
                        </div>
                      )}
                      {/* Status history notes */}
                      {lastHistory?.notes && (
                        <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 4, background: 'rgba(79,70,229,0.05)', padding: '4px 8px', borderRadius: 6 }}>
                          <FileText size={11} style={{ display: 'inline', marginRight: 4 }} />
                          {lastHistory.notes}
                        </div>
                      )}
                      {/* Status photos */}
                      {b.photos && b.photos.length > 0 && (
                        <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                          {b.photos.slice(0, 3).map((ph, pi) => (
                            <img key={pi} src={ph} alt="status" style={{ width: 56, height: 56, objectFit: 'cover', borderRadius: 6, border: '1px solid var(--border)' }} />
                          ))}
                          {b.photos.length > 3 && (
                            <div style={{ width: 56, height: 56, background: 'var(--surface)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, color: 'var(--text-muted)', border: '1px solid var(--border)' }}>
                              +{b.photos.length - 3}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="jc-price">₹{b.total?.toLocaleString('en-IN')}</div>
                  </div>
                  <div className="jc-actions">
                    <Link to={`/messages/${b.id}`} className="btn btn-secondary btn-sm"><MessageCircle size={14} />Chat</Link>
                    <Link to={`/track/${b.id}`} className="btn btn-secondary btn-sm">View Track</Link>
                    {nextStatus && (
                      <button className="btn btn-primary btn-sm" onClick={() => openStatusModal(b)}>
                        <RefreshCw size={13} /> Mark {nextStatus}
                      </button>
                    )}
                    {b.status === 'Completed' && (
                      <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'var(--green)' }}>
                        <CheckCircle size={14} /> Completed
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ── Status Update Modal ── */}
      {statusModal && (
        <div className="modal-overlay" onClick={() => setStatusModal(null)}>
          <div className="modal animate-fadeInUp" style={{ maxWidth: 500 }} onClick={(e: React.MouseEvent) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h2>Update Status</h2>
                <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>
                  Booking #{statusModal.booking.id} → <strong>{statusModal.nextStatus}</strong>
                </p>
              </div>
              <button className="modal-close" onClick={() => setStatusModal(null)}><X size={18} /></button>
            </div>

            {/* Status badge preview */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16, padding: '10px 14px', background: 'var(--surface)', borderRadius: 10, border: '1px solid var(--border)' }}>
              <RefreshCw size={16} color="var(--accent)" />
              <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Marking as:</span>
              <span className="badge badge-orange">{statusModal.nextStatus}</span>
            </div>

            {/* Optional notes */}
            <div className="form-group" style={{ marginBottom: 16 }}>
              <label className="label">
                <FileText size={14} style={{ display: 'inline', marginRight: 6 }} />
                Notes (optional)
              </label>
              <textarea
                className="input-field"
                style={{ resize: 'vertical', minHeight: 80, fontFamily: 'inherit', fontSize: 14 }}
                placeholder="Add any notes about this status update (visible to customer)..."
                value={statusNotes}
                onChange={(e) => setStatusNotes(e.target.value)}
              />
            </div>

            {/* Photo upload */}
            <div className="form-group" style={{ marginBottom: 20 }}>
              <label className="label">
                <Camera size={14} style={{ display: 'inline', marginRight: 6 }} />
                Photos (optional)
              </label>
              <input
                ref={photoInputRef}
                type="file"
                accept="image/*"
                multiple
                style={{ display: 'none' }}
                onChange={handlePhotoUpload}
              />
              <button
                type="button"
                className="btn btn-secondary"
                style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 10 }}
                onClick={() => photoInputRef.current?.click()}
              >
                <Upload size={14} /> Upload Photos
              </button>
              {statusPhotos.length > 0 && (
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {statusPhotos.map((ph, i) => (
                    <div key={i} style={{ position: 'relative' }}>
                      <img src={ph} alt="upload" style={{ width: 64, height: 64, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)' }} />
                      <button
                        type="button"
                        style={{ position: 'absolute', top: -6, right: -6, background: 'var(--red)', border: 'none', borderRadius: '50%', width: 18, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'white' }}
                        onClick={() => setStatusPhotos(prev => prev.filter((_, idx) => idx !== i))}
                      >
                        <X size={10} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={() => setStatusModal(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleConfirmStatus}>
                <CheckCircle size={15} /> Confirm Update
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
