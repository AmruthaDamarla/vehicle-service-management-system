import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { Car, Calendar, Clock, CheckCircle, Plus, ArrowRight, MessageCircle, Star, TrendingUp, Wrench, X } from 'lucide-react';
import './DashboardPage.css';

const STATUS_COLOR: Record<string, string> = {
  Booked: 'badge-blue', Assigned: 'badge-orange', 'Checked-In': 'badge-yellow',
  'In Progress': 'badge-orange', 'Quality Check': 'badge-yellow',
  'Ready for Pickup': 'badge-green', Completed: 'badge-green', Cancelled: 'badge-red',
};

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Morning';
  if (h < 17) return 'Afternoon';
  return 'Evening';
}

export default function DashboardPage() {
  const { user } = useAuth();
  const { bookings, vehicles, services, reviews, messages } = useApp();
  const navigate = useNavigate();

  // ── New message popup ──────────────────────────────────────────────────────
  interface PopupMsg { id: number; bookingId: string; text: string; from: string; }
  const [msgPopup, setMsgPopup] = useState<PopupMsg | null>(null);
  const prevMsgCount = useRef(0);
  const isCustomer = user?.role === 'customer';
  const isMechanic = user?.role === 'mechanic';

  useEffect(() => {
    // Customer sees mechanic messages; mechanic sees customer messages
    const relevantFrom = isCustomer ? 'mechanic' : isMechanic ? 'customer' : null;
    if (!relevantFrom) return;
    const allMsgs = Object.entries(messages).flatMap(([bkId, msgs]) =>
      msgs.filter(m => m.from === relevantFrom && !m.read).map(m => ({ ...m, bookingId: bkId }))
    );
    if (allMsgs.length > prevMsgCount.current) {
      const newest = allMsgs[allMsgs.length - 1];
      setMsgPopup({ id: newest.id, bookingId: newest.bookingId, text: newest.text, from: newest.from });
      const t = setTimeout(() => setMsgPopup(null), 5000);
      prevMsgCount.current = allMsgs.length;
      return () => clearTimeout(t);
    }
    prevMsgCount.current = allMsgs.length;
  }, [messages, isCustomer, isMechanic]);
  // ── End popup ──────────────────────────────────────────────────────────────

  const myBookings    = bookings.filter(b => b.userId === user?.id);
  const activeBookings    = myBookings.filter(b => !['Completed', 'Cancelled'].includes(b.status));
  const completedBookings = myBookings.filter(b => b.status === 'Completed');
  const myVehicles    = vehicles.filter(v => v.userId === user?.id);
  const unread        = Object.values(messages).flat().filter(m => !m.read && m.from !== 'customer').length;

  const getService = (id: number) => services.find(s => s.id === id);
  const getVehicle = (id: number) => vehicles.find(v => v.id === id);

  const stats = [
    { icon: Calendar,       label: 'Active Bookings',  value: activeBookings.length,    color: 'orange', link: '/bookings' },
    { icon: CheckCircle,    label: 'Completed',        value: completedBookings.length, color: 'green',  link: '/bookings' },
    { icon: Car,            label: 'My Vehicles',      value: myVehicles.length,        color: 'blue',   link: '/vehicles' },
    { icon: MessageCircle,  label: 'Unread Messages',  value: unread,                   color: unread > 0 ? 'orange' : 'muted', link: '/messages' },
  ] as const;

  return (
    <div className="page dashboard-page">
      <div className="container">
        <div className="dash-header animate-fadeInUp">
          <div>
            <h1 className="dash-greeting">Good {getGreeting()}, <span>{user?.name?.split(' ')[0]}</span> 👋</h1>
            <p className="dash-subtitle">Here's what's happening with your vehicles today.</p>
          </div>
          <Link to="/book" className="btn btn-primary"><Plus size={16} />Book a Service</Link>
        </div>

        {/* Stats */}
        <div className="dash-stats animate-fadeInUp delay-100">
          {stats.map(s => (
            <Link to={s.link} key={s.label} className={`stat-card color-${s.color}`}>
              <div className="stat-icon-wrap"><s.icon size={22} /></div>
              <div className="stat-info">
                <div className="stat-num">{s.value}</div>
                <div className="stat-lbl">{s.label}</div>
              </div>
              <ArrowRight size={16} className="stat-arrow" />
            </Link>
          ))}
        </div>

        <div className="dash-grid">
          {/* Active Bookings */}
          <div className="animate-fadeInUp delay-200">
            <div className="section-head">
              <h2>Active Bookings</h2>
              <Link to="/bookings" className="view-all">View all <ArrowRight size={14} /></Link>
            </div>
            {activeBookings.length === 0 ? (
              <div className="empty-state">
                <Wrench size={40} />
                <p>No active bookings</p>
                <Link to="/book" className="btn btn-primary btn-sm"><Plus size={14} />Book Now</Link>
              </div>
            ) : (
              <div className="booking-list">
                {activeBookings.slice(0, 3).map(b => {
                  const svc = getService(b.serviceId);
                  const veh = getVehicle(b.vehicleId);
                  return (
                    <Link to={`/track/${b.id}`} key={b.id} className="booking-item">
                      <div className="bi-left">
                        <div className="bi-icon"><Wrench size={16} /></div>
                        <div>
                          <div className="bi-name">{svc?.name}</div>
                          <div className="bi-detail">{veh?.make} {veh?.model} · {b.date}</div>
                        </div>
                      </div>
                      <span className={`badge ${STATUS_COLOR[b.status] || 'badge-blue'}`}>{b.status}</span>
                    </Link>
                  );
                })}
              </div>
            )}
          </div>

          {/* My Vehicles */}
          <div className="animate-fadeInUp delay-300">
            <div className="section-head">
              <h2>My Vehicles</h2>
              <Link to="/vehicles" className="view-all">Manage <ArrowRight size={14} /></Link>
            </div>
            {myVehicles.length === 0 ? (
              <div className="empty-state">
                <Car size={40} />
                <p>No vehicles added yet</p>
                <Link to="/vehicles" className="btn btn-primary btn-sm"><Plus size={14} />Add Vehicle</Link>
              </div>
            ) : (
              <div className="vehicle-list">
                {myVehicles.map(v => (
                  <div key={v.id} className="vehicle-item">
                    <div className="vi-icon"><Car size={20} /></div>
                    <div>
                      <div className="vi-name">{v.make} {v.model}</div>
                      <div className="vi-detail">{v.year} · {v.fuelType} · {v.regNumber}</div>
                    </div>
                    {v.isDefault && <span className="badge badge-green">Default</span>}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Actions */}
          <div className="animate-fadeInUp delay-200">
            <div className="section-head"><h2>Quick Actions</h2></div>
            <div className="quick-actions">
              {[
                { icon: Plus,         label: 'Book a Service',   to: '/book',      color: 'orange', badge: 0 },
                { icon: Car,          label: 'Add Vehicle',      to: '/vehicles',  color: 'blue',   badge: 0 },
                { icon: MessageCircle,label: 'Messages',         to: '/messages',  color: 'green',  badge: unread },
                { icon: Star,         label: 'My Reviews',       to: '/bookings',  color: 'yellow', badge: 0 },
                { icon: TrendingUp,   label: 'Service History',  to: '/bookings',  color: 'blue',   badge: 0 },
                { icon: Calendar,     label: 'Upcoming',         to: '/bookings',  color: 'orange', badge: 0 },
              ].map(a => (
                <Link key={a.label} to={a.to} className={`qa-item qa-${a.color}`}>
                  <div className="qa-icon"><a.icon size={18} /></div>
                  <span>{a.label}</span>
                  {a.badge > 0 && <div className="qa-badge">{a.badge}</div>}
                </Link>
              ))}
            </div>
          </div>

          {/* Recent Reviews */}
          <div className="animate-fadeInUp delay-400">
            <div className="section-head">
              <h2>Your Reviews</h2>
              <Link to="/bookings" className="view-all">All <ArrowRight size={14} /></Link>
            </div>
            {reviews.filter(r => r.userId === user?.id).length === 0 ? (
              <div className="empty-state">
                <Star size={40} />
                <p>No reviews yet</p>
                <p style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Complete a service to leave a review</p>
              </div>
            ) : (
              <div className="review-list">
                {reviews.filter(r => r.userId === user?.id).map(r => {
                  const svc = getService(r.serviceId);
                  return (
                    <div key={r.id} className="review-item">
                      <div className="ri-top">
                        <span className="ri-service">{svc?.name}</span>
                        <div className="ri-stars">{[1, 2, 3, 4, 5].map(s => <Star key={s} size={12} className={s <= r.rating ? 'star' : 'star empty'} />)}</div>
                      </div>
                      <p className="ri-comment">{r.comment}</p>
                      <span className="ri-date">{r.createdAt}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
