import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useApp, containsAbusiveContent } from '../context/AppContext';
import { Send, MessageCircle, Search, ArrowLeft, Image, MoreVertical, Volume2, VolumeX, Flag, X, AlertTriangle, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import './MessagesPage.css';

export default function MessagesPage(): JSX.Element {
  const { bookingId: paramId } = useParams<{ bookingId?: string }>();
  const { user } = useAuth();
  const {
    bookings, vehicles, services, messages, conversationMeta,
    sendMessage, markMessagesRead,
    reportConversation, muteConversation, unmuteConversation,
  } = useApp();
  const navigate = useNavigate();
  const imageInputRef = useRef<HTMLInputElement>(null);

  const myBookings = user?.role === 'mechanic'
    ? bookings.filter(b => b.mechanicId === user?.id || b.mechanicId === 3)
    : bookings.filter(b => b.userId === user?.id && b.status !== 'Cancelled');

  const [activeId, setActiveId] = useState<string | null>(paramId ?? myBookings[0]?.id ?? null);
  const [text, setText] = useState<string>('');
  const [search, setSearch] = useState<string>('');
  const [showMenu, setShowMenu] = useState<boolean>(false);
  const [showReportModal, setShowReportModal] = useState<boolean>(false);
  const [reportReason, setReportReason] = useState<string>('');
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (paramId) setActiveId(paramId);
  }, [paramId]);

  useEffect(() => {
    if (activeId) {
      markMessagesRead(activeId);
    }
  }, [activeId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeId, messages]);

  const activeBooking = bookings.find(b => b.id === activeId);
  const activeVehicle = vehicles.find(v => v.id === activeBooking?.vehicleId);
  const activeService = services.find(s => s.id === activeBooking?.serviceId);
  const activeMessages = activeId ? (messages[activeId] ?? []) : [];
  const activeMeta = activeId ? conversationMeta[activeId] : undefined;
  const isMuted = activeMeta?.muted ?? false;
  const isReported = activeMeta?.reported ?? false;

  const filteredBookings = myBookings.filter(b => {
    const s = services.find(sv => sv.id === b.serviceId);
    const v = vehicles.find(vv => vv.id === b.vehicleId);
    return !search || s?.name.toLowerCase().includes(search.toLowerCase()) || v?.make.toLowerCase().includes(search.toLowerCase());
  });

  const handleSend = (): void => {
    if (!text.trim() || !activeId) return;
    if (containsAbusiveContent(text)) {
      toast.error('Message contains inappropriate content and cannot be sent.');
      return;
    }
    if (isMuted) {
      toast.error('This conversation is muted. Unmute to send messages.');
      return;
    }
    const result = sendMessage(activeId, text.trim(), user?.role === 'mechanic' ? 'mechanic' : 'customer');
    if (result.success) setText('');
    else toast.error('Message could not be sent.');
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const file = e.target.files?.[0];
    if (!file || !activeId) return;
    if (!file.type.startsWith('image/')) { toast.error('Please select an image file.'); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error('Image must be under 5MB.'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      if (dataUrl) {
        sendMessage(activeId, '📷 Image', user?.role === 'mechanic' ? 'mechanic' : 'customer', dataUrl);
        toast.success('Image sent!');
      }
    };
    reader.readAsDataURL(file);
    if (imageInputRef.current) imageInputRef.current.value = '';
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>): void => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const handleMuteToggle = (): void => {
    if (!activeId) return;
    if (isMuted) {
      unmuteConversation(activeId);
      toast.success('Conversation unmuted.');
    } else {
      muteConversation(activeId);
      toast.success('Conversation muted. You will no longer receive notifications for this chat.');
    }
    setShowMenu(false);
  };

  const handleReport = (): void => {
    if (!activeId || !reportReason.trim()) { toast.error('Please enter a reason.'); return; }
    reportConversation(activeId, reportReason.trim());
    toast.success('Conversation reported. Our team will review it shortly.');
    setShowReportModal(false);
    setReportReason('');
  };

  const getUnread = (bookingId: string): number =>
    (messages[bookingId] ?? []).filter(m => !m.read && m.from !== (user?.role === 'mechanic' ? 'mechanic' : 'customer')).length;

  return (
    <div className="page messages-page">
      <div className="messages-layout">
        {/* Sidebar */}
        <div className="msg-sidebar">
          <div className="msg-sidebar-header">
            <h2>Messages</h2>
            <div className="msg-search-wrap">
              <Search size={14} className="ms-icon" />
              <input className="msg-search" placeholder="Search bookings…" value={search} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearch(e.target.value)} />
            </div>
          </div>
          <div className="conversation-list">
            {filteredBookings.length === 0 && (
              <div className="no-convos"><MessageCircle size={32} /><p>No conversations yet</p></div>
            )}
            {filteredBookings.map(b => {
              const s = services.find(sv => sv.id === b.serviceId);
              const v = vehicles.find(vv => vv.id === b.vehicleId);
              const lastMsg = (messages[b.id] ?? []).slice(-1)[0];
              const unread = getUnread(b.id);
              const bMeta = conversationMeta[b.id];
              return (
                <div key={b.id} className={`convo-item${activeId === b.id ? ' active' : ''}`} onClick={() => { setActiveId(b.id); navigate(`/messages/${b.id}`); }}>
                  <div className="ci-avatar">{s?.name?.[0] ?? '?'}</div>
                  <div className="ci-info">
                    <div className="ci-top">
                      <span className="ci-name">
                        {s?.name}
                        {bMeta?.muted && <VolumeX size={11} style={{ display: 'inline', marginLeft: 4, color: 'var(--text-muted)' }} />}
                      </span>
                      {lastMsg && <span className="ci-time">{lastMsg.time?.split(' ')[1]?.slice(0, 5) ?? ''}</span>}
                    </div>
                    <div className="ci-sub">
                      <span className="ci-vehicle">{v?.make} {v?.model}</span>
                      {lastMsg && (
                        <span className="ci-preview">
                          {lastMsg.from === 'customer' ? 'You: ' : ''}
                          {lastMsg.imageUrl ? '📷 Photo' : lastMsg.text?.slice(0, 30)}
                          {(!lastMsg.imageUrl && (lastMsg.text?.length ?? 0) > 30) ? '…' : ''}
                        </span>
                      )}
                    </div>
                  </div>
                  {unread > 0 && <div className="ci-badge">{unread}</div>}
                </div>
              );
            })}
          </div>
        </div>

        {/* Chat Area */}
        <div className="msg-chat-area">
          {!activeId ? (
            <div className="chat-empty">
              <MessageCircle size={56} />
              <h3>Select a conversation</h3>
              <p>Choose a booking from the left to start messaging</p>
            </div>
          ) : (
            <>
              {/* Chat Header */}
              <div className="chat-header">
                <button className="chat-back" onClick={() => navigate('/messages')}><ArrowLeft size={18} /></button>
                <div className="ch-avatar">{activeService?.name?.[0]}</div>
                <div className="ch-info">
                  <div className="ch-name">
                    {activeService?.name}
                    {isMuted && <VolumeX size={12} style={{ display: 'inline', marginLeft: 6, color: 'var(--text-muted)' }} />}
                    {isReported && <Flag size={12} style={{ display: 'inline', marginLeft: 6, color: 'var(--red)' }} />}
                  </div>
                  <div className="ch-sub">
                    {activeVehicle?.make} {activeVehicle?.model} · #{activeId} ·{' '}
                    <span className={`status-dot-inline ${activeBooking?.mechanic ? 'online' : ''}`} />
                    {activeBooking?.mechanic ?? 'Awaiting assignment'}
                  </div>
                </div>
                {/* Menu */}
                <div style={{ position: 'relative' }}>
                  <button className="icon-btn" onClick={() => setShowMenu(p => !p)}><MoreVertical size={18} /></button>
                  {showMenu && (
                    <div style={{ position: 'absolute', right: 0, top: '100%', background: '#fff', border: '1px solid var(--border)', borderRadius: 10, boxShadow: '0 4px 20px rgba(0,0,0,0.12)', zIndex: 100, minWidth: 180, overflow: 'hidden' }}>
                      <button
                        style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 16px', fontSize: 13, cursor: 'pointer', background: 'none', border: 'none', width: '100%', textAlign: 'left', color: 'var(--text-primary)' }}
                        onClick={handleMuteToggle}
                      >
                        {isMuted ? <Volume2 size={14} /> : <VolumeX size={14} />}
                        {isMuted ? 'Unmute Conversation' : 'Mute Conversation'}
                      </button>
                      <button
                        style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 16px', fontSize: 13, cursor: 'pointer', background: 'none', border: 'none', width: '100%', textAlign: 'left', color: 'var(--red)', borderTop: '1px solid var(--border)' }}
                        onClick={() => { setShowMenu(false); setShowReportModal(true); }}
                      >
                        <Flag size={14} /> Report Conversation
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Reported banner */}
              {isReported && (
                <div style={{ background: 'rgba(220,38,38,0.06)', borderBottom: '1px solid rgba(220,38,38,0.15)', padding: '8px 16px', fontSize: 12, color: 'var(--red)', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <AlertTriangle size={13} /> This conversation has been reported and is under review.
                </div>
              )}

              {/* Muted banner */}
              {isMuted && (
                <div style={{ background: 'rgba(100,116,139,0.08)', borderBottom: '1px solid var(--border)', padding: '8px 16px', fontSize: 12, color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <VolumeX size={13} /> Conversation muted — notifications paused.
                  <button style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--blue)', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 700 }} onClick={handleMuteToggle}>Unmute</button>
                </div>
              )}

              {/* Messages */}
              <div className="chat-messages" onClick={() => setShowMenu(false)}>
                {activeMessages.length === 0 && (
                  <div className="no-messages">
                    <MessageCircle size={40} />
                    <p>No messages yet. Start the conversation!</p>
                  </div>
                )}
                {activeMessages.map((msg, i) => {
                  const isMe = (user?.role === 'mechanic') ? msg.from === 'mechanic' : msg.from === 'customer';
                  const showDate = i === 0 || activeMessages[i - 1]?.time?.split(' ')[0] !== msg.time?.split(' ')[0];
                  return (
                    <React.Fragment key={msg.id}>
                      {showDate && <div className="msg-date-divider">{msg.time?.split(' ')[0]}</div>}
                      <div className={`message-bubble${isMe ? ' me' : ' them'}`}>
                        {!isMe && <div className="msg-sender-avatar">{activeBooking?.mechanic?.[0] ?? 'M'}</div>}
                        <div className="msg-content">
                          {!isMe && <div className="msg-sender-name">{activeBooking?.mechanic ?? 'Mechanic'}</div>}
                          {msg.imageUrl ? (
                            <div className="msg-image-wrap">
                              <img
                                src={msg.imageUrl}
                                alt="attachment"
                                className="msg-image"
                                style={{ maxWidth: 200, maxHeight: 200, borderRadius: 10, cursor: 'pointer', display: 'block' }}
                                onClick={() => setPreviewImage(msg.imageUrl!)}
                              />
                              {msg.text !== '📷 Image' && <div className="msg-text" style={{ marginTop: 4 }}>{msg.text}</div>}
                            </div>
                          ) : (
                            <div className="msg-text">{msg.text}</div>
                          )}
                          <div className="msg-meta">
                            <span>{msg.time?.split(' ')[1] ?? ''}</span>
                            {isMe && <span className={`read-receipt ${msg.read ? 'read' : ''}`}>✓✓</span>}
                          </div>
                        </div>
                      </div>
                    </React.Fragment>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="chat-input-area">
                <input
                  ref={imageInputRef}
                  type="file"
                  accept="image/*"
                  style={{ display: 'none' }}
                  onChange={handleImageUpload}
                />
                <button
                  className="input-action-btn"
                  title="Attach image"
                  onClick={() => imageInputRef.current?.click()}
                  disabled={isMuted}
                >
                  <Image size={18} />
                </button>
                <textarea
                  className="chat-input"
                  placeholder={isMuted ? 'Conversation muted…' : 'Type a message…'}
                  value={text}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  rows={1}
                  disabled={isMuted}
                />
                <button className={`send-btn${text.trim() && !isMuted ? ' active' : ''}`} onClick={handleSend} disabled={!text.trim() || isMuted}>
                  <Send size={18} />
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* ── Image Preview Modal ── */}
      {previewImage && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          onClick={() => setPreviewImage(null)}
        >
          <button style={{ position: 'absolute', top: 20, right: 20, background: 'rgba(255,255,255,0.1)', border: 'none', borderRadius: '50%', width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'white' }}>
            <X size={18} />
          </button>
          <img src={previewImage} alt="preview" style={{ maxWidth: '90vw', maxHeight: '90vh', borderRadius: 12, objectFit: 'contain' }} />
        </div>
      )}

      {/* ── Report Modal ── */}
      {showReportModal && (
        <div className="modal-overlay" onClick={() => setShowReportModal(false)}>
          <div className="modal animate-fadeInUp" style={{ maxWidth: 440 }} onClick={(e: React.MouseEvent) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h2>Report Conversation</h2>
                <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>Help us keep AutoServe safe</p>
              </div>
              <button className="modal-close" onClick={() => setShowReportModal(false)}><X size={18} /></button>
            </div>
            <div style={{ marginBottom: 16 }}>
              <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 12 }}>Please describe why you are reporting this conversation:</p>
              {['Abusive language', 'Spam or unsolicited content', 'Harassment', 'Other'].map(reason => (
                <button
                  key={reason}
                  type="button"
                  style={{ display: 'block', width: '100%', textAlign: 'left', padding: '10px 14px', marginBottom: 6, borderRadius: 8, border: `1.5px solid ${reportReason === reason ? 'var(--accent)' : 'var(--border)'}`, background: reportReason === reason ? 'rgba(249,115,22,0.06)' : 'white', cursor: 'pointer', fontSize: 13, color: 'var(--text-primary)', fontFamily: 'inherit' }}
                  onClick={() => setReportReason(reason)}
                >
                  {reportReason === reason && <CheckCircle size={13} style={{ display: 'inline', marginRight: 8, color: 'var(--accent)' }} />}
                  {reason}
                </button>
              ))}
            </div>
            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={() => setShowReportModal(false)}>Cancel</button>
              <button className="btn btn-primary" style={{ background: 'var(--red)' }} onClick={handleReport} disabled={!reportReason}>
                <Flag size={14} /> Submit Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
