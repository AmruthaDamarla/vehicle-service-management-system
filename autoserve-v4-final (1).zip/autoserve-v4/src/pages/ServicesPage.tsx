import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Service } from '../context/AppContext';
import { Search, Filter, Clock, Star, Plus, Check, X, ShoppingCart } from 'lucide-react';
import './ServicesPage.css';

type CartUpdater = number[] | ((prev: number[]) => number[]);

interface ServicesPageProps {
  cart: number[];
  setCart: (fn: CartUpdater) => void;
}

const CATEGORIES = ['All', 'General', 'Electrical', 'Bodywork'] as const;
type SortKey = 'popular' | 'price-asc' | 'price-desc' | 'time';

export default function ServicesPage({ cart, setCart }: ServicesPageProps) {
  const { services } = useApp();
  const navigate = useNavigate();
  const [search, setSearch]     = useState('');
  const [category, setCategory] = useState<string>('All');
  const [sortBy, setSortBy]     = useState<SortKey>('popular');
  const [selected, setSelected] = useState<Service | null>(null);

  const filtered = useMemo(() => {
    let list = services.filter(s => {
      const ms = s.name.toLowerCase().includes(search.toLowerCase()) || s.description.toLowerCase().includes(search.toLowerCase());
      const mc = category === 'All' || s.category === category;
      return ms && mc;
    });
    if (sortBy === 'price-asc')  list = [...list].sort((a, b) => a.price - b.price);
    else if (sortBy === 'price-desc') list = [...list].sort((a, b) => b.price - a.price);
    else if (sortBy === 'time')  list = [...list].sort((a, b) => a.duration - b.duration);
    else list = [...list].sort((a, b) => b.reviews - a.reviews);
    return list;
  }, [services, search, category, sortBy]);

  const toggleCart = (id: number) => {
    setCart(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };
  const inCart = (id: number) => cart.includes(id);

  return (
    <div className="page services-page">
      <div className="container">
        <div className="page-header animate-fadeInUp">
          <div>
            <h1 className="page-title">Service Catalog</h1>
            <p className="page-subtitle">Browse from {services.length} professional services</p>
          </div>
          {cart.length > 0 && (
            <button className="btn btn-primary" onClick={() => navigate('/cart')}>
              <ShoppingCart size={16} /> View Cart ({cart.length})
            </button>
          )}
        </div>

        <div className="filters-bar animate-fadeInUp delay-100">
          <div className="search-wrap">
            <Search size={16} className="search-icon" />
            <input className="search-input" placeholder="Search services…" value={search} onChange={e => setSearch(e.target.value)} />
            {search && <button className="search-clear" onClick={() => setSearch('')}><X size={14} /></button>}
          </div>
          <div className="cat-tabs">
            {CATEGORIES.map(c => (
              <button key={c} className={`cat-tab${category === c ? ' active' : ''}`} onClick={() => setCategory(c)}>{c}</button>
            ))}
          </div>
          <div className="sort-wrap">
            <Filter size={14} />
            <select className="sort-select" value={sortBy} onChange={e => setSortBy(e.target.value as SortKey)}>
              <option value="popular">Most Popular</option>
              <option value="price-asc">Price: Low–High</option>
              <option value="price-desc">Price: High–Low</option>
              <option value="time">Duration</option>
            </select>
          </div>
        </div>

        <p className="results-count animate-fadeInUp delay-200">{filtered.length} service{filtered.length !== 1 ? 's' : ''} found</p>

        <div className="services-grid">
          {filtered.map((s, i) => (
            <div key={s.id} className={`service-card animate-fadeInUp${inCart(s.id) ? ' in-cart' : ''}`} style={{ animationDelay: `${i * 0.05}s`, opacity: 0 }}>
              <div className="sc-top">
                <span className={`badge badge-${s.category === 'General' ? 'green' : s.category === 'Electrical' ? 'blue' : 'orange'}`}>{s.category}</span>
                <div className="sc-rating"><Star size={12} className="star" /><span>{s.rating}</span><span className="sc-reviews">({s.reviews})</span></div>
              </div>
              <h3 className="sc-name">{s.name}</h3>
              <p className="sc-desc">{s.description}</p>
              <div className="sc-meta"><span><Clock size={13} /> {s.duration >= 60 ? `${Math.floor(s.duration / 60)}h ${s.duration % 60 ? s.duration % 60 + 'm' : ''}` : s.duration + 'm'}</span></div>
              <div className="sc-footer">
                <div className="sc-price">₹{s.price.toLocaleString('en-IN')}<span>/service</span></div>
                <div className="sc-btns">
                  <button className="btn btn-secondary btn-sm" onClick={() => setSelected(s)}>Details</button>
                  <button
                    className={`btn btn-sm${inCart(s.id) ? ' btn-in-cart' : ' btn-primary'}`}
                    onClick={() => toggleCart(s.id)}
                  >
                    {inCart(s.id) ? <><Check size={14} />Added</> : <><Plus size={14} />Add</>}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="no-results animate-fadeInUp"><Search size={48} /><h3>No services found</h3><p>Try a different search or category</p></div>
        )}

        {/* Floating cart bar */}
        {cart.length > 0 && (
          <div className="cart-float-bar" onClick={() => navigate('/cart')}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <ShoppingCart size={20} />
              <span><strong>{cart.length}</strong> service{cart.length !== 1 ? 's' : ''} in cart</span>
            </div>
            <span style={{ fontWeight: 700 }}>Go to Cart →</span>
          </div>
        )}
      </div>

      {/* Detail Modal */}
      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal service-modal animate-fadeInUp" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <span className={`badge badge-${selected.category === 'General' ? 'green' : selected.category === 'Electrical' ? 'blue' : 'orange'}`}>{selected.category}</span>
                <h2 style={{ marginTop: '8px' }}>{selected.name}</h2>
              </div>
              <button className="modal-close" onClick={() => setSelected(null)}><X size={18} /></button>
            </div>
            <p style={{ color: 'var(--text-secondary)', marginBottom: 16, lineHeight: 1.6 }}>{selected.description}</p>
            <div className="svc-detail-grid">
              <div className="svc-detail-item"><span className="sdl">Duration</span><span className="sdv">{selected.duration >= 60 ? `${Math.floor(selected.duration / 60)}h ${selected.duration % 60 ? selected.duration % 60 + 'm' : ''}` : selected.duration + 'm'}</span></div>
              <div className="svc-detail-item"><span className="sdl">Base Price</span><span className="sdv">₹{selected.price.toLocaleString('en-IN')}</span></div>
              <div className="svc-detail-item"><span className="sdl">Rating</span><span className="sdv">{selected.rating} ★ ({selected.reviews} reviews)</span></div>
            </div>
            <div className="svc-lists">
              <div className="svc-list-col"><h4>✅ Inclusions</h4><ul>{selected.inclusions.map(item => <li key={item}><Check size={12} />{item}</li>)}</ul></div>
              <div className="svc-list-col"><h4>❌ Exclusions</h4><ul>{selected.exclusions.map(item => <li key={item}><X size={12} />{item}</li>)}</ul></div>
            </div>
            {selected.addons?.length > 0 && (
              <div className="svc-addons"><h4>⚡ Add-ons Available</h4>
                <div className="addon-chips">{selected.addons.map(a => <span key={a.id} className="addon-chip">{a.name} <span>+₹{a.price}</span></span>)}</div>
              </div>
            )}
            <div className="modal-actions" style={{ marginTop: 24 }}>
              <button className="btn btn-secondary" onClick={() => setSelected(null)}>Close</button>
              <button
                className={`btn${inCart(selected.id) ? ' btn-in-cart' : ' btn-primary'}`}
                onClick={() => { toggleCart(selected.id); setSelected(null); }}
              >
                {inCart(selected.id) ? <><X size={15} />Remove from Cart</> : <><Plus size={15} />Add to Cart</>}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
