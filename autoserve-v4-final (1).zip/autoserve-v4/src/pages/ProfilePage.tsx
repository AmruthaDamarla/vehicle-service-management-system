import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { User, Mail, Phone, Lock, Save, Eye, EyeOff, Shield } from 'lucide-react';
import './ProfilePage.css';

interface ProfileForm {
  name: string;
  email: string;
  mobile: string;
}

interface PassForm {
  current: string;
  newPass: string;
  confirm: string;
}

export default function ProfilePage(): JSX.Element {
  const { user, updateProfile } = useAuth();
  const [form, setForm] = useState<ProfileForm>({ name: user?.name ?? '', email: user?.email ?? '', mobile: user?.mobile ?? '' });
  const [passForm, setPassForm] = useState<PassForm>({ current: '', newPass: '', confirm: '' });
  const [showPass, setShowPass] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState<boolean>(false);
  const [passLoading, setPassLoading] = useState<boolean>(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleProfileSave = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    if (!form.name.trim()) { setErrors({ name: 'Name required' }); return; }
    setLoading(true);
    await new Promise<void>(r => setTimeout(r, 600));
    updateProfile(form);
    setLoading(false);
    toast.success('Profile updated successfully');
  };

  const handlePassSave = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!passForm.current) errs.current = 'Enter current password';
    if (passForm.newPass.length < 8) errs.newPass = 'Minimum 8 characters';
    else if (!/[A-Z]/.test(passForm.newPass)) errs.newPass = 'Need 1 uppercase letter';
    else if (!/[0-9]/.test(passForm.newPass)) errs.newPass = 'Need 1 number';
    if (passForm.newPass !== passForm.confirm) errs.confirm = 'Passwords do not match';
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setPassLoading(true);
    await new Promise<void>(r => setTimeout(r, 700));
    setPassLoading(false);
    setPassForm({ current: '', newPass: '', confirm: '' });
    toast.success('Password updated successfully');
  };

  const toggleShow = (key: string): void => setShowPass(p => ({ ...p, [key]: !p[key] }));

  return (
    <div className="page profile-page">
      <div className="container">
        <div className="page-header animate-fadeInUp">
          <div>
            <h1 className="page-title">Profile Settings</h1>
            <p className="page-subtitle">Manage your account details and security</p>
          </div>
        </div>

        <div className="profile-layout">
          {/* Profile Card */}
          <div className="profile-card animate-fadeInUp delay-100">
            <div className="profile-avatar-section">
              <div className="profile-avatar-lg">{user?.avatar}</div>
              <div>
                <div className="pa-name">{user?.name}</div>
                <div className="pa-email">{user?.email}</div>
                <span className={`badge badge-${user?.role === 'admin' ? 'orange' : user?.role === 'mechanic' ? 'blue' : 'green'}`}>{user?.role}</span>
              </div>
            </div>
          </div>

          <div className="profile-forms">
            {/* Personal Info */}
            <div className="settings-card animate-fadeInUp delay-200">
              <div className="sc-header"><User size={18} /><h3>Personal Information</h3></div>
              <form onSubmit={handleProfileSave} className="settings-form">
                <div className="form-row">
                  <div className="form-group">
                    <label className="label">Full Name</label>
                    <div className="input-wrap">
                      <User size={15} className="input-icon" />
                      <input className={`input-field padded${errors.name ? ' error' : ''}`} value={form.name} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm(p => ({ ...p, name: e.target.value }))} placeholder="Full name" />
                    </div>
                    {errors.name && <p className="error-text">{errors.name}</p>}
                  </div>
                  <div className="form-group">
                    <label className="label">Email Address</label>
                    <div className="input-wrap">
                      <Mail size={15} className="input-icon" />
                      <input className="input-field padded" value={form.email} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm(p => ({ ...p, email: e.target.value }))} placeholder="Email" type="email" />
                    </div>
                  </div>
                </div>
                <div className="form-group" style={{ maxWidth: '50%' }}>
                  <label className="label">Mobile Number</label>
                  <div className="input-wrap">
                    <Phone size={15} className="input-icon" />
                    <input className="input-field padded" value={form.mobile} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm(p => ({ ...p, mobile: e.target.value }))} placeholder="Mobile" maxLength={10} />
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <button type="submit" className="btn btn-primary" disabled={loading}>
                    {loading ? <span className="spinner" /> : <><Save size={15} />Save Changes</>}
                  </button>
                </div>
              </form>
            </div>

            {/* Security */}
            <div className="settings-card animate-fadeInUp delay-300">
              <div className="sc-header"><Shield size={18} /><h3>Security & Password</h3></div>
              <form onSubmit={handlePassSave} className="settings-form">
                <div className="form-group">
                  <label className="label">Current Password</label>
                  <div className="input-wrap">
                    <Lock size={15} className="input-icon" />
                    <input className={`input-field padded${errors.current ? ' error' : ''}`} type={showPass.current ? 'text' : 'password'} value={passForm.current} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPassForm(p => ({ ...p, current: e.target.value }))} placeholder="Current password" />
                    <button type="button" className="eye-btn" onClick={() => toggleShow('current')}>{showPass.current ? <EyeOff size={15} /> : <Eye size={15} />}</button>
                  </div>
                  {errors.current && <p className="error-text">{errors.current}</p>}
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label className="label">New Password</label>
                    <div className="input-wrap">
                      <Lock size={15} className="input-icon" />
                      <input className={`input-field padded${errors.newPass ? ' error' : ''}`} type={showPass.newPass ? 'text' : 'password'} value={passForm.newPass} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPassForm(p => ({ ...p, newPass: e.target.value }))} placeholder="New password" />
                      <button type="button" className="eye-btn" onClick={() => toggleShow('newPass')}>{showPass.newPass ? <EyeOff size={15} /> : <Eye size={15} />}</button>
                    </div>
                    {errors.newPass && <p className="error-text">{errors.newPass}</p>}
                  </div>
                  <div className="form-group">
                    <label className="label">Confirm New Password</label>
                    <div className="input-wrap">
                      <Lock size={15} className="input-icon" />
                      <input className={`input-field padded${errors.confirm ? ' error' : ''}`} type={showPass.confirm ? 'text' : 'password'} value={passForm.confirm} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPassForm(p => ({ ...p, confirm: e.target.value }))} placeholder="Confirm password" />
                      <button type="button" className="eye-btn" onClick={() => toggleShow('confirm')}>{showPass.confirm ? <EyeOff size={15} /> : <Eye size={15} />}</button>
                    </div>
                    {errors.confirm && <p className="error-text">{errors.confirm}</p>}
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <button type="submit" className="btn btn-primary" disabled={passLoading}>
                    {passLoading ? <span className="spinner" /> : <><Lock size={15} />Update Password</>}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
