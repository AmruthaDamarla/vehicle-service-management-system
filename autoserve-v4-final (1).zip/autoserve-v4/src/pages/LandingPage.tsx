import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Car, Shield, Clock, Star, CheckCircle, ArrowRight, Wrench, CreditCard, MessageCircle, Zap } from 'lucide-react';
import './LandingPage.css';

const FEATURES = [
  { icon: Wrench,        title: 'Smart Booking',        desc: 'Book any service in under 2 minutes with real-time slot availability.' },
  { icon: Clock,         title: 'Live Tracking',        desc: 'Track your vehicle service status from Booked to Completed in real time.' },
  { icon: Shield,        title: 'Secure Payments',      desc: 'Pay via UPI, card or net banking with PCI-compliant checkout and auto-invoicing.' },
  { icon: MessageCircle, title: 'Direct Messaging',     desc: 'Chat directly with your assigned mechanic and share photos of issues.' },
  { icon: Star,          title: 'Reviews & Ratings',    desc: 'Rate your service and help others make informed decisions.' },
  { icon: Zap,           title: 'Instant Confirmation', desc: 'Get booking confirmation with ID, cost breakdown and reminder alerts.' },
];

const STATS = [
  { value: '12,000+', label: 'Vehicles Serviced' },
  { value: '4.8★',    label: 'Average Rating' },
  { value: '98%',     label: 'On-Time Delivery' },
  { value: '50+',     label: 'Expert Mechanics' },
];

const STEPS = [
  { num: '01', title: 'Register & Add Vehicle', desc: 'Create your account and add your vehicle details in seconds.' },
  { num: '02', title: 'Browse & Book Service',  desc: 'Pick from our catalog, choose a slot and confirm your booking.' },
  { num: '03', title: 'Track Progress Live',    desc: 'Watch your service move through each stage with real-time updates.' },
  { num: '04', title: 'Pay & Review',           desc: 'Pay securely, download your invoice and leave a review.' },
];

export default function LandingPage() {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) {
        const y = window.scrollY;
        heroRef.current.style.transform = `translateY(${y * 0.3}px)`;
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="landing">
      {/* Hero */}
      <section className="hero">
        <div className="hero-bg" ref={heroRef}>
          <div className="orb orb1" />
          <div className="orb orb2" />
          <div className="orb orb3" />
          <div className="grid-pattern" />
        </div>
        <div className="hero-content container">
          <div className="hero-badge animate-fadeInUp">
            <Zap size={12} /> India's Smartest Vehicle Service Platform
          </div>
          <h1 className="hero-title animate-fadeInUp delay-100">
            Your Car Deserves<br />
            <span className="accent-text">Expert Care.</span><br />
            <span className="outline-text">Effortlessly Booked.</span>
          </h1>
          <p className="hero-desc animate-fadeInUp delay-200">
            Book, track, and manage vehicle services from the comfort of your home. Real-time updates, certified mechanics, and transparent pricing.
          </p>
          <div className="hero-actions animate-fadeInUp delay-300">
            <Link to="/register" className="btn btn-primary btn-lg">
              Get Started Free <ArrowRight size={18} />
            </Link>
            <Link to="/login" className="btn btn-secondary btn-lg">
              Sign In
            </Link>
          </div>
          <div className="hero-trust animate-fadeInUp delay-400">
            {['No hidden charges', 'Certified mechanics', 'Free cancellation'].map(t => (
              <span key={t} className="trust-item"><CheckCircle size={14} /> {t}</span>
            ))}
          </div>
        </div>
        <div className="hero-visual animate-slideInRight delay-200">
          <div className="hero-card">
            <div className="hc-header">
              <div className="hc-dot green" /><div className="hc-dot yellow" /><div className="hc-dot red" />
              <span>Live Service Tracker</span>
            </div>
            <div className="hc-booking-id">Booking #BK2026051</div>
            <div className="hc-vehicle">🚗 Maruti Swift VXi · KA-51-AB-1234</div>
            <div className="hc-steps">
              {['Booked', 'Checked-In', 'In Progress', 'QA', 'Ready', 'Done'].map((s, i) => (
                <div key={s} className={`hc-step${i <= 2 ? ' done' : i === 3 ? ' active' : ''}`}>
                  <div className="hcs-dot" />
                  {i < 5 && <div className="hcs-line" />}
                  <span>{s}</span>
                </div>
              ))}
            </div>
            <div className="hc-progress">
              <div className="hcp-bar"><div className="hcp-fill" style={{ width: '55%' }} /></div>
              <span>Est. ready by 3:30 PM</span>
            </div>
            <div className="hc-mechanic">
              <div className="hcm-avatar">RM</div>
              <div><div className="hcm-name">Ravi Mechanic</div><div className="hcm-role">Assigned Mechanic</div></div>
              <div className="hcm-status"><div className="online-dot" /> Online</div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="stats-section">
        <div className="container">
          <div className="stats-grid">
            {STATS.map((s, i) => (
              <div key={s.label} className="stat-item animate-fadeInUp" style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="stat-value">{s.value}</div>
                <div className="stat-label">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="features-section container">
        <div className="section-header">
          <div className="section-tag">Features</div>
          <h2 className="section-title">Everything You Need,<br />Nothing You Don't</h2>
        </div>
        <div className="features-grid">
          {FEATURES.map((f, i) => (
            <div key={f.title} className="feature-card animate-fadeInUp" style={{ animationDelay: `${i * 0.08}s` }}>
              <div className="feature-icon"><f.icon size={22} /></div>
              <h3>{f.title}</h3>
              <p>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className="steps-section container">
        <div className="section-header">
          <div className="section-tag">How It Works</div>
          <h2 className="section-title">Four Simple Steps<br />to Stress-Free Servicing</h2>
        </div>
        <div className="steps-grid">
          {STEPS.map((s, i) => (
            <div key={s.num} className="step-card animate-fadeInUp" style={{ animationDelay: `${i * 0.1}s` }}>
              <div className="step-num">{s.num}</div>
              <h3>{s.title}</h3>
              <p>{s.desc}</p>
              {i < STEPS.length - 1 && <div className="step-arrow"><ArrowRight size={18} /></div>}
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="cta-section container">
        <div className="cta-card">
          <div className="cta-orb" />
          <h2>Ready to Service Smarter?</h2>
          <p>Join thousands of vehicle owners who trust AutoServe for all their service needs.</p>
          <Link to="/register" className="btn btn-primary btn-lg">
            Create Free Account <ArrowRight size={18} />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="footer-brand">
            <div className="brand-icon"><Car size={18} /></div>
            <span>AutoServe</span>
          </div>
          <p>© 2026 AutoServe · Vehicle Service Booking System · Infosys Limited</p>
        </div>
      </footer>
    </div>
  );
}
