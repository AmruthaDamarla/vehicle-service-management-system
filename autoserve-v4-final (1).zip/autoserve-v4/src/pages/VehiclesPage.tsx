import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { Vehicle, AddVehicleData } from '../context/AppContext';
import toast from 'react-hot-toast';
import { Car, Plus, Edit2, Trash2, Star, X, Check } from 'lucide-react';
import './VehiclesPage.css';

const FUEL_TYPES = ['Petrol', 'Diesel', 'Electric', 'CNG', 'Hybrid'];
const MAKES = ['Maruti Suzuki', 'Hyundai', 'Tata', 'Honda', 'Toyota', 'Mahindra', 'Kia', 'MG', 'Renault', 'Volkswagen', 'Ford', 'Skoda', 'Other'];
const currentYear = new Date().getFullYear();
const YEARS = Array.from({ length: currentYear - 1979 }, (_, i) => currentYear - i);

interface VehicleForm {
  make: string;
  model: string;
  variant: string;
  year: number;
  fuelType: string;
  regNumber: string;
  isDefault: boolean;
}

type VehicleErrors = Partial<Record<keyof VehicleForm, string>>;

const emptyForm: VehicleForm = { make: '', model: '', variant: '', year: currentYear, fuelType: 'Petrol', regNumber: '', isDefault: false };

const validateVehicle = (f: VehicleForm): VehicleErrors => {
  const e: VehicleErrors = {};
  if (!f.make) e.make = 'Make is required';
  if (!f.model.trim()) e.model = 'Model is required';
  if (!f.year || f.year > currentYear || f.year < 1980) e.year = 'Invalid year (1980 – current year)';
  if (!f.fuelType) e.fuelType = 'Fuel type required';
  if (!f.regNumber.trim()) e.regNumber = 'Registration number required';
  else if (!/^[A-Z]{2}-\d{2}-[A-Z]{1,2}-\d{1,4}$/.test(f.regNumber.toUpperCase())) e.regNumber = 'Format: KA-51-AB-1234';
  return e;
};

export default function VehiclesPage() {
  const { user } = useAuth();
  const { vehicles, addVehicle, updateVehicle, deleteVehicle, setDefaultVehicle } = useApp();
  const [showModal, setShowModal]     = useState(false);
  const [editing, setEditing]         = useState<number | null>(null);
  const [form, setForm]               = useState<VehicleForm>(emptyForm);
  const [errors, setErrors]           = useState<VehicleErrors>({});
  const [loading, setLoading]         = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const myVehicles = vehicles.filter(v => v.userId === user?.id);

  const openAdd  = () => { setForm(emptyForm); setEditing(null); setErrors({}); setShowModal(true); };
  const openEdit = (v: Vehicle) => { setForm({ make: v.make, model: v.model, variant: v.variant, year: v.year, fuelType: v.fuelType, regNumber: v.regNumber, isDefault: v.isDefault }); setEditing(v.id); setErrors({}); setShowModal(true); };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const target = e.target as HTMLInputElement;
    const { name, value, type } = target;
    setForm(p => ({ ...p, [name]: type === 'checkbox' ? target.checked : value }));
    const key = name as keyof VehicleForm;
    if (errors[key]) setErrors(p => ({ ...p, [key]: '' }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const errs = validateVehicle(form);
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 500));
    const normalized = { ...form, regNumber: form.regNumber.toUpperCase() };
    if (editing !== null) {
      updateVehicle(editing, normalized);
      toast.success('Vehicle updated successfully');
    } else {
      addVehicle(normalized as AddVehicleData, user?.id);
      toast.success('Vehicle added successfully');
    }
    setLoading(false);
    setShowModal(false);
  };

  const handleDelete = (id: number) => {
    deleteVehicle(id);
    setDeleteConfirm(null);
    toast.success('Vehicle removed');
  };

  return (
    <div className="page vehicles-page">
      <div className="container">
        <div className="page-header animate-fadeInUp">
          <div>
            <h1 className="page-title">My Vehicles</h1>
            <p className="page-subtitle">Manage your vehicles for service bookings</p>
          </div>
          <button className="btn btn-primary" onClick={openAdd}><Plus size={16} />Add Vehicle</button>
        </div>

        {myVehicles.length === 0 ? (
          <div className="vehicles-empty animate-fadeInUp delay-100">
            <div className="ve-icon"><Car size={56} /></div>
            <h2>No vehicles yet</h2>
            <p>Add your vehicle to start booking services</p>
            <button className="btn btn-primary" onClick={openAdd}><Plus size={16} />Add Your First Vehicle</button>
          </div>
        ) : (
          <div className="vehicles-grid animate-fadeInUp delay-100">
            {myVehicles.map((v, i) => (
              <div key={v.id} className={`vehicle-card${v.isDefault ? ' default' : ''}`} style={{ animationDelay: `${i * 0.08}s` }}>
                {v.isDefault && <div className="default-ribbon"><Star size={10} /> Default</div>}
                <div className="vc-header">
                  <div className="vc-icon"><Car size={28} /></div>
                  <div className="vc-actions">
                    {!v.isDefault && (
                      <button className="icon-btn-sm" title="Set as default" onClick={() => { setDefaultVehicle(v.id); toast.success('Default vehicle updated'); }}>
                        <Star size={14} />
                      </button>
                    )}
                    <button className="icon-btn-sm" onClick={() => openEdit(v)}><Edit2 size={14} /></button>
                    <button className="icon-btn-sm danger" onClick={() => setDeleteConfirm(v.id)}><Trash2 size={14} /></button>
                  </div>
                </div>
                <div className="vc-name">{v.make} {v.model}</div>
                {v.variant && <div className="vc-variant">{v.variant}</div>}
                <div className="vc-specs">
                  <span className="spec-item"><span className="spec-label">Year</span><span>{v.year}</span></span>
                  <span className="spec-item"><span className="spec-label">Fuel</span><span>{v.fuelType}</span></span>
                  <span className="spec-item reg"><span className="spec-label">Reg</span><span>{v.regNumber}</span></span>
                </div>
              </div>
            ))}
            <button className="vehicle-card add-card" onClick={openAdd}>
              <Plus size={32} />
              <span>Add Vehicle</span>
            </button>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal animate-fadeInUp" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editing !== null ? 'Edit Vehicle' : 'Add New Vehicle'}</h2>
              <button className="modal-close" onClick={() => setShowModal(false)}><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="modal-form">
              <div className="form-row">
                <div className="form-group">
                  <label className="label">Make *</label>
                  <select className={`input-field${errors.make ? ' error' : ''}`} name="make" value={form.make} onChange={handleChange}>
                    <option value="">Select make</option>
                    {MAKES.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                  {errors.make && <p className="error-text">{errors.make}</p>}
                </div>
                <div className="form-group">
                  <label className="label">Model *</label>
                  <input className={`input-field${errors.model ? ' error' : ''}`} name="model" value={form.model} onChange={handleChange} placeholder="Swift, Creta, Nexon…" />
                  {errors.model && <p className="error-text">{errors.model}</p>}
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="label">Variant</label>
                  <input className="input-field" name="variant" value={form.variant} onChange={handleChange} placeholder="VXi, ZXi+, S…" />
                </div>
                <div className="form-group">
                  <label className="label">Year *</label>
                  <select className={`input-field${errors.year ? ' error' : ''}`} name="year" value={form.year} onChange={handleChange}>
                    {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
                  </select>
                  {errors.year && <p className="error-text">{errors.year}</p>}
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="label">Fuel Type *</label>
                  <select className={`input-field${errors.fuelType ? ' error' : ''}`} name="fuelType" value={form.fuelType} onChange={handleChange}>
                    {FUEL_TYPES.map(f => <option key={f} value={f}>{f}</option>)}
                  </select>
                  {errors.fuelType && <p className="error-text">{errors.fuelType}</p>}
                </div>
                <div className="form-group">
                  <label className="label">Registration Number *</label>
                  <input className={`input-field${errors.regNumber ? ' error' : ''}`} name="regNumber" value={form.regNumber} onChange={handleChange} placeholder="KA-51-AB-1234" style={{ textTransform: 'uppercase' }} />
                  {errors.regNumber && <p className="error-text">{errors.regNumber}</p>}
                </div>
              </div>
              <label className="checkbox-label">
                <input type="checkbox" name="isDefault" checked={form.isDefault} onChange={handleChange} />
                <span>Set as default vehicle</span>
              </label>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={loading}>
                  {loading ? <span className="spinner" /> : <><Check size={16} />{editing !== null ? 'Update' : 'Add Vehicle'}</>}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteConfirm !== null && (
        <div className="modal-overlay" onClick={() => setDeleteConfirm(null)}>
          <div className="modal confirm-modal animate-fadeInUp" onClick={e => e.stopPropagation()}>
            <div className="confirm-icon"><Trash2 size={28} /></div>
            <h3>Remove Vehicle?</h3>
            <p>This vehicle will be removed from your account. Existing bookings won't be affected.</p>
            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={() => setDeleteConfirm(null)}>Cancel</button>
              <button className="btn" style={{ background: 'var(--red)', color: 'white' }} onClick={() => handleDelete(deleteConfirm)}>Remove</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
