import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import toast from 'react-hot-toast';
import { Car, Wrench, Calendar, CheckCircle, ChevronRight, ChevronLeft, Plus, Clock, Image, X, Upload } from 'lucide-react';
import './BookingPage.css';

const STEPS = ['Vehicle', 'Services', 'Schedule', 'Review'];
const TIME_SLOTS = ['08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'];

interface BookingLocationState {
  serviceIds?: number[];
  clearCart?: boolean;
}

interface BookingSelection {
  vehicleId: number | null;
  serviceIds: number[];
  addons: string[];
  date: string;
  slot: string;
  notes: string;
  userImages: string[];
}

function getNextDays(n: number): Date[] {
  const days: Date[] = [];
  for (let i = 1; i <= n; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    days.push(d);
  }
  return days;
}

export default function BookingPage() {
  const { serviceId } = useParams<{ serviceId?: string }>();
  const { user } = useAuth();
  const { vehicles, services, createBooking } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const locationState = (location.state as BookingLocationState) || {};
  const cartServiceIds = locationState.serviceIds || [];
  const imageInputRef = useRef<HTMLInputElement>(null);

  const myVehicles = vehicles.filter(v => v.userId === user?.id);
  const initialServiceIds = serviceId ? [parseInt(serviceId)] : cartServiceIds;
  const [step, setStep]   = useState(cartServiceIds.length > 0 ? 1 : 0);
  const [sel, setSel]     = useState<BookingSelection>({
    vehicleId:   myVehicles.find(v => v.isDefault)?.id ?? myVehicles[0]?.id ?? null,
    serviceIds:  initialServiceIds,
    addons:      [],
    date:        '',
    slot:        '',
    notes:       '',
    userImages:  [],
  });
  const [loading, setLoading] = useState(false);
  const [booked, setBooked]   = useState<string | null>(null);
  // Lightbox for review-step image preview
  const [previewImg, setPreviewImg] = useState<string | null>(null);

  useEffect(() => {
    if (serviceId) { setSel(p => ({ ...p, serviceIds: [parseInt(serviceId)] })); setStep(2); }
  }, [serviceId]);

  const vehicle          = myVehicles.find(v => v.id === sel.vehicleId);
  const selectedServices = services.filter(s => sel.serviceIds.includes(s.id));
  const allAddons        = selectedServices.flatMap(s => s.addons || []);
  const addonItems       = allAddons.filter(a => sel.addons.includes(a.id));
  const addonTotal       = addonItems.reduce((sum, a) => sum + a.price, 0);
  const subtotal         = selectedServices.reduce((sum, s) => sum + (s.price || 0), 0) + addonTotal;
  const tax   = Math.round(subtotal * 0.18);
  const total = subtotal + tax;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const files = Array.from(e.target.files ?? []);
    if (sel.userImages.length + files.length > 5) {
      toast.error('You can upload a maximum of 5 images.');
      return;
    }
    files.forEach(file => {
      if (!file.type.startsWith('image/')) return;
      if (file.size > 5 * 1024 * 1024) { toast.error(`${file.name} is too large (max 5 MB).`); return; }
      const reader = new FileReader();
      reader.onload = (ev) => {
        const result = ev.target?.result as string;
        if (result) setSel(p => ({ ...p, userImages: [...p.userImages, result] }));
      };
      reader.readAsDataURL(file);
    });
    if (imageInputRef.current) imageInputRef.current.value = '';
  };

  const removeImage = (idx: number): void => {
    setSel(p => ({ ...p, userImages: p.userImages.filter((_, i) => i !== idx) }));
  };

  const handleBook = async () => {
    if (!sel.vehicleId || !user) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    const result = createBooking({
      userId:      user.id,
      vehicleId:   sel.vehicleId,
      serviceId:   sel.serviceIds[0],
      serviceIds:  sel.serviceIds,
      addons:      sel.addons,
      date:        sel.date,
      slot:        sel.slot,
      notes:       sel.notes,
      total,
      userImages:  sel.userImages,
    });
    setLoading(false);
    if (result.success) { setBooked(result.bookingId); }
  };

  if (booked) return (
    <div className="booking-success animate-fadeInUp">
      <div className="success-card">
        <div className="success-anim">
          <svg viewBox="0 0 80 80" className="success-svg">
            <circle cx="40" cy="40" r="36" fill="none" stroke="var(--green)" strokeWidth="4" />
            <polyline points="25,42 36,52 55,30" fill="none" stroke="var(--green)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="48" strokeDashoffset="48" style={{ animation: 'checkmark 0.6s ease forwards 0.3s' }} />
          </svg>
        </div>
        <h1>Booking Confirmed!</h1>
        <p>Your booking has been placed successfully.</p>
        <div className="success-id">Booking ID: <strong>{booked}</strong></div>
        <div className="success-details">
          <div><span>Vehicle</span><span>{vehicle?.make} {vehicle?.model}</span></div>
          <div><span>Services</span><span>{selectedServices.map(s => s.name).join(', ')}</span></div>
          <div><span>Date</span><span>{sel.date} at {sel.slot}</span></div>
          <div><span>Total</span><span>₹{total.toLocaleString('en-IN')}</span></div>
        </div>
        <div className="success-actions">
          <button className="btn btn-secondary" onClick={() => navigate('/bookings')}>View Bookings</button>
          <button className="btn btn-primary" onClick={() => navigate(`/payment/${booked}`)}>Pay Now</button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="page booking-page">
      <div className="container">
        <div className="booking-header animate-fadeInUp">
          <h1 className="page-title">Book a Service</h1>
          <div className="step-indicator">
            {STEPS.map((s, i) => (
              <React.Fragment key={s}>
                <div className={`step-dot${i === step ? ' active' : i < step ? ' done' : ''}`}>
                  {i < step ? <CheckCircle size={14} /> : <span>{i + 1}</span>}
                  <span className="step-label">{s}</span>
                </div>
                {i < STEPS.length - 1 && <div className={`step-line${i < step ? ' done' : ''}`} />}
              </React.Fragment>
            ))}
          </div>
        </div>

        <div className="booking-layout">
          <div className="booking-main animate-fadeInUp delay-100">

            {/* Step 0: Vehicle */}
            {step === 0 && (
              <div className="booking-step">
                <h2>Select Vehicle</h2>
                {myVehicles.length === 0 ? (
                  <div className="step-empty">
                    <Car size={40} />
                    <p>No vehicles added yet</p>
                    <button className="btn btn-primary" onClick={() => navigate('/vehicles')}><Plus size={16} />Add Vehicle</button>
                  </div>
                ) : (
                  <div className="option-list">
                    {myVehicles.map(v => (
                      <div key={v.id} className={`option-card${sel.vehicleId === v.id ? ' selected' : ''}`} onClick={() => setSel(p => ({ ...p, vehicleId: v.id }))}>
                        <div className="opt-icon"><Car size={22} /></div>
                        <div className="opt-info">
                          <div className="opt-name">{v.make} {v.model} {v.variant}</div>
                          <div className="opt-sub">{v.year} · {v.fuelType} · {v.regNumber}</div>
                        </div>
                        {v.isDefault && <span className="badge badge-green">Default</span>}
                        <div className={`opt-check${sel.vehicleId === v.id ? ' show' : ''}`}><CheckCircle size={18} /></div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Step 1: Services (multi-select) */}
            {step === 1 && (
              <div className="booking-step">
                <h2>Select Services</h2>
                <p style={{ fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '16px' }}>You can select one or more services</p>
                <div className="option-list">
                  {services.map(s => {
                    const isSelected = sel.serviceIds.includes(s.id);
                    return (
                      <div key={s.id} className={`option-card${isSelected ? ' selected' : ''}`} onClick={() => setSel(p => ({
                        ...p,
                        serviceIds: isSelected ? p.serviceIds.filter(id => id !== s.id) : [...p.serviceIds, s.id],
                        addons: [],
                      }))}>
                        <div className="opt-icon svc"><Wrench size={22} /></div>
                        <div className="opt-info">
                          <div className="opt-name">{s.name}</div>
                          <div className="opt-sub"><Clock size={11} /> {s.duration}m · ₹{s.price.toLocaleString('en-IN')}</div>
                        </div>
                        <span className={`badge badge-${s.category === 'General' ? 'green' : s.category === 'Electrical' ? 'blue' : 'orange'}`}>{s.category}</span>
                        <div className={`opt-check${isSelected ? ' show' : ''}`}><CheckCircle size={18} /></div>
                      </div>
                    );
                  })}
                </div>
                {selectedServices.length > 0 && allAddons.length > 0 && (
                  <div className="addons-section">
                    <h3>Available Add-ons</h3>
                    <div className="addon-list">
                      {allAddons.map(a => (
                        <label key={a.id} className={`addon-item${sel.addons.includes(a.id) ? ' selected' : ''}`}>
                          <input type="checkbox" checked={sel.addons.includes(a.id)} onChange={() => setSel(p => ({ ...p, addons: p.addons.includes(a.id) ? p.addons.filter(x => x !== a.id) : [...p.addons, a.id] }))} />
                          <span>{a.name}</span>
                          <span className="addon-price">+₹{a.price}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Step 2: Schedule */}
            {step === 2 && (
              <div className="booking-step">
                <h2>Choose Date & Time</h2>
                <div className="date-grid">
                  {getNextDays(10).map(d => {
                    const dateStr = d.toISOString().split('T')[0];
                    const dayName = d.toLocaleDateString('en-IN', { weekday: 'short' });
                    const dayNum  = d.getDate();
                    const month   = d.toLocaleDateString('en-IN', { month: 'short' });
                    return (
                      <button key={dateStr} className={`date-btn${sel.date === dateStr ? ' active' : ''}`} onClick={() => setSel(p => ({ ...p, date: dateStr }))}>
                        <span className="day-name">{dayName}</span>
                        <span className="day-num">{dayNum}</span>
                        <span className="day-month">{month}</span>
                      </button>
                    );
                  })}
                </div>
                {sel.date && (
                  <>
                    <h3 style={{ marginTop: '24px', marginBottom: '12px', fontSize: '15px', fontWeight: 600 }}>Available Time Slots</h3>
                    <div className="slot-grid">
                      {TIME_SLOTS.map(slot => (
                        <button key={slot} className={`slot-btn${sel.slot === slot ? ' active' : ''}`} onClick={() => setSel(p => ({ ...p, slot }))}>
                          {slot}
                        </button>
                      ))}
                    </div>
                  </>
                )}
                <div className="form-group" style={{ marginTop: '20px' }}>
                  <label className="label">Special Instructions (optional)</label>
                  <textarea className="input-field" rows={3} placeholder="Any specific issues or requests…" value={sel.notes} onChange={e => setSel(p => ({ ...p, notes: e.target.value }))} style={{ resize: 'vertical' }} />
                </div>

                {/* ── User Image Upload ── */}
                <div className="form-group" style={{ marginTop: '16px' }}>
                  <label className="label" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <Image size={14} /> Upload Photos (optional)
                    <span style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 400 }}>— damage, issues, references (max 5)</span>
                  </label>
                  <input
                    ref={imageInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    style={{ display: 'none' }}
                    onChange={handleImageUpload}
                  />
                  <button
                    type="button"
                    className="btn btn-secondary"
                    style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 10 }}
                    onClick={() => imageInputRef.current?.click()}
                    disabled={sel.userImages.length >= 5}
                  >
                    <Upload size={14} />
                    {sel.userImages.length >= 5 ? 'Max 5 photos reached' : 'Choose Photos'}
                  </button>
                  {sel.userImages.length > 0 && (
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      {sel.userImages.map((img, i) => (
                        <div key={i} style={{ position: 'relative' }}>
                          <img
                            src={img}
                            alt="upload preview"
                            style={{ width: 72, height: 72, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)', cursor: 'pointer', display: 'block' }}
                            onClick={() => setPreviewImg(img)}
                          />
                          <button
                            type="button"
                            onClick={() => removeImage(i)}
                            style={{ position: 'absolute', top: -6, right: -6, background: 'var(--red)', border: 'none', borderRadius: '50%', width: 18, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'white', padding: 0 }}
                          >
                            <X size={10} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Step 3: Review */}
            {step === 3 && (
              <div className="booking-step">
                <h2>Review & Confirm</h2>
                <div className="review-section">
                  <div className="review-row"><span>Vehicle</span><span>{vehicle?.make} {vehicle?.model} · {vehicle?.regNumber}</span></div>
                  <div className="review-row"><span>Services</span><span>{selectedServices.map(s => s.name).join(', ')}</span></div>
                  {addonItems.length > 0 && <div className="review-row"><span>Add-ons</span><span>{addonItems.map(a => a.name).join(', ')}</span></div>}
                  <div className="review-row"><span>Date & Time</span><span>{sel.date} at {sel.slot}</span></div>
                  {sel.notes && <div className="review-row"><span>Notes</span><span>{sel.notes}</span></div>}
                  {sel.userImages.length > 0 && (
                    <div className="review-row" style={{ alignItems: 'flex-start' }}>
                      <span>Photos</span>
                      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                        {sel.userImages.map((img, i) => (
                          <img
                            key={i}
                            src={img}
                            alt="booking photo"
                            style={{ width: 56, height: 56, objectFit: 'cover', borderRadius: 6, border: '1px solid var(--border)', cursor: 'pointer' }}
                            onClick={() => setPreviewImg(img)}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                <div className="price-breakdown">
                  {selectedServices.map(s => <div key={s.id} className="pb-row"><span>{s.name}</span><span>₹{s.price?.toLocaleString('en-IN')}</span></div>)}
                  {addonTotal > 0 && <div className="pb-row"><span>Add-ons</span><span>₹{addonTotal.toLocaleString('en-IN')}</span></div>}
                  <div className="pb-row"><span>GST (18%)</span><span>₹{tax.toLocaleString('en-IN')}</span></div>
                  <div className="pb-divider" />
                  <div className="pb-row total"><span>Total</span><span>₹{total.toLocaleString('en-IN')}</span></div>
                </div>
              </div>
            )}

            <div className="step-nav">
              {step > 0 && <button className="btn btn-secondary" onClick={() => setStep(p => p - 1)}><ChevronLeft size={16} />Back</button>}
              {step < STEPS.length - 1 ? (
                <button
                  className="btn btn-primary"
                  style={{ marginLeft: 'auto' }}
                  disabled={(step === 0 && !sel.vehicleId) || (step === 1 && sel.serviceIds.length === 0) || (step === 2 && (!sel.date || !sel.slot))}
                  onClick={() => setStep(p => p + 1)}
                >
                  Next <ChevronRight size={16} />
                </button>
              ) : (
                <button className="btn btn-primary" style={{ marginLeft: 'auto' }} onClick={handleBook} disabled={loading}>
                  {loading ? <span className="spinner" /> : <><CheckCircle size={16} />Confirm Booking</>}
                </button>
              )}
            </div>
          </div>

          {/* Summary Sidebar */}
          {(selectedServices.length > 0 || vehicle) && (
            <div className="booking-sidebar animate-slideInRight delay-200">
              <div className="sidebar-card">
                <h3>Booking Summary</h3>
                {vehicle && (
                  <div className="summary-item">
                    <Car size={16} />
                    <div><div className="si-label">Vehicle</div><div className="si-val">{vehicle.make} {vehicle.model}</div></div>
                  </div>
                )}
                {selectedServices.length > 0 && (
                  <div className="summary-item">
                    <Wrench size={16} />
                    <div><div className="si-label">Services</div><div className="si-val">{selectedServices.map(s => s.name).join(', ')}</div></div>
                  </div>
                )}
                {sel.date && sel.slot && (
                  <div className="summary-item">
                    <Calendar size={16} />
                    <div><div className="si-label">Schedule</div><div className="si-val">{sel.date} · {sel.slot}</div></div>
                  </div>
                )}
                {sel.userImages.length > 0 && (
                  <div className="summary-item">
                    <Image size={16} />
                    <div><div className="si-label">Photos</div><div className="si-val">{sel.userImages.length} attached</div></div>
                  </div>
                )}
                {selectedServices.length > 0 && (
                  <div className="summary-total">
                    <span>Estimated Total</span>
                    <span>₹{total.toLocaleString('en-IN')}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Image Lightbox ── */}
      {previewImg && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.88)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          onClick={() => setPreviewImg(null)}
        >
          <button
            style={{ position: 'absolute', top: 20, right: 20, background: 'rgba(255,255,255,0.15)', border: 'none', borderRadius: '50%', width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'white' }}
            onClick={() => setPreviewImg(null)}
          >
            <X size={18} />
          </button>
          <img
            src={previewImg}
            alt="preview"
            style={{ maxWidth: '90vw', maxHeight: '90vh', borderRadius: 12, objectFit: 'contain' }}
            onClick={e => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
