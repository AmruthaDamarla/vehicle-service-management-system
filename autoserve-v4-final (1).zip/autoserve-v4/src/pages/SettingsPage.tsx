import React from 'react';
import { Link } from 'react-router-dom';
import { User } from 'lucide-react';

export default function SettingsPage(): JSX.Element {
  return (
    <div className="page" style={{ padding: '40px 0 80px' }}>
      <div className="container">
        <div className="page-header">
          <div>
            <h1 className="page-title">Settings</h1>
            <p className="page-subtitle">App preferences and account settings</p>
          </div>
        </div>
        <div className="card" style={{ maxWidth: 480, marginTop: 24 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Settings panel coming soon. Manage your profile and security settings from the Profile page.</p>
            <Link to="/profile" className="btn btn-primary" style={{ width: 'fit-content' }}>
              <User size={16} /> Go to Profile
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
