import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MOCK_USERS } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { Car, ArrowLeft, Mail, Phone, ShieldCheck, Lock, Eye, EyeOff, ArrowRight, RefreshCw } from 'lucide-react';
import './AuthPages.css';

type Step = 'identify' | 'otp' | 'reset';
// Forgot password flow updated with OTP verification support

const PWD_CHECKS = [
  { label: '8+ characters', test: (p: string) => p.length >= 8 },
  { label: '1 uppercase',   test: (p: string) => /[A-Z]/.test(p) },
  { label: '1 number',      test: (p: string) => /[0-9]/.test(p) },
];

function generateOTP(): string {
  return String(Math.floor(1000 + Math.random() * 9000));
}

export default function ForgotPasswordPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('identify');
  const [identifier, setIdentifier] = useState('');
  const [identifierError, setIdentifierError] = useState('');
  const [otp, setOtp] = useState(['', '', '', '']);
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [otpError, setOtpError] = useState('');
  const [otpTimer, setOtpTimer] = useState(60);
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [passError, setPassError] = useState('');
  const [loading, setLoading] = useState(false);
  const otpRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  // OTP countdown timer
  useEffect(() => {
    if (step !== 'otp') return;
    if (otpTimer <= 0) return;
    const t = setTimeout(() => setOtpTimer(p => p - 1), 1000);
    return () => clearTimeout(t);
  }, [step, otpTimer]);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIdentifierError('');
    const found = MOCK_USERS.find(u => u.email === identifier || u.mobile === identifier);
    if (!found) { setIdentifierError('No account found with this email or mobile.'); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 800));
    const code = generateOTP();
    setGeneratedOtp(code);
    setLoading(false);
    setStep('otp');
    setOtpTimer(60);
    // Show OTP in toast since this is a demo (no real SMS/email)
    toast.success(`OTP sent! (Demo: ${code})`, { duration: 8000 });
  };

  const handleOtpChange = (idx: number, val: string) => {
    if (!/^\d*$/.test(val)) return;
    const next = [...otp];
    next[idx] = val.slice(-1);
    setOtp(next);
    setOtpError('');
    if (val && idx < 3) otpRefs[idx + 1].current?.focus();
    if (!val && idx > 0) otpRefs[idx - 1].current?.focus();
  };

  const handleOtpKeyDown = (idx: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[idx] && idx > 0) {
      otpRefs[idx - 1].current?.focus();
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    const entered = otp.join('');
    if (entered.length < 4) { setOtpError('Please enter all 4 digits.'); return; }
    if (entered !== generatedOtp) { setOtpError('Invalid OTP. Please try again.'); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 600));
    setLoading(false);
    setStep('reset');
    toast.success('OTP verified! Set your new password.');
  };

  const handleResendOtp = async () => {
    const code = generateOTP();
    setGeneratedOtp(code);
    setOtp(['', '', '', '']);
    setOtpError('');
    setOtpTimer(60);
    toast.success(`New OTP sent! (Demo: ${code})`, { duration: 8000 });
    otpRefs[0].current?.focus();
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassError('');
    if (newPass.length < 8) { setPassError('Password must be at least 8 characters.'); return; }
    if (!/[A-Z]/.test(newPass)) { setPassError('Password must contain at least 1 uppercase letter.'); return; }
    if (!/[0-9]/.test(newPass)) { setPassError('Password must contain at least 1 number.'); return; }
    if (newPass !== confirmPass) { setPassError('Passwords do not match.'); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 800));
    // Update password in MOCK_USERS (demo in-memory)
    const user = MOCK_USERS.find(u => u.email === identifier || u.mobile === identifier);
    if (user) user.password = newPass;
    setLoading(false);
    toast.success('Password reset successfully! Please sign in.');
    navigate('/login');
  };

  return (
    <div className="auth-page">
      <div className="auth-bg">
        <div className="auth-orb auth-orb1" />
        <div className="auth-orb auth-orb2" />
        <div className="auth-grid" />
      </div>
      <div className="auth-container">
        <div className="auth-card animate-fadeInUp">
          <div className="auth-logo">
            <Link to="/" className="brand-link">
              <div className="brand-icon"><Car size={20} /></div>
              <span className="brand-text">AutoServe</span>
            </Link>
          </div>

          {/* Step indicators */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 24 }}>
            {(['identify', 'otp', 'reset'] as Step[]).map((s, i) => (
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{
                  width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 12, fontWeight: 700,
                  background: step === s ? 'var(--accent)' : (['identify','otp','reset'].indexOf(step) > i) ? 'var(--green)' : 'var(--border)',
                  color: (step === s || ['identify','otp','reset'].indexOf(step) > i) ? 'white' : 'var(--text-muted)',
                  transition: 'all 0.3s',
                }}>
                  {['identify','otp','reset'].indexOf(step) > i ? '✓' : i + 1}
                </div>
                {i < 2 && <div style={{ width: 32, height: 2, background: ['identify','otp','reset'].indexOf(step) > i ? 'var(--green)' : 'var(--border)', transition: 'all 0.3s' }} />}
              </div>
            ))}
          </div>

          {/* ── Step 1: Identify ── */}
          {step === 'identify' && (
            <>
              <h1 className="auth-title">Forgot Password?</h1>
              <p className="auth-subtitle">Enter your email or mobile to receive an OTP</p>
              <form onSubmit={handleSendOtp} className="auth-form">
                <div className="form-group">
                  <label className="label">Email or Mobile Number</label>
                  <div className="input-wrap">
                    <Phone size={16} className="input-icon" />
                    <input
                      className={`input-field padded${identifierError ? ' error' : ''}`}
                      value={identifier}
                      onChange={e => { setIdentifier(e.target.value); setIdentifierError(''); }}
                      placeholder="email@example.com or 9876543210"
                      autoComplete="username"
                    />
                  </div>
                  {identifierError && <p className="error-text">{identifierError}</p>}
                </div>
                <button type="submit" className="btn btn-primary btn-lg auth-submit" disabled={loading || !identifier}>
                  {loading ? <span className="spinner" /> : <><span>Send OTP</span><ArrowRight size={18} /></>}
                </button>
              </form>
              <p className="auth-switch"><Link to="/login"><ArrowLeft size={14} style={{ display: 'inline', marginRight: 4 }} />Back to Sign In</Link></p>
            </>
          )}

          {/* ── Step 2: OTP ── */}
          {step === 'otp' && (
            <>
              <div style={{ textAlign: 'center', marginBottom: 8 }}>
                <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'rgba(249,115,22,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                  <ShieldCheck size={26} color="var(--accent)" />
                </div>
                <h1 className="auth-title">Enter OTP</h1>
                <p className="auth-subtitle">We sent a 4-digit code to <strong>{identifier}</strong></p>
              </div>
              <form onSubmit={handleVerifyOtp} className="auth-form">
                <div style={{ display: 'flex', gap: 12, justifyContent: 'center', margin: '20px 0' }}>
                  {otp.map((digit, idx) => (
                    <input
                      key={idx}
                      ref={otpRefs[idx]}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={e => handleOtpChange(idx, e.target.value)}
                      onKeyDown={e => handleOtpKeyDown(idx, e)}
                      style={{
                        width: 56, height: 64, textAlign: 'center', fontSize: 28, fontWeight: 700,
                        border: `2px solid ${otpError ? 'var(--red)' : digit ? 'var(--accent)' : 'var(--border)'}`,
                        borderRadius: 12, outline: 'none', background: 'white', color: 'var(--text-primary)',
                        transition: 'border-color 0.2s',
                      }}
                    />
                  ))}
                </div>
                {otpError && <p className="error-text" style={{ textAlign: 'center' }}>{otpError}</p>}

                <div style={{ textAlign: 'center', fontSize: 13, color: 'var(--text-secondary)', margin: '8px 0 16px' }}>
                  {otpTimer > 0
                    ? <span>Resend OTP in <strong style={{ color: 'var(--accent)' }}>{otpTimer}s</strong></span>
                    : <button type="button" className="forgot-link" style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }} onClick={handleResendOtp}>
                        <RefreshCw size={13} /> Resend OTP
                      </button>
                  }
                </div>

                <button type="submit" className="btn btn-primary btn-lg auth-submit" disabled={loading || otp.join('').length < 4}>
                  {loading ? <span className="spinner" /> : <><span>Verify OTP</span><ArrowRight size={18} /></>}
                </button>
              </form>
              <p className="auth-switch">
                <button className="forgot-link" onClick={() => { setStep('identify'); setOtp(['', '', '', '']); setOtpError(''); }}>
                  <ArrowLeft size={14} style={{ display: 'inline', marginRight: 4 }} />Change email/mobile
                </button>
              </p>
            </>
          )}

          {/* ── Step 3: Reset Password ── */}
          {step === 'reset' && (
            <>
              <div style={{ textAlign: 'center', marginBottom: 8 }}>
                <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'rgba(22,163,74,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                  <Lock size={26} color="var(--green)" />
                </div>
                <h1 className="auth-title">Reset Password</h1>
                <p className="auth-subtitle">Choose a strong new password</p>
              </div>
              <form onSubmit={handleResetPassword} className="auth-form">
                <div className="form-group">
                  <label className="label">New Password</label>
                  <div className="input-wrap">
                    <Lock size={16} className="input-icon" />
                    <input
                      className={`input-field padded${passError ? ' error' : ''}`}
                      type={showNew ? 'text' : 'password'}
                      value={newPass}
                      onChange={e => { setNewPass(e.target.value); setPassError(''); }}
                      placeholder="Min 8 chars, 1 uppercase, 1 number"
                    />
                    <button type="button" className="eye-btn" onClick={() => setShowNew(!showNew)}>
                      {showNew ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  {newPass && (
                    <div className="pwd-checks">
                      {PWD_CHECKS.map(c => (
                        <span key={c.label} className={`pwd-check${c.test(newPass) ? ' pass' : ''}`}>
                          ✓ {c.label}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="form-group">
                  <label className="label">Confirm New Password</label>
                  <div className="input-wrap">
                    <Lock size={16} className="input-icon" />
                    <input
                      className={`input-field padded${passError ? ' error' : ''}`}
                      type={showConfirm ? 'text' : 'password'}
                      value={confirmPass}
                      onChange={e => { setConfirmPass(e.target.value); setPassError(''); }}
                      placeholder="Re-enter new password"
                    />
                    <button type="button" className="eye-btn" onClick={() => setShowConfirm(!showConfirm)}>
                      {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
                {passError && <p className="error-text">{passError}</p>}
                <button type="submit" className="btn btn-primary btn-lg auth-submit" disabled={loading}>
                  {loading ? <span className="spinner" /> : <><span>Reset Password</span><ArrowRight size={18} /></>}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
