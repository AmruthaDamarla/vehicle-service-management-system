import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { Booking, Mechanic, Application, Review } from '../context/AppContext';
import toast from 'react-hot-toast';
import {
  LayoutDashboard, BookOpen, Users, TrendingUp, CheckCircle, Clock,
  AlertCircle, X, Zap, Edit2, UserX, UserCheck, ClipboardList, Shield,
  Star, Flag, Eye, Trash2, ThumbsUp
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import './AdminDashboard.css';

interface AdminDashboardProps {
  tab?: string;
}

const STATUS_COLOR: Record<string, string> = {
  Booked: 'badge-blue', Assigned: 'badge-orange', 'Checked-In': 'badge-yellow',
  'In Progress': 'badge-orange', 'Quality Check': 'badge-yellow',
  'Ready for Pickup': 'badge-green', Completed: 'badge-green', Cancelled: 'badge-red'
};
const CHART_COLORS = ['#f97316', '#4f46e5', '#16a34a', '#ca8a04', '#dc2626'];
const CHART_DATA = [
  { name: 'Mon', bookings: 8 }, { name: 'Tue', bookings: 12 }, { name: 'Wed', bookings: 6 },
  { name: 'Thu', bookings: 15 }, { name: 'Fri', bookings: 11 }, { name: 'Sat', bookings: 18 }, { name: 'Sun', bookings: 4 },
];
const STATUSES = ['Assigned', 'Checked-In', 'In Progress', 'Quality Check', 'Ready for Pickup', 'Completed'];
const SKILL_OPTIONS = ['General', 'Electrical', 'Bodywork', 'AC Service', 'Tyres', 'Brakes'];

export default function AdminDashboard({ tab: initTab }: AdminDashboardProps): JSX.Element {
  const {
    bookings, vehicles, services, mechanics, applications, reviews,
    assignMechanic, updateBookingStatus, getSuggestedMechanic,
    updateMechanicSkills, deactivateMechanic, reactivateMechanic,
    approveApplication, rejectApplication,
    flagReview, approveReview, deleteReview,
    getServiceAverageRating,
  } = useApp();
  const { MOCK_USERS, activateMechanicUser } = useAuth();

  const [tab, setTab] = useState<string>(initTab ?? 'overview');
  const [assignModal, setAssignModal] = useState<Booking | null>(null);
  const [selectedMech, setSelectedMech] = useState<string>('');
  const [statusModal, setStatusModal] = useState<Booking | null>(null);
  const [newStatus, setNewStatus] = useState<string>('');
  const [statusNotes, setStatusNotes] = useState<string>('');
  const [skillModal, setSkillModal] = useState<Mechanic | null>(null);
  const [editSkills, setEditSkills] = useState<string[]>([]);
  const [reviewFilter, setReviewFilter] = useState<'all' | 'flagged' | 'approved'>('all');

  const totalRevenue = bookings.filter(b => b.status === 'Completed').reduce((s, b) => s + (b.total ?? 0), 0);
  const activeCount = bookings.filter(b => !['Completed', 'Cancelled'].includes(b.status)).length;
  const unassigned = bookings.filter(b => b.status === 'Booked').length;
  const pendingApps = applications.filter(a => a.status === 'pending').length;
  const flaggedReviews = reviews.filter(r => r.flagged);

  const catData = services.map(s => ({
    name: s.name.length > 14 ? s.name.slice(0, 14) + '…' : s.name,
    count: bookings.filter(b => b.serviceId === s.id).length,
  })).filter(d => d.count > 0);

  const getUserName = (userId: string | number): string => {
    const u = (MOCK_USERS ?? []).find(u => u.id === userId);
    return u ? u.name : `User #${userId}`;
  };
  const getVehicle = (id: string | number) => vehicles.find(v => v.id === id);
  const getService = (id: string | number) => services.find(s => s.id === id);

  const openAssignModal = (booking: Booking): void => {
    const suggested = getSuggestedMechanic(booking.serviceId);
    setAssignModal(booking);
    setSelectedMech(suggested ? String(suggested.id) : '');
  };
  const handleAssign = (): void => {
    if (!selectedMech) { toast.error('Select a mechanic'); return; }
    if (!assignModal) return;
    assignMechanic(assignModal.id, parseInt(selectedMech));
    toast.success('Mechanic assigned successfully');
    setAssignModal(null); setSelectedMech('');
  };
  const handleStatusUpdate = (): void => {
    if (!newStatus || !statusModal) return;
    updateBookingStatus(statusModal.id, newStatus, statusNotes.trim() || undefined);
    toast.success(`Status updated to ${newStatus}`);
    setStatusModal(null); setNewStatus(''); setStatusNotes('');
  };

  const handleApprove = (app: Application): void => {
    approveApplication(app.id);
    if (app.userId !== undefined) activateMechanicUser(app.userId);
    toast.success(`${app.name} approved as mechanic!`);
  };
  const handleReject = (app: Application): void => {
    rejectApplication(app.id);
    toast.success('Application rejected');
  };

  const openSkillModal = (mech: Mechanic): void => { setSkillModal(mech); setEditSkills([...mech.skills]); };
  const handleSaveSkills = (): void => {
    if (!skillModal) return;
    updateMechanicSkills(skillModal.id, editSkills);
    toast.success('Skills updated');
    setSkillModal(null);
  };

  // Filtered reviews for moderation
  const filteredReviews: Review[] = reviews.filter(r => {
    if (reviewFilter === 'flagged') return r.flagged;
    if (reviewFilter === 'approved') return r.approved && !r.flagged;
    return true;
  });

  return (
    <div className="page admin-page">
      <div className="container">
        <div className="page-header animate-fadeInUp">
          <div>
            <h1 className="page-title">Admin Dashboard</h1>
            <p className="page-subtitle">Manage bookings, mechanics and service operations</p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Shield size={16} color="var(--accent)" />
            <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)' }}>Admin Portal</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="admin-tabs animate-fadeInUp delay-100">
          {[
            { id: 'overview',      icon: LayoutDashboard, label: 'Overview' },
            { id: 'bookings',      icon: BookOpen,        label: 'Bookings' },
            { id: 'mechanics',     icon: Users,           label: 'Mechanics' },
            { id: 'applications',  icon: ClipboardList,   label: `Applications${pendingApps > 0 ? ' (' + pendingApps + ')' : ''}` },
            { id: 'reviews',       icon: Star,            label: `Reviews${flaggedReviews.length > 0 ? ' (' + flaggedReviews.length + ')' : ''}` },
          ].map(t => (
            <button key={t.id} className={`admin-tab${tab === t.id ? ' active' : ''}`} onClick={() => setTab(t.id)}>
              <t.icon size={16} />{t.label}
              {t.id === 'applications' && pendingApps > 0 && <span style={{ background: 'var(--red)', color: 'white', fontSize: '10px', padding: '1px 6px', borderRadius: '20px', marginLeft: 4 }}>{pendingApps}</span>}
              {t.id === 'reviews' && flaggedReviews.length > 0 && <span style={{ background: 'var(--red)', color: 'white', fontSize: '10px', padding: '1px 6px', borderRadius: '20px', marginLeft: 4 }}>{flaggedReviews.length}</span>}
            </button>
          ))}
        </div>

        {/* ── OVERVIEW ── */}
        {tab === 'overview' && (
          <div className="animate-fadeInUp delay-200">
            <div className="admin-stats">
              {[
                { label: 'Total Bookings', value: bookings.length, icon: BookOpen, color: 'blue' },
                { label: 'Active Now', value: activeCount, icon: Clock, color: 'orange' },
                { label: 'Unassigned', value: unassigned, icon: AlertCircle, color: 'red' },
                { label: 'Revenue', value: `₹${(totalRevenue / 1000).toFixed(1)}K`, icon: TrendingUp, color: 'green' },
              ].map(s => (
                <div key={s.label} className={`admin-stat-card color-${s.color}`}>
                  <div className="asc-icon"><s.icon size={22} /></div>
                  <div className="asc-value">{s.value}</div>
                  <div className="asc-label">{s.label}</div>
                </div>
              ))}
            </div>
            <div className="charts-grid">
              <div className="chart-card">
                <h3>Bookings This Week</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={CHART_DATA}>
                    <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
                    <Tooltip contentStyle={{ background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', color: '#1e293b' }} />
                    <Bar dataKey="bookings" fill="#f97316" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="chart-card">
                <h3>Service Distribution</h3>
                {catData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie data={catData} cx="50%" cy="50%" outerRadius={80} dataKey="count" label={({ name }: { name: string }) => name}>
                        {catData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                      </Pie>
                      <Tooltip contentStyle={{ background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', color: '#1e293b' }} />
                    </PieChart>
                  </ResponsiveContainer>
                ) : <div className="no-data">No data yet</div>}
              </div>
            </div>
            <div className="admin-card">
              <div className="ac-header"><h3>Recent Bookings</h3><button className="btn btn-secondary btn-sm" onClick={() => setTab('bookings')}>View All</button></div>
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead><tr><th>ID</th><th>Customer</th><th>Service</th><th>Date</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    {bookings.slice(0, 5).map(b => {
                      const svc = getService(b.serviceId);
                      return (
                        <tr key={b.id}>
                          <td className="mono">#{b.id}</td>
                          <td>{b.userName ?? getUserName(b.userId)}</td>
                          <td>{b.serviceLabel ?? svc?.name}</td>
                          <td>{b.date}</td>
                          <td><span className={`badge ${STATUS_COLOR[b.status] ?? 'badge-blue'}`}>{b.status}</span></td>
                          <td>
                            <div className="action-btns">
                              {(b.status === 'Booked' || (!b.mechanic && !['Completed','Cancelled'].includes(b.status))) && (
                                <button className="btn btn-primary btn-sm" onClick={() => openAssignModal(b)}>
                                  {b.mechanic ? 'Reassign' : 'Assign'}
                                </button>
                              )}
                              {!['Completed', 'Cancelled', 'Booked'].includes(b.status) && <button className="btn btn-secondary btn-sm" onClick={() => { setStatusModal(b); setNewStatus(''); setStatusNotes(''); }}>Update</button>}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ── BOOKINGS ── */}
        {tab === 'bookings' && (
          <div className="animate-fadeInUp delay-200">
            <div className="admin-card">
              <div className="ac-header"><h3>All Bookings</h3><span className="badge badge-blue">{bookings.length} total</span></div>
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead><tr><th>ID</th><th>Customer</th><th>Service</th><th>Vehicle</th><th>Date</th><th>Mechanic</th><th>Status</th><th>Amount</th><th>Actions</th></tr></thead>
                  <tbody>
                    {bookings.map(b => {
                      const svc = getService(b.serviceId);
                      const veh = getVehicle(b.vehicleId);
                      return (
                        <tr key={b.id}>
                          <td className="mono">#{b.id}</td>
                          <td>{b.userName ?? getUserName(b.userId)}</td>
                          <td>{b.serviceLabel ?? svc?.name}</td>
                          <td>{b.vehicleLabel ?? `${veh?.make} ${veh?.model}`}</td>
                          <td>{b.date}</td>
                          <td>{b.mechanic ?? <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>Unassigned</span>}</td>
                          <td><span className={`badge ${STATUS_COLOR[b.status] ?? 'badge-blue'}`}>{b.status}</span></td>
                          <td>₹{(b.total ?? 0).toLocaleString('en-IN')}</td>
                          <td>
                            <div className="action-btns">
                              {!['Completed','Cancelled'].includes(b.status) && (
                                <button className="btn btn-primary btn-sm" onClick={() => openAssignModal(b)}>
                                  {b.mechanic ? 'Reassign' : 'Assign'}
                                </button>
                              )}
                              {!['Completed', 'Cancelled', 'Booked'].includes(b.status) && (
                                <button className="btn btn-secondary btn-sm" onClick={() => { setStatusModal(b); setNewStatus(''); setStatusNotes(''); }}>Update</button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ── MECHANICS ── */}
        {tab === 'mechanics' && (
          <div className="animate-fadeInUp delay-200">
            <div className="admin-card">
              <div className="ac-header">
                <h3>Mechanic Team</h3>
                <span className="badge badge-green">{mechanics.filter(m => m.status === 'active').length} active</span>
              </div>
              <div className="mechanic-cards-admin">
                {mechanics.map(m => (
                  <div key={m.id} className={`mca-card${m.status === 'inactive' ? ' inactive' : ''}`}>
                    <div className="mca-header">
                      <div className={`mca-avatar ${m.availability ? 'available' : 'busy'}`}>
                        {m.name.split(' ').map((w: string) => w[0]).join('')}
                      </div>
                      <div className={`mca-status-dot ${m.availability ? 'online' : 'offline'}`} />
                    </div>
                    <div className="mca-name">{m.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 8 }}>
                      {m.rating > 0 ? `⭐ ${m.rating} · ` : ''}{m.shift}
                    </div>
                    <div className="mca-skills">
                      {m.skills.map(s => <span key={s} className="badge badge-blue" style={{ margin: '2px' }}>{s}</span>)}
                      {m.skills.length === 0 && <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>No skills set</span>}
                    </div>
                    <div className="mca-meta">
                      <div><span>Load</span><span style={{ fontWeight: 700, color: m.currentLoad > 2 ? 'var(--red)' : 'var(--green)' }}>{m.currentLoad} jobs</span></div>
                    </div>
                    <div className="mca-actions">
                      <button className="btn btn-secondary btn-sm" onClick={() => openSkillModal(m)}>
                        <Edit2 size={12} /> Edit Skills
                      </button>
                      {m.status !== 'inactive' ? (
                        <button className="btn btn-sm danger-btn" onClick={() => { deactivateMechanic(m.id); toast.success(`${m.name} deactivated`); }}>
                          <UserX size={12} /> Deactivate
                        </button>
                      ) : (
                        <button className="btn btn-sm" style={{ background: 'rgba(22,163,74,0.1)', color: 'var(--green)', border: '1px solid rgba(22,163,74,0.2)' }} onClick={() => { reactivateMechanic(m.id); toast.success(`${m.name} reactivated`); }}>
                          <UserCheck size={12} /> Reactivate
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                {mechanics.length === 0 && (
                  <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>
                    <Users size={48} style={{ marginBottom: 12 }} />
                    <p>No active mechanics yet. Approve applications to add mechanics.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ── APPLICATIONS ── */}
        {tab === 'applications' && (
          <div className="animate-fadeInUp delay-200">
            <div className="admin-card">
              <div className="ac-header">
                <h3>Mechanic Applications</h3>
                <span className="badge badge-orange">{pendingApps} pending</span>
              </div>
              {applications.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>
                  <ClipboardList size={48} style={{ marginBottom: 12 }} />
                  <p>No applications yet. Share the registration link with potential mechanics.</p>
                </div>
              ) : (
                <div className="applications-list">
                  {applications.map(app => (
                    <div key={app.id} className={`application-card status-${app.status}`}>
                      <div className="app-avatar">{app.name?.split(' ').map((w: string) => w[0]).join('') ?? '?'}</div>
                      <div className="app-info">
                        <div className="app-name">{app.name}</div>
                        <div className="app-contact">{app.email} · {app.mobile}</div>
                        <div className="app-skills">
                          {(app.skills ?? []).map(s => <span key={s} className="badge badge-blue" style={{ margin: '2px', fontSize: 11 }}>{s}</span>)}
                          {(!app.skills || app.skills.length === 0) && <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>No skills listed</span>}
                        </div>
                        <div className="app-date">Applied: {app.appliedAt ? new Date(app.appliedAt).toLocaleDateString('en-IN') : 'N/A'}</div>
                      </div>
                      <div className="app-status-col">
                        {app.status === 'pending' && (
                          <>
                            <span className="badge badge-yellow">Pending Review</span>
                            <div className="app-actions">
                              <button className="btn btn-sm" style={{ background: 'rgba(22,163,74,0.1)', color: 'var(--green)', border: '1px solid rgba(22,163,74,0.2)' }} onClick={() => handleApprove(app)}>
                                <CheckCircle size={13} /> Approve
                              </button>
                              <button className="btn btn-sm danger-btn" onClick={() => handleReject(app)}>
                                <X size={13} /> Reject
                              </button>
                            </div>
                          </>
                        )}
                        {app.status === 'approved' && <span className="badge badge-green">✓ Approved</span>}
                        {app.status === 'rejected' && <span className="badge badge-red">✗ Rejected</span>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── REVIEWS MODERATION ── */}
        {tab === 'reviews' && (
          <div className="animate-fadeInUp delay-200">
            {/* Service average ratings */}
            <div className="admin-card" style={{ marginBottom: 20 }}>
              <div className="ac-header">
                <h3>Service Average Ratings</h3>
                <span className="badge badge-blue">{services.length} services</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 12 }}>
                {services.map(svc => {
                  const avg = getServiceAverageRating(svc.id);
                  const svcReviews = reviews.filter(r => r.serviceId === svc.id && r.approved !== false);
                  return (
                    <div key={svc.id} style={{ background: 'var(--surface)', borderRadius: 10, padding: '12px 14px', border: '1px solid var(--border)' }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 4 }}>{svc.name}</div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <Star size={14} color="#f59e0b" fill="#f59e0b" />
                        <span style={{ fontWeight: 800, fontSize: 16, color: 'var(--text-primary)' }}>{avg > 0 ? avg.toFixed(1) : '—'}</span>
                        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>({svcReviews.length} reviews)</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Review moderation queue */}
            <div className="admin-card">
              <div className="ac-header">
                <h3>Review Moderation</h3>
                <div style={{ display: 'flex', gap: 8 }}>
                  {(['all', 'flagged', 'approved'] as const).map(f => (
                    <button key={f} className={`btn btn-sm ${reviewFilter === f ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setReviewFilter(f)}>
                      {f === 'flagged' ? `🚩 Flagged (${flaggedReviews.length})` : f === 'approved' ? '✓ Approved' : 'All'}
                    </button>
                  ))}
                </div>
              </div>
              {filteredReviews.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>
                  <Star size={48} style={{ marginBottom: 12 }} />
                  <p>No reviews in this category.</p>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {filteredReviews.map(r => {
                    const svc = getService(r.serviceId);
                    return (
                      <div key={r.id} style={{
                        background: r.flagged ? 'rgba(220,38,38,0.04)' : 'var(--surface)',
                        border: `1px solid ${r.flagged ? 'rgba(220,38,38,0.2)' : 'var(--border)'}`,
                        borderRadius: 12, padding: '14px 16px',
                      }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                          <div>
                            <span style={{ fontWeight: 700, fontSize: 14 }}>{r.userName}</span>
                            <span style={{ fontSize: 12, color: 'var(--text-muted)', marginLeft: 8 }}>· {svc?.name}</span>
                            <span style={{ fontSize: 12, color: 'var(--text-muted)', marginLeft: 8 }}>· {r.createdAt}</span>
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star key={i} size={12} color={i < r.rating ? '#f59e0b' : '#e2e8f0'} fill={i < r.rating ? '#f59e0b' : '#e2e8f0'} />
                            ))}
                            <span style={{ fontSize: 12, fontWeight: 700, marginLeft: 4 }}>{r.rating}/5</span>
                          </div>
                        </div>
                        <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 8px', lineHeight: 1.6 }}>{r.comment}</p>
                        {r.flagged && r.flaggedReason && (
                          <div style={{ fontSize: 11, color: 'var(--red)', background: 'rgba(220,38,38,0.06)', padding: '4px 10px', borderRadius: 6, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                            <Flag size={11} /> {r.flaggedReason}
                          </div>
                        )}
                        {r.edited && <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 8 }}>✏️ Edited {r.editedAt ? new Date(r.editedAt).toLocaleDateString('en-IN') : ''}</div>}
                        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                          {r.flagged && (
                            <button className="btn btn-sm" style={{ background: 'rgba(22,163,74,0.1)', color: 'var(--green)', border: '1px solid rgba(22,163,74,0.2)' }}
                              onClick={() => { approveReview(r.id); toast.success('Review approved'); }}>
                              <ThumbsUp size={12} /> Approve
                            </button>
                          )}
                          {!r.flagged && (
                            <button className="btn btn-sm btn-secondary"
                              onClick={() => { flagReview(r.id, 'Manually flagged by admin'); toast.success('Review flagged'); }}>
                              <Flag size={12} /> Flag
                            </button>
                          )}
                          <button className="btn btn-sm danger-btn"
                            onClick={() => { deleteReview(r.id); toast.success('Review deleted'); }}>
                            <Trash2 size={12} /> Delete
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ── Assign Mechanic Modal ── */}
      {assignModal && (
        <div className="modal-overlay" onClick={() => setAssignModal(null)}>
          <div className="modal animate-fadeInUp" onClick={(e: React.MouseEvent) => e.stopPropagation()} style={{ maxWidth: 520 }}>
            <div className="modal-header">
              <div>
                <h2>Assign Mechanic</h2>
                <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>Booking #{assignModal.id} · {assignModal.serviceLabel ?? getService(assignModal.serviceId)?.name}</p>
              </div>
              <button className="modal-close" onClick={() => setAssignModal(null)}><X size={18} /></button>
            </div>
            {(() => {
              const suggested = getSuggestedMechanic(assignModal.serviceId);
              return (
                <>
                  {suggested && (
                    <div style={{ background: 'rgba(22,163,74,0.08)', border: '1px solid rgba(22,163,74,0.2)', borderRadius: 8, padding: '10px 14px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--green)' }}>
                      <Zap size={14} /> <strong>Suggested:</strong> {suggested.name} — best skill match & lowest load
                    </div>
                  )}
                  <div className="mechanic-options">
                    {mechanics.filter(m => m.status === 'active').map(m => {
                      const isSuggested = suggested?.id === m.id;
                      return (
                        <label key={m.id} className={`mech-option${selectedMech === String(m.id) ? ' selected' : ''}${!m.availability ? ' unavailable' : ''}`} style={{ opacity: m.availability ? 1 : 0.55 }}>
                          <input type="radio" name="mechanic" value={m.id} checked={selectedMech === String(m.id)} onChange={() => m.availability && setSelectedMech(String(m.id))} disabled={!m.availability} />
                          <div className="mo-avatar">{m.name.split(' ').map((w: string) => w[0]).join('')}</div>
                          <div className="mo-info">
                            <div className="mo-name" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                              {m.name}
                              {isSuggested && <span style={{ background: 'var(--green)', color: 'white', fontSize: 10, padding: '2px 6px', borderRadius: 20, fontWeight: 700 }}>Best Fit</span>}
                              {!m.availability && <span style={{ background: 'rgba(220,38,38,0.1)', color: 'var(--red)', fontSize: 10, padding: '2px 6px', borderRadius: 20 }}>Busy</span>}
                            </div>
                            <div className="mo-meta">
                              {m.skills.map(s => <span key={s} style={{ background: 'rgba(79,70,229,0.1)', color: 'var(--blue)', fontSize: 10, padding: '2px 6px', borderRadius: 20, marginRight: 4 }}>{s}</span>)}
                              · Load: {m.currentLoad}{m.rating > 0 ? ` · ⭐ ${m.rating}` : ''}
                            </div>
                          </div>
                          <div className={`mo-load load-${m.currentLoad > 2 ? 'high' : 'low'}`}>{m.currentLoad} jobs</div>
                        </label>
                      );
                    })}
                    {mechanics.filter(m => m.status === 'active').length === 0 && (
                      <p style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 20 }}>No active mechanics. Approve applications first.</p>
                    )}
                  </div>
                </>
              );
            })()}
            <div className="modal-actions" style={{ marginTop: 20 }}>
              <button className="btn btn-secondary" onClick={() => setAssignModal(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleAssign}><CheckCircle size={15} />Assign</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Update Status Modal ── */}
      {statusModal && (
        <div className="modal-overlay" onClick={() => setStatusModal(null)}>
          <div className="modal animate-fadeInUp" onClick={(e: React.MouseEvent) => e.stopPropagation()}>
            <div className="modal-header">
              <div><h2>Update Status</h2><p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>Booking #{statusModal.id} · Current: {statusModal.status}</p></div>
              <button className="modal-close" onClick={() => setStatusModal(null)}><X size={18} /></button>
            </div>
            <div className="status-options">
              {STATUSES.map(s => (
                <button key={s} className={`status-option${newStatus === s ? ' selected' : ''}`} onClick={() => setNewStatus(s)}>
                  <span className={`badge ${STATUS_COLOR[s] ?? 'badge-blue'}`}>{s}</span>
                </button>
              ))}
            </div>
            <div className="form-group" style={{ marginTop: 16 }}>
              <label className="label">Notes (optional)</label>
              <textarea
                className="input-field"
                style={{ resize: 'vertical', minHeight: 70, fontFamily: 'inherit', fontSize: 13 }}
                placeholder="Add notes visible to the customer..."
                value={statusNotes}
                onChange={(e) => setStatusNotes(e.target.value)}
              />
            </div>
            <div className="modal-actions" style={{ marginTop: 16 }}>
              <button className="btn btn-secondary" onClick={() => setStatusModal(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleStatusUpdate} disabled={!newStatus}>Update Status</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Edit Skills Modal ── */}
      {skillModal && (
        <div className="modal-overlay" onClick={() => setSkillModal(null)}>
          <div className="modal animate-fadeInUp" onClick={(e: React.MouseEvent) => e.stopPropagation()}>
            <div className="modal-header">
              <div><h2>Edit Skills</h2><p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>{skillModal.name}</p></div>
              <button className="modal-close" onClick={() => setSkillModal(null)}><X size={18} /></button>
            </div>
            <label className="label" style={{ marginBottom: 12 }}>Select applicable skills:</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 20 }}>
              {SKILL_OPTIONS.map(s => (
                <button key={s} type="button"
                  style={{ padding: '8px 16px', border: `1.5px solid ${editSkills.includes(s) ? 'var(--blue)' : 'var(--border)'}`, borderRadius: 20, background: editSkills.includes(s) ? 'rgba(79,70,229,0.08)' : 'white', cursor: 'pointer', fontSize: 13, fontWeight: 600, color: editSkills.includes(s) ? 'var(--blue)' : 'var(--text-secondary)', transition: 'all 0.2s' }}
                  onClick={() => setEditSkills(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s])}>
                  {editSkills.includes(s) && <CheckCircle size={12} style={{ display: 'inline', marginRight: 4 }} />}{s}
                </button>
              ))}
            </div>
            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={() => setSkillModal(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSaveSkills}><CheckCircle size={15} />Save Skills</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
