import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useApp, NEXT_STEP } from '../context/AppContext';
import { CheckCircle, Clock, ArrowLeft, MessageCircle, CreditCard, MapPin, AlertCircle, Camera, Image, X } from 'lucide-react';
import './TrackingPage.css';

const ALL_STATUSES = ['Booked', 'Assigned', 'Checked-In', 'In Progress', 'Quality Check', 'Ready for Pickup', 'Completed'];

const STATUS_ICONS: Record<string, string> = {
  'Booked': '📋', 'Assigned': '👨‍🔧', 'Checked-In': '🔍',
  'In Progress': '🔧', 'Quality Check': '✅', 'Ready for Pickup': '🚗', 'Completed': '🎉'
};

const STATUS_DESC: Record<string, string> = {
  'Booked': 'Your booking has been received and is awaiting assignment.',
  'Assigned': 'A mechanic has been assigned and will begin work soon.',
  'Checked-In': 'Your vehicle has been checked in at the service center.',
  'In Progress': 'Your vehicle is currently being serviced.',
  'Quality Check': 'Final quality inspection is being performed.',
  'Ready for Pickup': 'Your vehicle is ready! Please collect it at your convenience.',
  'Completed': 'Service completed successfully. Thank you for choosing AutoServe!'
};

export default function TrackingPage(): JSX.Element {
  const { bookingId } = useParams<{ bookingId?: string }>();
  const { bookings, vehicles, services, mechanics } = useApp();
  // Lightbox state — used for BOTH mechanic photos and user images
  const [lightboxSrc, setLightboxSrc] = useState<string | null>(null);

  const booking = bookings.find(b => b.id === bookingId);
  if (!booking) return (
    <div className="page tracking-page">
      <div className="container">
        <div className="not-found">
          <AlertCircle size={48} />
          <h2>Booking not found</h2>
          <Link to="/bookings" className="btn btn-primary">Back to Bookings</Link>
        </div>
      </div>
    </div>
  );

  const vehicle  = vehicles.find(v => v.id === booking.vehicleId);
  const service  = services.find(s => s.id === booking.serviceId);
  const mechanic = mechanics.find(m => m.id === booking.mechanicId);

  const currentIdx  = ALL_STATUSES.indexOf(booking.status);
  const isCancelled = booking.status === 'Cancelled';
  const progress    = isCancelled ? 0 : Math.round(((currentIdx + 1) / ALL_STATUSES.length) * 100);

  const lastHistory = booking.statusHistory[booking.statusHistory.length - 1];
  const nextStep    = NEXT_STEP[booking.status];

  // Mechanic-uploaded photos (from status history)
  const mechanicPhotos = booking.statusHistory.flatMap(h => h.photos ?? []);

  // User-uploaded photos (from booking creation)
  const userPhotos = booking.userImages ?? [];

  return (
    <div className="page tracking-page">
      <div className="container">
        <div className="tracking-header animate-fadeInUp">
          <Link to="/bookings" className="back-link"><ArrowLeft size={16} /> All Bookings</Link>
          <div className="th-main">
            <div>
              <h1 className="page-title">Service Tracking</h1>
              <p className="page-subtitle">Booking #{booking.id}</p>
            </div>
            <div className="th-actions">
              <Link to={`/messages/${booking.id}`} className="btn btn-secondary btn-sm"><MessageCircle size={14} />Message</Link>
              {booking.status === 'Booked' && (
                <Link to={`/payment/${booking.id}`} className="btn btn-primary btn-sm"><CreditCard size={14} />Pay Now</Link>
              )}
            </div>
          </div>
        </div>

        <div className="tracking-layout">
          {/* Main Tracker */}
          <div className="tracking-main animate-fadeInUp delay-100">
            {/* Status Banner */}
            <div className={`status-banner${isCancelled ? ' cancelled' : ''}`}>
              <div className="sb-icon">{isCancelled ? '❌' : STATUS_ICONS[booking.status]}</div>
              <div style={{ flex: 1 }}>
                <div className="sb-status">{booking.status}</div>
                <div className="sb-desc">{isCancelled ? 'This booking has been cancelled.' : STATUS_DESC[booking.status]}</div>
                {lastHistory && (
                  <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
                    <Clock size={11} /> Last updated: {lastHistory.time}
                  </div>
                )}
                {nextStep && !isCancelled && booking.status !== 'Completed' && (
                  <div style={{ fontSize: 12, color: 'var(--blue)', marginTop: 4, fontWeight: 600 }}>
                    ➡ Next: {nextStep}
                  </div>
                )}
              </div>
              {!isCancelled && booking.status !== 'Completed' && (
                <div className="sb-pulse"><div className="pulse-dot" /></div>
              )}
            </div>

            {/* Mechanic notes from last update */}
            {lastHistory?.notes && (
              <div style={{ background: 'rgba(79,70,229,0.06)', border: '1px solid rgba(79,70,229,0.18)', borderRadius: 10, padding: '12px 16px', marginBottom: 16, fontSize: 13, color: 'var(--text-secondary)' }}>
                <strong style={{ color: 'var(--blue)' }}>📝 Mechanic Notes:</strong> {lastHistory.notes}
              </div>
            )}

            {/* User-uploaded photos (from booking) */}
            {userPhotos.length > 0 && (
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Image size={14} /> Your Submitted Photos ({userPhotos.length})
                </div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {userPhotos.map((ph, i) => (
                    <img
                      key={i}
                      src={ph}
                      alt="user upload"
                      style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)', cursor: 'pointer' }}
                      onClick={() => setLightboxSrc(ph)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Mechanic service photos */}
            {mechanicPhotos.length > 0 && (
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Camera size={14} /> Service Photos ({mechanicPhotos.length})
                </div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {mechanicPhotos.map((ph, i) => (
                    <img
                      key={i}
                      src={ph}
                      alt="service"
                      style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)', cursor: 'pointer' }}
                      onClick={() => setLightboxSrc(ph)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Progress Bar */}
            {!isCancelled && (
              <div className="progress-section">
                <div className="progress-bar-wrap">
                  <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
                </div>
                <div className="progress-label">{progress}% Complete</div>
              </div>
            )}

            {/* Timeline */}
            {!isCancelled && (
              <div className="status-timeline">
                <h3>Service Journey</h3>
                <div className="timeline">
                  {ALL_STATUSES.map((status, i) => {
                    const done   = i < currentIdx;
                    const active = i === currentIdx;
                    const histEntry = booking.statusHistory.find(h => h.status === status);
                    return (
                      <div key={status} className={`tl-step${done ? ' done' : active ? ' active' : ''}`}>
                        <div className="tl-dot">
                          {done ? <CheckCircle size={14} /> : active ? <div className="tl-active-dot" /> : <div className="tl-empty-dot" />}
                        </div>
                        <div className="tl-content">
                          <div className="tl-status">{STATUS_ICONS[status]} {status}</div>
                          {histEntry ? (
                            <>
                              <div className="tl-time">{histEntry.time}</div>
                              {histEntry.notes && (
                                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2, fontStyle: 'italic' }}>
                                  "{histEntry.notes}"
                                </div>
                              )}
                              {histEntry.photos && histEntry.photos.length > 0 && (
                                <div style={{ display: 'flex', gap: 4, marginTop: 4 }}>
                                  {histEntry.photos.map((ph, pi) => (
                                    <img
                                      key={pi}
                                      src={ph}
                                      alt="step"
                                      style={{ width: 36, height: 36, objectFit: 'cover', borderRadius: 4, border: '1px solid var(--border)', cursor: 'pointer' }}
                                      onClick={() => setLightboxSrc(ph)}
                                    />
                                  ))}
                                </div>
                              )}
                            </>
                          ) : (
                            <div className="tl-pending">Pending</div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="tracking-sidebar animate-slideInRight delay-200">
            <div className="ts-card">
              <h3>Booking Details</h3>
              <div className="ts-rows">
                <div className="ts-row"><span>Booking ID</span><strong className="mono">#{booking.id}</strong></div>
                <div className="ts-row"><span>Service</span><strong>{service?.name}</strong></div>
                <div className="ts-row"><span>Vehicle</span><strong>{vehicle?.make} {vehicle?.model}</strong></div>
                <div className="ts-row"><span>Reg No.</span><strong className="mono">{vehicle?.regNumber}</strong></div>
                <div className="ts-row"><span>Date</span><strong>{booking.date}</strong></div>
                <div className="ts-row"><span>Slot</span><strong>{booking.slot}</strong></div>
              </div>
            </div>

            {mechanic && (
              <div className="ts-card">
                <h3>Your Mechanic</h3>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                  <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'var(--accent)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 16 }}>
                    {mechanic.name.split(' ').map((w: string) => w[0]).join('')}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{mechanic.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>⭐ {mechanic.rating} · {mechanic.shift}</div>
                  </div>
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                  {mechanic.skills.map(s => (
                    <span key={s} style={{ fontSize: 11, padding: '2px 8px', background: 'rgba(79,70,229,0.08)', color: 'var(--blue)', borderRadius: 20, fontWeight: 600 }}>{s}</span>
                  ))}
                </div>
              </div>
            )}

            <div className="ts-card">
              <h3>Amount</h3>
              <div className="ts-rows">
                <div className="ts-row"><span>Total</span><strong>₹{booking.total?.toLocaleString('en-IN')}</strong></div>
              </div>
              {booking.notes && (
                <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 10, padding: '8px 10px', background: 'var(--surface)', borderRadius: 8 }}>
                  📝 {booking.notes}
                </div>
              )}
            </div>

            <div className="ts-card">
              <h3 style={{ display: 'flex', alignItems: 'center', gap: 6 }}><MapPin size={14} /> Service Center</h3>
              <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: 0 }}>AutoServe Service Hub<br />Indiranagar, Bengaluru — 560038</p>
            </div>
          </div>
        </div>
      </div>

      {/* ── Lightbox Modal (base64-safe inline preview) ── */}
      {lightboxSrc && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.88)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          onClick={() => setLightboxSrc(null)}
        >
          <button
            style={{ position: 'absolute', top: 20, right: 20, background: 'rgba(255,255,255,0.15)', border: 'none', borderRadius: '50%', width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'white' }}
            onClick={() => setLightboxSrc(null)}
          >
            <X size={18} />
          </button>
          <img
            src={lightboxSrc}
            alt="full preview"
            style={{ maxWidth: '90vw', maxHeight: '90vh', borderRadius: 12, objectFit: 'contain' }}
            onClick={e => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
