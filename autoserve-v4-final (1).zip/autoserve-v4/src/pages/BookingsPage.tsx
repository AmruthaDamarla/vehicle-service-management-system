import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { Booking, Review } from '../context/AppContext';
import toast from 'react-hot-toast';
import { Calendar, Star, Eye, MessageCircle, XCircle, RefreshCw, CreditCard, X, Send, Clock } from 'lucide-react';
import './BookingsPage.css';

const TIME_SLOTS = ['08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'];
const STATUS_COLOR: Record<string, string> = { Booked: 'badge-blue', Assigned: 'badge-orange', 'Checked-In': 'badge-yellow', 'In Progress': 'badge-orange', 'Quality Check': 'badge-yellow', 'Ready for Pickup': 'badge-green', Completed: 'badge-green', Cancelled: 'badge-red' };
const TABS = ['All', 'Active', 'Completed', 'Cancelled'] as const;
type Tab = typeof TABS[number];

interface ReviewModalState { booking: Booking; existing: Review | undefined }
interface ReviewForm { rating: number; comment: string }
interface RescheduleForm { date: string; slot: string }

export default function BookingsPage() {
  const { user } = useAuth();
  const { bookings, vehicles, services, reviews, cancelBooking, addReview, editReview, rescheduleBooking } = useApp();
  const navigate = useNavigate();
  const [tab, setTab]               = useState<Tab>('All');
  const [reviewModal, setReviewModal]   = useState<ReviewModalState | null>(null);
  const [reviewForm, setReviewForm]     = useState<ReviewForm>({ rating: 5, comment: '' });
  const [cancelConfirm, setCancelConfirm] = useState<string | null>(null);
  const [rescheduleModal, setRescheduleModal] = useState<Booking | null>(null);
  const [rescheduleForm, setRescheduleForm]   = useState<RescheduleForm>({ date: '', slot: '' });

  const myBookings = bookings.filter(b => b.userId === user?.id);
  const filtered = myBookings.filter(b => {
    if (tab === 'Active')    return !['Completed', 'Cancelled', 'Booked'].includes(b.status) || b.status === 'Booked';
    if (tab === 'Completed') return b.status === 'Completed';
    if (tab === 'Cancelled') return b.status === 'Cancelled';
    return true;
  });

  const getService = (id: number) => services.find(s => s.id === id);
  const getVehicle = (id: number) => vehicles.find(v => v.id === id);
  const getReview  = (bookingId: string) => reviews.find(r => r.bookingId === bookingId);

  const openReview = (booking: Booking) => {
    const existing = getReview(booking.id);
    setReviewForm(existing ? { rating: existing.rating, comment: existing.comment } : { rating: 5, comment: '' });
    setReviewModal({ booking, existing });
  };

  const handleReviewSubmit = () => {
    if (!reviewForm.comment.trim()) { toast.error('Please write a review comment'); return; }
    if (!reviewModal || !user) return;
    const { booking, existing } = reviewModal;
    if (existing) {
      editReview(existing.id, reviewForm);
      toast.success('Review updated');
    } else {
      addReview({ ...reviewForm, userId: user.id, bookingId: booking.id, serviceId: booking.serviceId, userName: user.name });
      toast.success('Review submitted! Thanks for your feedback.');
    }
    setReviewModal(null);
  };

  const handleCancel = (id: string) => {
    cancelBooking(id);
    setCancelConfirm(null);
    toast.success('Booking cancelled');
  };

  const canCancel = (b: Booking) => !['Completed', 'Cancelled', 'In Progress', 'Quality Check', 'Ready for Pickup'].includes(b.status);

  const canReschedule = (b: Booking) => {
    if (['Completed', 'Cancelled', 'In Progress', 'Quality Check', 'Ready for Pickup'].includes(b.status)) return false;
    if (!b.date || !b.slot) return false;
    const slotHour   = b.slot.split(':')[0];
    const slotPeriod = b.slot.split(' ')[1];
    let h = parseInt(slotHour);
    if (slotPeriod === 'PM' && h !== 12) h += 12;
    if (slotPeriod === 'AM' && h === 12) h = 0;
    const appointmentTime = new Date(b.date + 'T' + String(h).padStart(2, '0') + ':00:00');
    return appointmentTime > new Date(Date.now() + 3 * 60 * 60 * 1000);
  };

  const canEditReview = (rev: Review | undefined) => {
    if (!rev) return false;
    const created = new Date(rev.createdAt + 'T00:00:00').getTime();
    return (Date.now() - created) < 24 * 60 * 60 * 1000;
  };

  const handleReschedule = () => {
    if (!rescheduleForm.date || !rescheduleForm.slot) { toast.error('Select date and time'); return; }
    if (!rescheduleModal) return;
    const result = rescheduleBooking(rescheduleModal.id, rescheduleForm.date, rescheduleForm.slot);
    if ('error' in result) { toast.error(result.error); return; }
    toast.success('Booking rescheduled successfully!');
    setRescheduleModal(null);
  };

  const getNextDays = (n: number): Date[] => {
    const days: Date[] = [];
    for (let i = 1; i <= n; i++) { const d = new Date(); d.setDate(d.getDate() + i); days.push(d); }
    return days;
  };

  return (
    <div className="page bookings-page">
      <div className="container">
        <div className="page-header animate-fadeInUp">
          <div>
            <h1 className="page-title">My Bookings</h1>
            <p className="page-subtitle">{myBookings.length} total bookings</p>
          </div>
          <Link to="/book" className="btn btn-primary"><Calendar size={16} />New Booking</Link>
        </div>

        <div className="tab-bar animate-fadeInUp delay-100">
          {TABS.map(t => (
            <button key={t} className={`tab-btn${tab === t ? ' active' : ''}`} onClick={() => setTab(t)}>
              {t}
              <span className="tab-count">
                {t === 'All' ? myBookings.length : t === 'Active' ? myBookings.filter(b => !['Completed', 'Cancelled'].includes(b.status)).length : myBookings.filter(b => b.status === t).length}
              </span>
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="bookings-empty animate-fadeInUp delay-200">
            <Calendar size={48} />
            <h3>No {tab.toLowerCase()} bookings</h3>
            <p>{tab === 'All' ? 'Book your first service to get started' : `You have no ${tab.toLowerCase()} bookings`}</p>
            {tab === 'All' && <Link to="/book" className="btn btn-primary">Book a Service</Link>}
          </div>
        ) : (
          <div className="bookings-list animate-fadeInUp delay-200">
            {filtered.map((b, i) => {
              const svc = getService(b.serviceId);
              const veh = getVehicle(b.vehicleId);
              const rev = getReview(b.id);
              return (
                <div key={b.id} className="booking-card" style={{ animationDelay: `${i * 0.05}s` }}>
                  <div className="bc-header">
                    <div className="bc-id">#{b.id}</div>
                    <span className={`badge ${STATUS_COLOR[b.status] || 'badge-blue'}`}>{b.status}</span>
                  </div>
                  <div className="bc-body">
                    <div className="bc-main">
                      <div className="bc-service">{svc?.name}</div>
                      <div className="bc-vehicle">{veh?.make} {veh?.model} · {veh?.regNumber}</div>
                      <div className="bc-meta">
                        <span><Calendar size={12} /> {b.date} at {b.slot}</span>
                        {b.mechanic && <span>👨‍🔧 {b.mechanic}</span>}
                      </div>
                    </div>
                    <div className="bc-price">
                      <div className="bc-total">₹{b.total?.toLocaleString('en-IN')}</div>
                      <div className="bc-total-label">Total</div>
                    </div>
                  </div>

                  {rev && (
                    <div className="bc-review">
                      <div className="bcr-stars">{[1, 2, 3, 4, 5].map(s => <Star key={s} size={12} className={s <= rev.rating ? 'star' : 'star empty'} />)}</div>
                      <p>{rev.comment}</p>
                      {rev.edited && <span className="edited-tag">edited</span>}
                    </div>
                  )}

                  <div className="bc-actions">
                    <Link to={`/track/${b.id}`} className="btn btn-secondary btn-sm"><Eye size={14} />Track</Link>
                    <Link to={`/messages/${b.id}`} className="btn btn-secondary btn-sm"><MessageCircle size={14} />Message</Link>
                    {b.status === 'Completed' && !rev && (
                      <button className="btn btn-secondary btn-sm" onClick={() => openReview(b)}><Star size={14} />Review</button>
                    )}
                    {b.status === 'Completed' && rev && canEditReview(rev) && (
                      <button className="btn btn-secondary btn-sm" onClick={() => openReview(b)}><Star size={14} />Edit Review</button>
                    )}
                    {b.status === 'Completed' && rev && !canEditReview(rev) && (
                      <span style={{ fontSize: '11px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: 4 }}><Clock size={12} />Edit window closed</span>
                    )}
                    {b.status === 'Booked' && (
                      <button className="btn btn-secondary btn-sm" onClick={() => navigate(`/payment/${b.id}`)}><CreditCard size={14} />Pay</button>
                    )}
                    {canReschedule(b) && (
                      <button className="btn btn-secondary btn-sm" onClick={() => { setRescheduleModal(b); setRescheduleForm({ date: b.date, slot: b.slot }); }}><RefreshCw size={14} />Reschedule</button>
                    )}
                    {canCancel(b) && (
                      <button className="btn btn-sm danger-btn" onClick={() => setCancelConfirm(b.id)}><XCircle size={14} />Cancel</button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Review Modal */}
      {reviewModal && (
        <div className="modal-overlay" onClick={() => setReviewModal(null)}>
          <div className="modal review-modal animate-fadeInUp" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h2>{reviewModal.existing ? 'Edit Review' : 'Write a Review'}</h2>
                <p style={{ fontSize: '13px', color: 'var(--text-secondary)', marginTop: '4px' }}>{getService(reviewModal.booking.serviceId)?.name}</p>
              </div>
              <button className="modal-close" onClick={() => setReviewModal(null)}><X size={18} /></button>
            </div>
            <div className="star-rating">
              {[1, 2, 3, 4, 5].map(s => (
                <button key={s} className={`star-btn${s <= reviewForm.rating ? ' active' : ''}`} onClick={() => setReviewForm(p => ({ ...p, rating: s }))}>
                  <Star size={28} />
                </button>
              ))}
            </div>
            <p className="rating-label">{['', 'Very Bad', 'Bad', 'Okay', 'Good', 'Excellent!'][reviewForm.rating]}</p>
            <div className="form-group" style={{ marginTop: '16px' }}>
              <label className="label">Your Review</label>
              <textarea className="input-field" rows={4} placeholder="Share your experience…" value={reviewForm.comment} onChange={e => setReviewForm(p => ({ ...p, comment: e.target.value }))} style={{ resize: 'vertical' }} />
            </div>
            <div className="modal-actions" style={{ marginTop: '16px' }}>
              <button className="btn btn-secondary" onClick={() => setReviewModal(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleReviewSubmit}><Send size={15} />{reviewModal.existing ? 'Update' : 'Submit'} Review</button>
            </div>
          </div>
        </div>
      )}

      {/* Reschedule Modal */}
      {rescheduleModal && (
        <div className="modal-overlay" onClick={() => setRescheduleModal(null)}>
          <div className="modal animate-fadeInUp" onClick={e => e.stopPropagation()} style={{ maxWidth: 520 }}>
            <div className="modal-header">
              <div>
                <h2>Reschedule Booking</h2>
                <p style={{ fontSize: '13px', color: 'var(--text-secondary)', marginTop: '4px' }}>#{rescheduleModal.id} · 3-hour cutoff applies</p>
              </div>
              <button className="modal-close" onClick={() => setRescheduleModal(null)}><X size={18} /></button>
            </div>
            <div style={{ marginBottom: '16px' }}>
              <label className="label">New Date</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '8px' }}>
                {getNextDays(10).map(d => {
                  const ds = d.toISOString().split('T')[0];
                  const isActive = rescheduleForm.date === ds;
                  return (
                    <button key={ds} onClick={() => setRescheduleForm(p => ({ ...p, date: ds, slot: '' }))}
                      style={{ padding: '8px 14px', border: `1.5px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`, borderRadius: '8px', background: isActive ? 'rgba(249,115,22,0.08)' : 'white', cursor: 'pointer', fontSize: '13px', fontWeight: 600, color: isActive ? 'var(--accent)' : 'var(--text-secondary)' }}>
                      {d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })}
                    </button>
                  );
                })}
              </div>
            </div>
            {rescheduleForm.date && (
              <div style={{ marginBottom: '16px' }}>
                <label className="label">New Time Slot</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '8px' }}>
                  {TIME_SLOTS.map(slot => {
                    const isActive = rescheduleForm.slot === slot;
                    return (
                      <button key={slot} onClick={() => setRescheduleForm(p => ({ ...p, slot }))}
                        style={{ padding: '8px 14px', border: `1.5px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`, borderRadius: '8px', background: isActive ? 'rgba(249,115,22,0.08)' : 'white', cursor: 'pointer', fontSize: '13px', fontWeight: 600, color: isActive ? 'var(--accent)' : 'var(--text-secondary)' }}>
                        {slot}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
            <div style={{ background: 'rgba(249,115,22,0.06)', border: '1px solid rgba(249,115,22,0.2)', borderRadius: '8px', padding: '10px 14px', fontSize: '12px', color: 'var(--accent)', marginBottom: '16px' }}>
              ⏰ Reschedule must be at least 3 hours before the appointment time
            </div>
            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={() => setRescheduleModal(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleReschedule}><RefreshCw size={15} />Confirm Reschedule</button>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Modal */}
      {cancelConfirm && (
        <div className="modal-overlay" onClick={() => setCancelConfirm(null)}>
          <div className="modal confirm-modal animate-fadeInUp" onClick={e => e.stopPropagation()}>
            <div className="confirm-icon" style={{ background: 'rgba(239,68,68,0.1)', color: 'var(--red)' }}><XCircle size={28} /></div>
            <h3>Cancel Booking?</h3>
            <p>Are you sure you want to cancel this booking? This action cannot be undone.</p>
            <div className="modal-actions" style={{ justifyContent: 'center' }}>
              <button className="btn btn-secondary" onClick={() => setCancelConfirm(null)}>Keep Booking</button>
              <button className="btn" style={{ background: 'var(--red)', color: 'white' }} onClick={() => handleCancel(cancelConfirm)}>Yes, Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
